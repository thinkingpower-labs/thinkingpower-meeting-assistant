# 思惟力量 AI 工具機器鳥系列

依使用者 2026-10-17 最後指示：帶 AI 功能的思惟力量工具採同系列機器鳥，以不同配色區分產品。風格採帥氣、簡單線條，避免幼兒玩具感。

- 共同外觀：正面幾何鳥首、銳利雙眼、尖喙、對稱上揚的機械翅膀，簡化輪廓與負空間。
- 會議助手：紫色／深紫色，檔名 `ThinkingPowerMeeting.exe`。
- 保留同一輪廓及比例；新產品以配色區分，不改成完全不同角色。
- 公司原有字標不改動。機器鳥為產品圖示，非原 Meetily 標誌。
- `thinkingpower-meeting-bird.png` 是以內建 imagegen 產生的透明背景原始圖；圖示尺寸只做等比縮放與格式轉換。
- 舊資料相容：不改 `tw.thinkingpower.meetily.flybird` 識別碼、資料庫、模型、憑證及原音資料夾。
- 原作者 MIT 與非官方衍生版標示保留於「關於」、LICENSE、NOTICE。

生成提示詞：sleek minimalist robot bird emblem for a professional AI meeting assistant; symmetrical geometric head, narrow intelligent eyes, pointed beak and swept angular wings; broad simple contours, deep violet and purple with white cutouts; transparent background; readable at 16/32/48px; no text, watermark, smile, blush, giant eyes, toy body or desktop shortcut arrow. 使用內建 imagegen 產生；由先前機器人方向依使用者後續指示改為帥氣機器鳥。
