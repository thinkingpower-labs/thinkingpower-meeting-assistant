# 1.1.0 發行備註

以通過使用者驗收的 1.0.3-rc.2 功能正式發行，僅版本與文件包整理，不新增自動說話人分離。

使用說明與變更見公開儲存庫 README、操作說明與 CHANGELOG。原生回歸 14 項、前端 18 個檔案通過；使用者於 2026-10-21 回報驗收通過。執行槽／排隊僅保存在程序記憶體，既有會議與分段進度保存在 SQLite。取消等待當前分段保存後停止後續請求。

Windows 使用 MSVC 工具鏈、C++ Build Tools、Windows SDK、CMake 與 libclang；pnpm 10.18.3 frozen install。準備與發行包對應的 ffmpeg、llama-helper sidecar，以及經建置腳本驗證的 ONNX Runtime DLL。frontend 下先執行 pnpm build，再執行 pnpm exec tauri build --no-bundle --config ../scripts/bundle-config.json --ci，使用正式 protocol 嵌入介面。

第三方來源與授權保留。請勿將資料庫、Key、私人錄音或 .transcription-attempts 提交至公開儲存庫。
