'use client';
import {useEffect,useRef,useState} from 'react';
import Link from 'next/link';
import {invoke,convertFileSrc} from '@tauri-apps/api/core';
import {InterruptedRecordings} from '@/components/InterruptedRecordings';
import {TranscriptionTaskList} from '@/components/TranscriptionTaskList';
import {useTranscriptionTasks,isActiveTask} from '@/hooks/useTranscriptionTasks';
import {useImportDialog} from '@/contexts/ImportDialogContext';
import {Button} from '@/components/ui/button';
type Recording={meeting_id:string;title:string;created_at:string;folder_path:string|null;stage:string|null;provider:string|null;model:string|null;completed_count:number;error:string|null};
const stages:Record<string,string>={waiting:'尚未轉錄',interrupted:'上次中斷，可接續',failed:'處理失敗',cancelled:'已取消，可接續',uploading:'雲端處理中',transcribing:'轉錄中',transcribed:'逐字稿已完成',complete:'完成',summarizing:'產生摘要中',summary_failed:'摘要失敗，逐字稿仍保留'};
export default function RecordingsPage(){
  const {tasks,error:taskError}=useTranscriptionTasks();
  const [rows,setRows]=useState<Recording[]>([]),[error,setError]=useState(''),[search,setSearch]=useState('');
  const [filter,setFilter]=useState('all');
  const [player,setPlayer]=useState<{id:string;title:string;url:string}|null>(null),[playerError,setPlayerError]=useState('');
  const listenRequest=useRef(0);
  const {openImportDialog}=useImportDialog();
  useEffect(()=>{let active=true,pending=false;const refresh=async()=>{if(pending)return;pending=true;try{const result=await invoke<Recording[]>('list_recording_library');if(active){setRows(result);setError('');}}catch{if(active)setError('無法讀取錄音清單，請稍後重試');}finally{pending=false;}};void refresh();const timer=setInterval(refresh,3000);return()=>{active=false;clearInterval(timer);listenRequest.current++;};},[]);
  const listen=async(id:string,title:string)=>{
    const request=++listenRequest.current;setPlayer(null);setPlayerError('');
    try{const path=await invoke<string>('flybird_meeting_audio',{meetingId:id});if(request===listenRequest.current)setPlayer({id,title,url:convertFileSrc(path)});}
    catch(value){if(request===listenRequest.current)setPlayerError(String(value));}
  };
  const active=tasks.filter(isActiveTask);
  const shownTasks=tasks.filter(task=>task.title.toLocaleLowerCase().includes(search.toLocaleLowerCase())&&(filter==='all'||(filter==='active'?isActiveTask(task):filter==='attention'?['failed','cancelled'].includes(task.status):task.status==='complete')));
  const taskMeetings=new Set(tasks.map(task=>task.meeting_id));
  const shownRows=rows.filter(row=>!taskMeetings.has(row.meeting_id)&&row.title.toLocaleLowerCase().includes(search.toLocaleLowerCase())&&(filter==='all'||(filter==='active'?false:filter==='attention'?['waiting','interrupted','failed','cancelled'].includes(row.stage||'waiting'):['transcribed','complete','summarizing','summary_failed'].includes(row.stage||''))));
  return <main className="mx-auto max-w-5xl p-6 pb-28 space-y-5">
    <header className="flex flex-wrap justify-between gap-3"><div><h1 className="text-2xl font-semibold">錄音與轉錄中心</h1><p className="mt-2 text-sm text-gray-600">集中聆聽原音、查看進度與管理工作。雲端最多同時 3 筆，本機 1 筆，其餘依序排隊。</p></div><Button onClick={()=>openImportDialog()}>匯入錄音</Button></header>
    <p className="text-sm">{active.length} 筆處理／排隊中 · {rows.length} 筆會議錄音紀錄</p>
    {(error||taskError)&&<p role="alert" className="text-red-700">{error||taskError}</p>}
    <div className="flex flex-wrap gap-3"><input aria-label="搜尋錄音" placeholder="搜尋錄音名稱" value={search} onChange={event=>setSearch(event.target.value)} className="rounded border px-3 py-2 flex-1"/><select aria-label="篩選錄音狀態" value={filter} onChange={event=>setFilter(event.target.value)} className="rounded border px-3 py-2"><option value="all">全部</option><option value="active">處理／排隊中</option><option value="attention">需要處理</option><option value="complete">已完成</option></select></div>
    {filter!=='active'&&filter!=='complete'&&<InterruptedRecordings search={search} onListen={(path,title)=>{listenRequest.current++;setPlayerError('');setPlayer({id:path,title,url:convertFileSrc(path)});}}/>}
    {(player||playerError)&&<section aria-label="原音播放器" className="sticky top-0 z-20 rounded-xl border bg-blue-50 p-4 shadow-sm"><div className="flex justify-between gap-3"><h2 className="font-semibold">{player?.title||'原音無法播放'}</h2><Button size="sm" variant="outline" onClick={()=>{listenRequest.current++;setPlayer(null);setPlayerError('');}}>關閉播放器</Button></div>{player&&<audio key={player.id} controls preload="metadata" src={player.url} className="mt-3 w-full" onError={()=>setPlayerError('音檔無法播放，請確認原音仍存在或開啟會議檢查。')}/>} {playerError&&<p role="alert" className="text-red-700">{playerError}</p>}</section>}
    <TranscriptionTaskList tasks={shownTasks} onListen={(id,title)=>{void listen(id,title);}}/>
    <section className="space-y-3" aria-label="已保存的錄音">{shownRows.map(row=>{const count=row.completed_count;return <article key={row.meeting_id} className="rounded-xl border p-4 space-y-2"><h2 className="font-semibold">{row.title}</h2><p className="text-sm text-gray-600">{row.created_at} · {stages[row.stage||'waiting']||row.stage} · 已保存 {count} 段{row.provider?` · ${row.provider}／${row.model||'預設'}`:''}</p>{row.error&&<p className="text-sm text-red-700 break-words">{row.error}</p>}<div className="flex gap-2"><Button size="sm" variant="outline" disabled={!row.folder_path} onClick={()=>void listen(row.meeting_id,row.title)}>聆聽原音</Button><Link className="px-3 py-2 text-sm underline" href={`/meeting-details?id=${encodeURIComponent(row.meeting_id)}`}>開啟會議／接續或重新轉錄</Link></div></article>;})}</section>
    {!shownRows.length&&!shownTasks.length&&<p className="text-gray-500">此篩選沒有會議轉錄紀錄；未完成的錄音會列在上方。</p>}
  </main>;
}
