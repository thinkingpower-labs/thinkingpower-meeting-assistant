import { Metadata } from 'next';

export const metadata: Metadata = {
  title: '思惟力量會議助手',
  description: 'AI-powered meeting assistant',
};
