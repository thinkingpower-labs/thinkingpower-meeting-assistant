import type { ModelConfig } from '@/components/ModelSettingsModal';

export function summaryUsesNetwork(config: ModelConfig): boolean {
  if (config.provider === 'builtin-ai') return false;
  if (config.provider !== 'ollama' && config.provider !== 'custom-openai') return true;
  const endpoint = config.provider === 'ollama' ? config.ollamaEndpoint || 'http://localhost:11434' : config.customOpenAIEndpoint || '';
  try { return !['localhost', '127.0.0.1', '[::1]'].includes(new URL(endpoint).hostname); }
  catch { return true; }
}

// An explicit one-use grant for this meeting and this exact summary configuration.
// It expires with the current window session; never grant on merely reading settings.
const token = (meetingId: string) => `summary-consent:${meetingId}`;
const destination = (config: ModelConfig) => JSON.stringify([config.provider, config.model, config.ollamaEndpoint, config.customOpenAIEndpoint]);
export function grantSummary(meetingId: string, config: ModelConfig) { sessionStorage.setItem(token(meetingId), destination(config)); }
export function consumeSummaryGrant(meetingId: string, config: ModelConfig) {
  const value = sessionStorage.getItem(token(meetingId)); sessionStorage.removeItem(token(meetingId));
  return value === destination(config);
}
