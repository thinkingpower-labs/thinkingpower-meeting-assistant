export interface LanguageOption {
  code: string;
  label: string;
}

/**
 * Language options offered in the summary language pickers.
 * Codes must stay in sync with `language_name_from_code` in
 * `frontend/src-tauri/src/summary/processor.rs`.
 */
export const LANGUAGE_OPTIONS: LanguageOption[] = [
  { code: 'en', label: "英文" },
  { code: 'zh', label: "中文" },
  { code: 'zh-tw', label: "繁體中文" },
  { code: 'de', label: "德文" },
  { code: 'es', label: "西班牙文" },
  { code: 'ru', label: "俄文" },
  { code: 'ko', label: "韓文" },
  { code: 'fr', label: "法文" },
  { code: 'ja', label: "日文" },
  { code: 'pt', label: "葡萄牙文" },
  { code: 'it', label: "義大利文" },
  { code: 'nl', label: "荷蘭文" },
  { code: 'pl', label: "波蘭文" },
  { code: 'ar', label: "阿拉伯文" },
  { code: 'hi', label: "印地文" },
  { code: 'ta', label: "泰米爾文" },
  { code: 'tr', label: "土耳其文" },
  { code: 'vi', label: "越南文" },
  { code: 'th', label: "泰文" },
  { code: 'id', label: "印尼文" },
  { code: 'sv', label: "瑞典文" },
  { code: 'cs', label: "捷克文" },
  { code: 'da', label: "丹麥文" },
  { code: 'fi', label: "芬蘭文" },
  { code: 'el', label: "希臘文" },
  { code: 'he', label: "希伯來文" },
  { code: 'hu', label: "匈牙利文" },
  { code: 'no', label: "挪威文" },
  { code: 'ro', label: "羅馬尼亞文" },
  { code: 'uk', label: "烏克蘭文" },
];

export const AUTO_VALUE = '__auto__' as const;

const SUPPORTED_CODES: ReadonlySet<string> = new Set(LANGUAGE_OPTIONS.map((o) => o.code));

/**
 * Normalises a raw locale string (from transcription or storage) into a code we
 * can translate into. Handles BCP-47 regional tags: `pt-BR` -> `pt`, `en_GB` -> `en`.
 * Returns null for unsupported languages so callers can fall back to English
 * rather than sending a code Rust will silently drop.
 */
export function normaliseLanguageCode(raw: string | null | undefined): string | null {
  if (!raw) return null;
  const lower = raw.toLowerCase().replace(/_/g, '-');
  if (SUPPORTED_CODES.has(lower)) return lower;
  const base = lower.split('-')[0];
  if (SUPPORTED_CODES.has(base)) return base;
  return null;
}

export function labelForCode(code: string): string {
  return LANGUAGE_OPTIONS.find((l) => l.code === code)?.label ?? code;
}
