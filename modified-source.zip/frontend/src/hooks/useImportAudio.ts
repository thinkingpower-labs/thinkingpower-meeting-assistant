import { useState, useEffect, useCallback, useRef } from 'react';
import { invoke } from '@tauri-apps/api/core';
import type { TranscriptionTask } from './useTranscriptionTasks';
import Analytics from '@/lib/analytics';
import { applyPinnedSummaryLanguageToMeeting } from '@/lib/summary-language-preferences';
import { toast } from 'sonner';

export interface AudioFileInfo {
  path: string;
  filename: string;
  duration_seconds: number;
  size_bytes: number;
  format: string;
}

export interface ImportProgress {
  completed: number;
  total: number;
  stage: string;
  progress_percentage: number;
  message: string;
}

export interface ImportResult {
  job_id?: string;
  meeting_id: string;
  title: string;
  segments_count: number;
  duration_seconds: number;
}

export type ImportStatus = 'idle' | 'validating' | 'processing' | 'complete' | 'error';

export interface UseImportAudioOptions {
  onComplete?: (result: ImportResult) => void;
  onError?: (error: string) => void;
}

export interface UseImportAudioReturn {
  status: ImportStatus;
  fileInfo: AudioFileInfo | null;
  progress: ImportProgress | null;
  error: string | null;
  retainedMeetingId: string | null;
  isProcessing: boolean;
  isBusy: boolean;
  selectFile: () => Promise<AudioFileInfo | null>;
  validateFile: (path: string) => Promise<AudioFileInfo | null>;
  startImport: (
    sourcePath: string,
    title: string,
    language?: string | null,
    model?: string | null,
    provider?: string | null,
    cloudAuthorized?: boolean
  ) => Promise<void>;
  cancelImport: () => Promise<void>;
  reset: () => void;
}

export function useImportAudio({
  onComplete,
  onError,
}: UseImportAudioOptions = {}): UseImportAudioReturn {
  const [status, setStatus] = useState<ImportStatus>('idle');
  const [fileInfo, setFileInfo] = useState<AudioFileInfo | null>(null);
  const [progress, setProgress] = useState<ImportProgress | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [retainedMeetingId, setRetainedMeetingId] = useState<string | null>(null);
  const [activeJobId, setActiveJobId] = useState<string | null>(null);
  const jobId = useRef<string | null>(null);

  // Stable refs for callbacks to avoid listener re-registration on every render
  const onCompleteRef = useRef(onComplete);
  const onErrorRef = useRef(onError);
  useEffect(() => { onCompleteRef.current = onComplete; }, [onComplete]);
  useEffect(() => { onErrorRef.current = onError; }, [onError]);

  // Read the same task state as the recordings center so a missed event cannot
  // leave progress or completion stuck in this dialog.
  useEffect(() => {
    if (!activeJobId) return;
    let disposed = false;
    let timer: ReturnType<typeof setTimeout>;
    const isCurrent = () => !disposed && jobId.current === activeJobId;

    const refresh = async () => {
      let task: (TranscriptionTask & { import_result?: ImportResult | null }) | undefined;
      try {
        const rows = await invoke<(TranscriptionTask & { import_result?: ImportResult | null })[]>('list_transcription_tasks');
        task = rows.find(row => row.job_id === activeJobId);
      } catch {
        // A transient read failure does not reflect the state of the import.
      }
      if (!isCurrent()) return;

      if (task?.status === 'complete' && task.import_result) {
        const result = task.import_result;
        void Analytics.track('import_audio_completed', {
          success: 'true',
          duration_seconds: result.duration_seconds.toString(),
          segments_count: result.segments_count.toString(),
        }).catch(() => {});
        try {
          await applyPinnedSummaryLanguageToMeeting(result.meeting_id);
        } catch {
          if (isCurrent()) toast.warning('逐字稿已儲存，預設摘要語言未能套用。');
        }
        if (!isCurrent()) return;
        jobId.current = null;
        setActiveJobId(null);
        setStatus('complete');
        setProgress(null);
        onCompleteRef.current?.(result);
        return;
      }

      if (task && ['failed', 'cancelled'].includes(task.status)) {
        jobId.current = null;
        setActiveJobId(null);
        setProgress(null);
        setRetainedMeetingId(task.meeting_id);
        setStatus('error');
        setError(task.message);
        if (task.status === 'failed') {
          void Analytics.trackError('import_audio_failed', task.message).catch(() => {});
          onErrorRef.current?.(task.message);
        }
        return;
      }

      if (task) setProgress(task);
      timer = setTimeout(refresh, 1000);
    };

    void refresh();
    return () => {
      disposed = true;
      clearTimeout(timer);
    };
  }, [activeJobId]);

  // Select file using native file dialog
  const selectFile = useCallback(async (): Promise<AudioFileInfo | null> => {
    setStatus('validating');
    setError(null);

    try {
      const result = await invoke<AudioFileInfo | null>('select_and_validate_audio_command');
      if (result) {
        setFileInfo(result);
        setStatus('idle');
        return result;
      } else {
        // User cancelled
        setStatus('idle');
        return null;
      }
    } catch (err: any) {
      setStatus('error');
      const errorMsg = typeof err === 'string' ? err : (err?.message || String(err) || 'Failed to validate file');
      setError(errorMsg);
      onErrorRef.current?.(errorMsg);
      return null;
    }
  }, []);

  // Validate a file from a given path (for drag-drop)
  const validateFile = useCallback(async (path: string): Promise<AudioFileInfo | null> => {
    setStatus('validating');
    setError(null);

    try {
      const result = await invoke<AudioFileInfo>('validate_audio_file_command', { path });
      setFileInfo(result);
      setStatus('idle');
      return result;
    } catch (err: any) {
      setStatus('error');
      const errorMsg = typeof err === 'string' ? err : (err?.message || String(err) || 'Failed to validate file');
      setError(errorMsg);
      onErrorRef.current?.(errorMsg);
      return null;
    }
  }, []);

  // Start the import process
  const startImport = useCallback(
    async (
      sourcePath: string,
      title: string,
      language?: string | null,
      model?: string | null,
      provider?: string | null,
    cloudAuthorized?: boolean
    ) => {
      if (jobId.current) return;
      const requestId = crypto.randomUUID();
      jobId.current = requestId;
      setActiveJobId(requestId);
      setRetainedMeetingId(null);
      setStatus('processing');
      setError(null);
      setProgress(null);

      try {
        if (fileInfo) {
          void Analytics.track('import_audio_started', {
            file_size_bytes: fileInfo.size_bytes.toString(),
            duration_seconds: fileInfo.duration_seconds.toString(),
            language: language || 'auto',
            model_provider: provider || '',
            model_name: model || ''
          }).catch(() => {});
        }

        await invoke('start_import_audio_command', {
          requestId,
          sourcePath,
          title,
          language: language || null,
          model: model || null,
          provider: provider || null,
          cloudAuthorized: cloudAuthorized === true,
        });
      } catch (err: any) {
        if (jobId.current !== requestId) return;
        jobId.current = null;
        setActiveJobId(null);
        setStatus('error');
        const errorMsg = typeof err === 'string' ? err : (err?.message || String(err) || 'Failed to start import');
        setError(errorMsg);

        void Analytics.trackError('import_audio_failed', errorMsg).catch(() => {});

        onErrorRef.current?.(errorMsg);
      }
    },
    [fileInfo]
  );

  // Cancel ongoing import
  const cancelImport = useCallback(async () => {
    const id = jobId.current;
    try {
      if (!id) return;
      await invoke('cancel_transcription_task', { jobId: id });
      if (jobId.current !== id) return;
      jobId.current = null;
      setActiveJobId(null);
      setStatus('idle');
      setProgress(null);
    } catch (err: any) {
      console.error('Failed to cancel import:', err);
    }
  }, []);

  // Reset all state
  const reset = useCallback(() => {
    jobId.current = null;
    setActiveJobId(null);
    setRetainedMeetingId(null);
    setStatus('idle');
    setFileInfo(null);
    setProgress(null);
    setError(null);
  }, []);

  return {
    status,
    fileInfo,
    progress,
    error,
    retainedMeetingId,
    isProcessing: status === 'processing',
    isBusy: status === 'processing' || status === 'validating',
    selectFile,
    validateFile,
    startImport,
    cancelImport,
    reset,
  };
}
