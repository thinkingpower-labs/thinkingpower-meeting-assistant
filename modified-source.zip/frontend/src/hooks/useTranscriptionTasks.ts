import { useEffect, useState } from 'react';
import { invoke } from '@tauri-apps/api/core';
export type TranscriptionTask = {
  job_id:string; meeting_id:string|null; title:string; provider:string; model:string|null;
  status:string;stage:string;progress_percentage:number;completed:number;total:number;message:string;created_at:number;
};
export const isActiveTask = (task:TranscriptionTask) => ['queued','running','cancelling'].includes(task.status);
export function useTranscriptionTasks(){
  const [tasks,setTasks]=useState<TranscriptionTask[]>([]);
  const [error,setError]=useState('');
  useEffect(()=>{
    let active=true, pending=false;
    const refresh=async()=>{
      if(pending)return;pending=true;
      try{const rows=await invoke<TranscriptionTask[]>('list_transcription_tasks');if(active&&Array.isArray(rows)){setTasks(rows);setError('');}}
      catch{if(active)setError('無法更新轉錄進度，請稍後重試');}
      finally{pending=false;}
    };
    void refresh();const timer=setInterval(refresh,1500);
    return()=>{active=false;clearInterval(timer);};
  },[]);
  return {tasks,error};
}
