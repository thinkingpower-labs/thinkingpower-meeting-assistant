'use client';
import { useState } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { toast } from 'sonner';

export function ExportTranscript({ meetingId }: { meetingId: string }) {
  const [busy, setBusy] = useState(false);
  async function exportFile(format: 'txt' | 'md') {
    setBusy(true);
    try {
      const result = await invoke<string | null>('flybird_export_transcript', { meetingId, format });
      if (result) toast.success('逐字稿已匯出', { description: result });
    } catch (e) { toast.error('匯出未完成', { description: String(e) }); }
    finally { setBusy(false); }
  }
  return <div className="flex gap-2 px-4 py-2 border-b bg-white">
    <button disabled={busy} onClick={() => exportFile('txt')} className="border rounded px-3 py-1 disabled:opacity-50">匯出完整逐字稿 TXT</button>
    <button disabled={busy} onClick={() => exportFile('md')} className="border rounded px-3 py-1 disabled:opacity-50">匯出 Markdown</button>
  </div>;
}
