'use client';
import { useEffect, useState } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { TextModelPicker } from './TextModelPicker';
import { toast } from 'sonner';

export interface ModelConfig {
  provider: 'ollama' | 'groq' | 'claude' | 'gemini' | 'openai' | 'openrouter' | 'builtin-ai' | 'custom-openai';
  model: string; whisperModel: string; apiKey?: string | null; ollamaEndpoint?: string | null;
  customOpenAIEndpoint?: string | null; customOpenAIModel?: string | null; customOpenAIApiKey?: string | null;
  maxTokens?: number | null; temperature?: number | null; topP?: number | null;
}
type Connection = {provider: ModelConfig['provider']; endpoint: string; text_model: string; audio_model: string; text_verified: boolean; audio_verified: boolean};
type Entry = {connection: Connection; has_key: boolean};
const names: Record<string,string> = {'builtin-ai':'內建 AI（離線）',ollama:'Ollama',groq:'Groq',claude:'Claude',gemini:'Google Gemini',openai:'OpenAI',openrouter:'OpenRouter','custom-openai':'自訂伺服器（OpenAI 相容）'};

export function ModelSettingsModal({modelConfig, setModelConfig, onSave}: {
  modelConfig: ModelConfig;
  setModelConfig: (config: ModelConfig | ((prev: ModelConfig) => ModelConfig)) => void;
  onSave: (config: ModelConfig) => void;
  skipInitialFetch?: boolean; layout?: 'inline' | 'dialog';
}) {
  const [provider,setProvider] = useState(modelConfig.provider);
  const [model,setModel] = useState(modelConfig.model);
  const [entries,setEntries] = useState<Entry[]>([]);
  const [key,setKey] = useState('');
  const [endpoint,setEndpoint] = useState('');
  const [busy,setBusy] = useState(false);
  const entry = entries.find(e=>e.connection.provider===provider);
  const requiresKey = !['builtin-ai','ollama','custom-openai'].includes(provider);
  useEffect(()=>{
    let active=true;
    invoke<Entry[]>('ai_get_connections').then(data=>{if(active)setEntries(data);}).catch(()=>toast.error('無法讀取已儲存的服務連線'));
    return ()=>{active=false;};
  },[]);
  useEffect(()=>{setEndpoint(entry?.connection.endpoint || '');},[entry]);
  function changeProvider(value: ModelConfig['provider']) {
    setProvider(value);setKey('');
    setModel(value===modelConfig.provider ? modelConfig.model : entries.find(e=>e.connection.provider===value)?.connection.text_model || '');
  }
  async function save() {
    if(!entry)return;
    setBusy(true);
    try {
      if (provider === 'builtin-ai') await invoke('builtin_ai_prepare_model', {modelName: model});
      const config={...entry.connection,endpoint,text_model:model.trim()};
      await invoke('ai_save_connection',{config,apiKey:key.trim() || null});
      const updated:ModelConfig={...modelConfig,provider,model:model.trim(),apiKey:null,customOpenAIApiKey:null,
        ollamaEndpoint:provider==='ollama'?endpoint.replace(/\/v1\/?$/,''):null,
        customOpenAIEndpoint:provider==='custom-openai'?endpoint:null,
        customOpenAIModel:provider==='custom-openai'?model.trim():null};
      await invoke('api_save_model_config',{provider,model:updated.model,whisperModel:updated.whisperModel,apiKey:null,ollamaEndpoint:updated.ollamaEndpoint});
      setKey('');setModelConfig(updated);
      const {emit}=await import('@tauri-apps/api/event');
      await emit('model-config-updated',updated);
      await onSave(updated);
    }catch(e){toast.error('摘要設定未完成',{description:String(e)});}
    finally{setBusy(false);}
  }
  return <div className="space-y-4">
    <p className="text-sm text-gray-600">與設定頁共用服務連線；已儲存的 Key 不需重填。此處只設定逐字稿的摘要服務。</p>
    <label className="block">摘要服務<select className="border rounded p-2 w-full" value={provider} onChange={e=>changeProvider(e.target.value as ModelConfig['provider'])}>{Object.entries(names).map(([id,name])=><option key={id} value={id}>{name}</option>)}</select></label>
    {provider!=='builtin-ai'&&<label className="block">伺服器網址<Input value={endpoint} readOnly={!['ollama','custom-openai'].includes(provider)} onChange={e=>setEndpoint(e.target.value)}/></label>}
    <div>摘要文字模型<TextModelPicker provider={provider} value={model} onChange={setModel}/></div>
    {provider!=='builtin-ai'&&<label className="block">API Key{entry?.has_key?'（已安全儲存，不必重填）':requiresKey?'（尚未設定）':'（可不填）'}<Input type="password" autoComplete="off" value={key} onChange={e=>setKey(e.target.value)} placeholder={entry?.has_key?'留空保留，輸入新值可更換':'輸入此服務的 Key'}/></label>}
    <p className="text-sm text-gray-600">摘要失敗時可只重新產生摘要，原始錄音與逐字稿會保留。本機模型可直接在上方下載；儲存時會載入檢查。</p>
    <Button disabled={busy||!entry||!model.trim()||(requiresKey&&!entry.has_key&&!key.trim())} onClick={()=>void save()}>{busy?'儲存中…':'儲存'}</Button>
  </div>;
}
