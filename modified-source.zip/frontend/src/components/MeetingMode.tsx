'use client';

import { useConfig } from '@/contexts/ConfigContext';
import { useState } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { toast } from 'sonner';
import type { RecordingPreferences } from './RecordingSettings';
import { useRecordingState, RecordingStatus } from '@/contexts/RecordingStateContext';
import { ScreenRecordingOptions } from './ScreenRecordingOptions';

export function MeetingMode() {
  const { selectedDevices, setSelectedDevices } = useConfig();
  const { status } = useRecordingState();
  const [saving, setSaving] = useState(false);
  const inPerson = selectedDevices.systemDevice === '__disabled__';
  const locked = saving || (status !== RecordingStatus.IDLE && status !== RecordingStatus.ERROR);
  const selectMode = async (systemDevice: string | null) => {
    setSaving(true);
    try {
      const prefs = await invoke<RecordingPreferences>('get_recording_preferences');
      await invoke('set_recording_preferences', { preferences: {
        ...prefs, preferred_mic_device: selectedDevices.micDevice,
        preferred_system_device: systemDevice,
      } });
      setSelectedDevices({ ...selectedDevices, systemDevice });
    } catch { toast.error('會議模式儲存失敗，請重試。'); }
    finally { setSaving(false); }
  };
  return <section className="border-b bg-white px-6 py-3" aria-label="會議錄音模式">
    <div className="flex items-center gap-3">
      <strong>會議模式</strong>
      <button type="button" disabled={locked} aria-pressed={!inPerson}
        className={`rounded-lg border px-3 py-2 disabled:opacity-50 ${!inPerson ? 'bg-blue-50 border-blue-500' : ''}`}
        onClick={() => selectMode(null)}>線上會議</button>
      <button type="button" disabled={locked} aria-pressed={inPerson}
        className={`rounded-lg border px-3 py-2 disabled:opacity-50 ${inPerson ? 'bg-blue-50 border-blue-500' : ''}`}
        onClick={() => selectMode('__disabled__')}>實體會議</button>
    </div>
    <p className="mt-2 text-sm text-gray-600">{inPerson
      ? '只錄麥克風。請將收音設備靠近與會者，並確認現場已知悉錄音。'
      : '錄製麥克風與電腦播放聲音。建議戴耳機；其他程式的提示音也可能錄入。'}</p>
    <ScreenRecordingOptions locked={locked} inPerson={inPerson} />
  </section>;
}
