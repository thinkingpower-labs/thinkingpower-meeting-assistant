'use client';

import { invoke } from '@tauri-apps/api/core';
import { useEffect, useState } from 'react';

type Signal = 'signal' | 'quiet' | 'no_input' | 'unavailable';
type CaptureStatus = {
  microphone: Signal;
  system: Signal;
  microphone_device: string | null;
  system_device: string | null;
};
type AudioDevice = { name: string; device_type: 'Input' | 'Output' };

const labels: Record<Signal, string> = {
  signal: '有收音訊號',
  quiet: '訊號偏低或目前安靜',
  no_input: '尚未收到音訊',
  unavailable: '裝置未開啟',
};

function SourceStatus({ label, device, signal }: { label: string; device: string | null; signal: Signal }) {
  return <div className="flex flex-wrap items-baseline gap-x-2">
    <strong>{label}</strong>
    <span className={signal === 'signal' ? 'text-green-800' : 'text-amber-800'}>{labels[signal]}</span>
    {device && <span className="break-all text-xs text-slate-600">{device}</span>}
  </div>;
}

export function OnlineAudioCapture({ micDevice, systemDevice, locked, recording, paused, onOutputChange }: {
  micDevice: string | null;
  systemDevice: string | null;
  locked: boolean;
  recording: boolean;
  paused: boolean;
  onOutputChange: (device: string | null) => Promise<void>;
}) {
  const [devices, setDevices] = useState<string[]>([]);
  const [testResult, setTestResult] = useState<CaptureStatus | null>(null);
  const [liveResult, setLiveResult] = useState<CaptureStatus | null>(null);
  const [testing, setTesting] = useState(false);
  const [error, setError] = useState('');

  const refreshDevices = async () => {
    try {
      const available = await invoke<AudioDevice[]>('get_audio_devices');
      setDevices([...new Set(available.filter(device => device.device_type === 'Output').map(device => device.name))]);
      setError('');
    } catch {
      setError('無法讀取播放裝置。請檢查 Windows 音效設定。');
    }
  };

  useEffect(() => { void refreshDevices(); }, []);

  useEffect(() => {
    setTestResult(null);
  }, [micDevice, systemDevice]);

  useEffect(() => {
    if (!recording || paused) {
      setLiveResult(null);
      return;
    }
    let disposed = false;
    let timer: ReturnType<typeof setTimeout>;
    const refresh = async () => {
      try {
        const result = await invoke<CaptureStatus | null>('get_online_capture_status');
        if (!disposed) setLiveResult(result);
      } catch {
        if (!disposed) setLiveResult(null);
      }
      if (!disposed) timer = setTimeout(refresh, 1000);
    };
    void refresh();
    return () => {
      disposed = true;
      clearTimeout(timer);
    };
  }, [recording, paused]);

  const testCapture = async () => {
    setTesting(true);
    setError('');
    setTestResult(null);
    try {
      setTestResult(await invoke<CaptureStatus>('test_online_capture', {
        micDeviceName: micDevice,
        systemDeviceName: systemDevice,
      }));
    } catch (error) {
      setError(String(error));
    } finally {
      setTesting(false);
    }
  };

  const selected = systemDevice ?? '';
  const isListed = devices.some(name => name + ' (output)' === selected);
  const result = recording ? liveResult : testResult;

  return <div className="mt-3 space-y-2 rounded-lg bg-slate-50 p-3 text-sm" aria-label="線上會議收音">
    <div className="flex flex-wrap items-center gap-2">
      <label htmlFor="meeting-audio-output" className="font-medium">會議播放裝置</label>
      <select id="meeting-audio-output" className="max-w-md rounded border bg-white p-2"
        value={selected} disabled={locked || testing}
        onChange={event => void onOutputChange(event.target.value || null)}>
        <option value="">Windows 預設播放裝置</option>
        {selected && !isListed && <option value={selected}>{selected.replace(/ \(output\)$/, '')}（未列出）</option>}
        {devices.map(name => <option key={name} value={name + ' (output)'}>{name}</option>)}
      </select>
      <button type="button" disabled={locked || testing} className="rounded border px-3 py-2 disabled:opacity-50"
        onClick={() => void refreshDevices()}>重新整理裝置</button>
      <button type="button" disabled={locked || testing} className="rounded border px-3 py-2 disabled:opacity-50"
        onClick={() => void testCapture()}>{testing ? '試收中…' : '試收 5 秒'}</button>
    </div>
    <p className="text-slate-600">選擇和 Teams、Meet 或 Zoom 一樣的喇叭或耳機。試收時請說話，並讓會議軟體播放聲音。試收只顯示訊號狀態。</p>
    {testing && <p role="status">正在試收麥克風和電腦播放聲音。請在這 5 秒內讓兩路都有聲音。</p>}
    {recording && !paused && !result && <p role="status">正在讀取收音狀態…</p>}
    {paused && <p role="status">錄音已暫停</p>}
    {result && !paused && <div aria-live="polite" className="space-y-1">
      <p className="font-medium">{recording ? '近 3 秒收音狀態' : '試收結果'}</p>
      <SourceStatus label="麥克風" device={result.microphone_device} signal={result.microphone} />
      <SourceStatus label="電腦播放" device={result.system_device} signal={result.system} />
    </div>}
    {error && <p role="alert" className="text-red-700">{error}</p>}
  </div>;
}
