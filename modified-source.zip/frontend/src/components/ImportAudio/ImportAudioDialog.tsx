import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import {
  Upload,
  Globe,
  Loader2,
  AlertCircle,
  CheckCircle2,
  X,
  Cpu,
  FileAudio,
  Clock,
  HardDrive,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '../ui/dialog';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../ui/select';
import { toast } from 'sonner';
import { serviceNames } from '../AIWorkflowSettings';
import { grantSummary, summaryUsesNetwork } from '@/lib/cloud-consent';
import { useConfig } from '@/contexts/ConfigContext';
import { useImportAudio, ImportResult } from '@/hooks/useImportAudio';
import { useRouter } from 'next/navigation';
import { useSidebar } from '../Sidebar/SidebarProvider';
import { LANGUAGES } from '@/constants/languages';
import { useTranscriptionModels, ModelOption } from '@/hooks/useTranscriptionModels';
import type { ModelConfig } from '../ModelSettingsModal';


interface ImportAudioDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  preselectedFile?: string | null;
  onComplete?: () => void;
}

function formatDuration(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);

  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }
  return `${minutes}:${secs.toString().padStart(2, '0')}`;
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(1)} GB`;
}

export function ImportAudioDialog({
  open,
  onOpenChange,
  preselectedFile,
  onComplete,
}: ImportAudioDialogProps) {
  const router = useRouter();
  const { refetchMeetings } = useSidebar();
  const { selectedLanguage, transcriptModelConfig, modelConfig, isAutoSummary } = useConfig();

  const [title, setTitle] = useState('');
  const [cloudAccepted, setCloudAccepted] = useState(false);
  const [selectedLang, setSelectedLang] = useState(selectedLanguage || 'auto');
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [titleModifiedByUser, setTitleModifiedByUser] = useState(false);

  // Always start as false — represents "dialog has not yet been opened".
  // Do NOT initialize from the `open` prop: if the component mounts with open=true
  // (e.g. drag-drop path), we still need the initialization effect to run.
  const prevOpenRef = useRef(false);
  const workflowRef = useRef<{autoSummary: boolean; consent: boolean; summary: ModelConfig} | null>(null);

  // Use centralized model fetching hook
  const {
    availableModels,
    selectedModelKey,
    setSelectedModelKey,
    loadingModels,
    fetchModels,
    resetSelection,
  } = useTranscriptionModels(transcriptModelConfig, true);

  const handleImportComplete = useCallback((result: ImportResult) => {
    const workflow = workflowRef.current;
    if (workflow?.autoSummary && workflow.consent) grantSummary(result.meeting_id, workflow.summary);
    toast.success(`逐字稿已儲存，共 ${result.segments_count} 段。`);

    // Refresh meetings list then navigate to the imported meeting
    refetchMeetings();
    onComplete?.();
    if (!open) return;
    onOpenChange(false);
    router.push(`/meeting-details?id=${result.meeting_id}${workflow?.autoSummary ? "&source=workflow" : ""}`);
  }, [router, refetchMeetings, onComplete, onOpenChange, isAutoSummary, cloudAccepted, modelConfig, open]);

  const handleImportError = useCallback((error: string) => {
    toast.error('處理失敗', { description: error });
  }, []);

  const {
    status,
    fileInfo,
    progress,
    error,
    retainedMeetingId,
    isProcessing,
    isBusy,
    selectFile,
    validateFile,
    startImport,
    cancelImport,
    reset,
  } = useImportAudio({
    onComplete: handleImportComplete,
    onError: handleImportError,
  });

  // Reset state only when dialog transitions from closed to open
  // This prevents re-initialization when config changes while dialog is already open (Bug #4 & #5)
  useEffect(() => {
    const wasOpen = prevOpenRef.current;
    prevOpenRef.current = open;

    // Only initialize when transitioning from closed (false) to open (true)
    if (open && !wasOpen) {
      reset();
      resetSelection();
      setTitle('');
      setTitleModifiedByUser(false);
      setSelectedLang(selectedLanguage || 'auto');
      setShowAdvanced(false);
      setCloudAccepted(false);

      // Validate preselected file if provided
      if (preselectedFile) {
        validateFile(preselectedFile).then((info) => {
          if (info) {
            setTitle(info.filename);
          }
        });
      }

      // Fetch available models using centralized hook
      fetchModels();
    }
  }, [open, preselectedFile, selectedLanguage, transcriptModelConfig, reset, resetSelection, validateFile, fetchModels]);

  // Update title when fileInfo changes
  useEffect(() => {
    if (fileInfo && !title && !titleModifiedByUser) {
      setTitle(fileInfo.filename);
    }
  }, [fileInfo, title, titleModifiedByUser]);

  const selectedModel = useMemo((): ModelOption | undefined => {
    if (!selectedModelKey) return undefined;
    const colonIndex = selectedModelKey.indexOf(':');
    if (colonIndex === -1) return undefined;
    const provider = selectedModelKey.slice(0, colonIndex);
    const name = selectedModelKey.slice(colonIndex + 1);
    return availableModels.find((m) => m.provider === provider && m.name === name);
  }, [selectedModelKey, availableModels]);
  const cloudAudio = !!selectedModel && !['whisper', 'parakeet'].includes(selectedModel.provider);
  const cloudSummary = isAutoSummary && summaryUsesNetwork(modelConfig);
  useEffect(() => setCloudAccepted(false), [selectedModelKey, modelConfig.provider, modelConfig.model, modelConfig.ollamaEndpoint, modelConfig.customOpenAIEndpoint, fileInfo?.path]);
  const isParakeetModel = selectedModel?.provider === 'parakeet';

  useEffect(() => {
    if (isParakeetModel && selectedLang !== 'auto') {
      setSelectedLang('auto');
    }
  }, [isParakeetModel, selectedLang]);

  const handleSelectFile = async () => {
    const info = await selectFile();
    if (info) {
      setTitle(info.filename);
    }
  };

  const handleStartImport = async () => {
    if (!fileInfo) return;
    workflowRef.current = {autoSummary: isAutoSummary, consent: cloudAccepted, summary: {...modelConfig, apiKey: null}};

    await startImport(
      fileInfo.path,
      title || fileInfo.filename,
      isParakeetModel ? null : selectedLang === 'auto' ? null : selectedLang,
      selectedModel?.name || null,
      selectedModel?.provider || null,
      cloudAccepted
    );
  };

  const handleCancel = async () => {
    if (isProcessing) {
      await cancelImport();
      toast.info('已要求取消；目前分段儲存後停止，原音及進度仍保留');
    }
    onOpenChange(false);
  };

  // Closing detaches the dialog; the backend task remains visible in the center.
  const handleOpenChange = (newOpen:boolean) => onOpenChange(newOpen);
  const handleEscapeKeyDown = (_event:KeyboardEvent) => {};
  const handleInteractOutside = (_event:Event) => {};

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent
        className="sm:max-w-[500px]"
        onEscapeKeyDown={handleEscapeKeyDown}
        onInteractOutside={handleInteractOutside}
      >
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {isProcessing ? (
              <>
                <Loader2 className="h-5 w-5 animate-spin text-blue-600" />
                正在處理音訊…
              </>
            ) : error ? (
              <>
                <AlertCircle className="h-5 w-5 text-red-600" />
                處理失敗
              </>
            ) : status === 'complete' ? (
              <>
                <CheckCircle2 className="h-5 w-5 text-green-600" />
                逐字稿已完成
              </>
            ) : (
              <>
                <Upload className="h-5 w-5 text-blue-600" />
                匯入音檔
              </>
            )}
          </DialogTitle>
          <DialogDescription>
            {isProcessing
              ? progress?.message || '正在處理音訊…'
              : error
              ? '處理未完成；已保留的原音與進度不會刪除'
              : '選擇音檔，保存原音後產生逐字稿與摘要'}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* File selection / info */}
          {!isProcessing && !error && (
            <>
              {fileInfo ? (
                <div className="bg-gray-50 rounded-lg p-4 space-y-3">
                  <div className="flex items-start gap-3">
                    <FileAudio className="h-8 w-8 text-blue-600 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-900 truncate">{fileInfo.filename}</p>
                      <div className="flex items-center gap-4 text-sm text-gray-500 mt-1">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3.5 w-3.5" />
                          {formatDuration(fileInfo.duration_seconds)}
                        </span>
                        <span className="flex items-center gap-1">
                          <HardDrive className="h-3.5 w-3.5" />
                          {formatFileSize(fileInfo.size_bytes)}
                        </span>
                        <span className="text-blue-600 font-medium">{fileInfo.format}</span>
                      </div>
                    </div>
                  </div>

                  {/* Editable title */}
                  <div className="space-y-1">
                    <label className="text-sm font-medium text-gray-700">會議名稱</label>
                    <Input
                      value={title}
                      onChange={(e) => {
                        setTitle(e.target.value);
                        setTitleModifiedByUser(true);
                      }}
                      placeholder="輸入會議名稱"
                    />
                  </div>

                  <Button variant="outline" size="sm" onClick={handleSelectFile} className="w-full">
                    更換音檔
                  </Button>
                </div>
              ) : (
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                  <FileAudio className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <Button onClick={handleSelectFile} disabled={status === 'validating'}>
                    {status === 'validating' ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        正在檢查…
                      </>
                    ) : (
                      <>
                        <Upload className="h-4 w-4 mr-2" />
                        選擇音檔
                      </>
                    )}
                  </Button>
                  <p className="text-sm text-gray-500 mt-2">MP4, WAV, MP3, FLAC, OGG, MKV, WebM, WMA</p>
                </div>
              )}

              {/* Advanced options (collapsible) */}
              {fileInfo && (
                <div className="border rounded-lg">
                  <button
                    onClick={() => setShowAdvanced(!showAdvanced)}
                    className="w-full flex items-center justify-between p-3 text-sm font-medium text-gray-700 hover:bg-gray-50"
                  >
                    <span>語言與轉錄模型</span>
                    {showAdvanced ? (
                      <ChevronUp className="h-4 w-4" />
                    ) : (
                      <ChevronDown className="h-4 w-4" />
                    )}
                  </button>

                  {showAdvanced && (
                    <div className="p-3 pt-0 space-y-4 border-t">
                      {/* Language selector */}
                      {!isParakeetModel ? (
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <Globe className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm font-medium">語言</span>
                          </div>
                          <Select value={selectedLang} onValueChange={setSelectedLang}>
                            <SelectTrigger className="w-full">
                              <SelectValue placeholder="選擇語言" />
                            </SelectTrigger>
                            <SelectContent className="max-h-60">
                              {LANGUAGES.map((lang) => (
                                <SelectItem key={lang.code} value={lang.code}>
                                  {lang.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <Globe className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm font-medium">語言</span>
                          </div>
                          <p className="text-xs text-muted-foreground">
                            Parakeet 會自動辨識語言，無須另選語言。
                          </p>
                        </div>
                      )}

                      {/* Model selector */}
                      {availableModels.length > 0 && (
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <Cpu className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm font-medium">模型</span>
                          </div>
                          <Select
                            value={selectedModelKey}
                            onValueChange={setSelectedModelKey}
                            disabled={loadingModels}
                          >
                            <SelectTrigger className="w-full">
                              <SelectValue placeholder={loadingModels ? '載入模型…' : '選擇模型'} />
                            </SelectTrigger>
                            <SelectContent>
                              {availableModels.map((model) => (
                                <SelectItem
                                  key={`${model.provider}:${model.name}`}
                                  value={`${model.provider}:${model.name}`}
                                >
                                  {model.displayName}{model.size_mb > 0 ? ` (${Math.round(model.size_mb)} MB)` : "（雲端）"}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </>
          )}

          {!isProcessing && fileInfo && <div className="bg-blue-50 p-3 rounded text-sm space-y-2">
            <p>原始音檔會先保存到本機。語音轉逐字稿：{serviceNames[selectedModel?.provider || ''] || selectedModel?.provider}／{selectedModel?.name}。</p>
            <p>{isAutoSummary ? `逐字稿將交由 ${serviceNames[modelConfig.provider]}／${modelConfig.model} 產生摘要。` : '自動摘要未開啟；完成後可手動產生。'}</p>
            {cloudAudio && <p>{selectedModel?.provider === 'openai' ? `轉錄預估 US$${(fileInfo.duration_seconds / 60 * (selectedModel.name === 'gpt-4o-mini-transcribe' ? 0.003 : 0.006)).toFixed(4)}` : selectedModel?.provider === 'groq' ? `轉錄預估 US$${(Math.max(10, fileInfo.duration_seconds) / 3600 * (selectedModel.name === 'whisper-large-v3-turbo' ? 0.04 : 0.111)).toFixed(4)}` : '此服務尚無可靠的自動估價，請先查閱服務商價格。'}。價格查核：2026-10-15；以美元估算，USD/USD＝1，未換算台幣。分段及最低計費單位可能使帳單不同。</p>}
            {(cloudAudio || cloudSummary) && <><p>轉錄、摘要分別計費；摘要依文字輸入／輸出 token 計費，目前未提供可靠金額。重試可能增加費用。ChatGPT 訂閱不包含 API 用量。</p><label className="flex gap-2"><input type="checkbox" checked={cloudAccepted} onChange={e => setCloudAccepted(e.target.checked)}/>我同意僅將本次音訊／逐字稿傳送至上述服務，並了解可能產生費用。</label></>}
          </div>}
          {/* Progress display */}
          {isProcessing && progress && (
            <div className="space-y-2">
              <div className="relative">
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div
                    className="bg-blue-600 h-3 rounded-full transition-all duration-300 ease-out"
                    style={{ width: `${Math.min(progress.progress_percentage, 100)}%` }}
                  />
                </div>
                <div className="flex justify-between text-xs text-gray-600 mt-1">
                  <span>{{copying: '保留原音', decoding: '讀取音訊', preparing: '音訊分段', vad: '音訊分段', transcribing: '轉錄中', uploading: '上傳中', saving: '儲存中', complete: '完成'}[progress.stage] || '處理中'}</span>
                  <span>{Math.round(progress.progress_percentage)}%</span>
                </div>
              </div>
              <p className="text-sm text-muted-foreground text-center">{progress.message}</p>
            </div>
          )}

          {/* Error display */}
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3">
              <p className="text-sm text-red-800">{error}</p>
            </div>
          )}
        </div>

        <DialogFooter>
          {!isProcessing && !error && (
            <>
              <Button variant="outline" onClick={() => onOpenChange(false)}>
                取消
              </Button>
              <Button
                onClick={handleStartImport}
                className="bg-blue-600 hover:bg-blue-700"
                disabled={!fileInfo || !selectedModel || ((cloudAudio || cloudSummary) && !cloudAccepted)}
              >
                <Upload className="h-4 w-4 mr-2" />
                開始處理
              </Button>
            </>
          )}
          {isProcessing && <Button variant="outline" onClick={()=>{onOpenChange(false);router.push('/recordings');}}>背景繼續／查看工作</Button>}
          {isProcessing && (
            <Button variant="outline" onClick={handleCancel}>
              <X className="h-4 w-4 mr-2" />
              取消
            </Button>
          )}
          {error && (
            <>
              <Button variant="outline" onClick={() => onOpenChange(false)}>
                關閉
              </Button>
              <Button onClick={() => {
                if (retainedMeetingId) { refetchMeetings(); onOpenChange(false); router.push(`/meeting-details?id=${retainedMeetingId}`); }
                else reset();
              }} variant="outline">
                {retainedMeetingId ? '開啟已保存會議並接續' : '重新選擇音檔'}
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
