'use client';
import { useEffect, useRef, useState } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { BuiltInModelManager } from './BuiltInModelManager';
import { textModelPresets } from '@/lib/text-model-presets';

export function TextModelPicker({provider, value, onChange, revision = 0}: {provider: string; value: string; onChange: (value: string) => void; revision?: number}) {
  const [models, setModels] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [confirmed, setConfirmed] = useState(false);
  const [manual, setManual] = useState(false);
  const presets = textModelPresets[provider] || [];
  const choices = confirmed ? models : presets.map(m => m.id);
  const label = (id: string) => presets.find(m => m.id === id)?.label || id;
  const generation = useRef(0);
  async function load() {
    const id = ++generation.current;
    setLoading(true); setError(''); setModels([]); setConfirmed(false);
    try {
      const data = provider === 'builtin-ai'
        ? (await invoke<{name: string; status: {type?: string}}[]>('builtin_ai_list_models')).filter(m => m.status?.type === 'available').map(m => m.name)
        : await invoke<string[]>('ai_list_text_models', {provider});
      if (id !== generation.current) return;
      setModels(data);
      setConfirmed(true);
      if (!data.length) setError('尚無可用模型；本機模型請先下載，或手動輸入完整模型 ID。');
    } catch (e) { if (id === generation.current) setError(String(e)); }
    finally { if (id === generation.current) setLoading(false); }
  }
  useEffect(() => { void load(); return () => { ++generation.current; }; }, [provider, revision]);
  if (provider === 'builtin-ai') return <div className="space-y-2">
    <p className="text-sm">完整會議紀錄請選 Qwen 3.5 4B（約 2.6 GB）。下載後按儲存，程式會實際載入並檢查；首次載入可能需要幾分鐘。</p>
    <BuiltInModelManager selectedModel={value} onModelSelect={onChange}/>
  </div>;
  return <div className="space-y-2">
    <div className="flex gap-2"><select aria-label="選擇文字模型" className="border rounded p-2 w-full" value={value || ''} onChange={e => {if(e.target.value) onChange(e.target.value);}} disabled={loading && !choices.length}>
      <option value="">{loading && !choices.length ? '正在載入模型…' : '請直接選擇文字模型'}</option>
      {value && !choices.includes(value) && <option value={value}>既有設定：{value}（未列於目前清單）</option>}
      <optgroup label={confirmed ? '服務回傳的模型清單' : '常用選項（尚未核對帳號權限）'}>
        {choices.map(model => <option key={model} value={model}>{label(model)}</option>)}
      </optgroup>
    </select><button type="button" className="border rounded px-3 whitespace-nowrap" disabled={loading} onClick={() => void load()}>重新載入</button></div>
    <button type="button" className="text-sm underline" aria-expanded={manual} onClick={() => setManual(!manual)}>進階：手動輸入模型 ID</button>
    {manual && <input aria-label="文字模型 ID" className="border rounded p-2 w-full" value={value} placeholder="僅自訂模型或特殊部署需要手動輸入" onChange={e => onChange(e.target.value)}/>}
    {error && <p role="status" className="text-sm text-amber-800">{presets.length ? '已先列出常用模型，可直接選擇；請儲存 API Key 後確認帳號可用清單。' : error}</p>}
    {provider === 'builtin-ai' && <p className="text-sm text-gray-600">完整會議紀要建議選 Qwen 3.5 4B。若原設定為 2B，已有完整 4B 時會自動使用 4B 並提示；未下載時會請你先下載，避免把未通過測試的 2B 紀要當成完成。</p>}
    <p className="text-xs text-gray-600">儲存服務後會自動更新模型清單。常用選項不代表你的帳號已有使用權限，也不代表摘要呼叫已驗證；摘要仍按服務計費。</p>
  </div>;
}
