'use client';
import {useEffect,useState} from 'react';
import {invoke,convertFileSrc} from '@tauri-apps/api/core';
import {useImportDialog} from '@/contexts/ImportDialogContext';
import {Button} from './ui/button';
import {toast} from 'sonner';
type Item={folder:string;name:string;status:string;chunks:number};
export function InterruptedRecordings({search='',onListen}:{search?:string;onListen?:(path:string,title:string)=>void}={}){
  const [items,setItems]=useState<Item[]>([]);
  const [busy,setBusy]=useState<string|null>(null);
  const [preview,setPreview]=useState<{name:string;url:string}|null>(null);
  const {openImportDialog}=useImportDialog();
  const refresh=()=>invoke<Item[]>('list_interrupted_recordings').then(setItems).catch(()=>toast.error('無法檢查未完成錄音，請至錄音資料夾保留原音'));
  useEffect(()=>{void refresh();},[]);
  const visible=items.filter(item=>item.name.toLocaleLowerCase().includes(search.toLocaleLowerCase()));
  if(!visible.length)return null;
  return <section className="mx-6 mt-4 p-4 border border-amber-300 bg-amber-50 rounded-lg" aria-label="未完成錄音復原">
    <h2 className="font-semibold">找到未完成的錄音</h2>
    <p className="text-sm">原音及分段仍保留。先檢查／復原，再由你確認是否轉錄；不會自動上傳。若會議已存在，請優先從原會議重新轉錄，避免重複建立。</p>
    {preview&&<div className="mt-3"><p>{preview.name}</p><audio key={preview.url} controls preload="metadata" src={preview.url} className="w-full" onError={()=>toast.error('原音無法播放，請保留分段並重新檢查')}/><Button size="sm" variant="outline" onClick={()=>setPreview(null)}>關閉聆聽</Button></div>}
    {visible.map(item=><div key={item.folder} className="flex flex-wrap items-center justify-between gap-3 mt-3">
      <span>{item.name} · {item.chunks} 個保留分段</span>
      <Button variant="outline" disabled={busy!==null} onClick={async()=>{
        setBusy(item.folder);setPreview(null);
        try{
          const result=await invoke<{status:string;audio_file_path:string|null;message:string}>('recover_audio_from_checkpoints',{meetingFolder:item.folder,sampleRate:48000});
          if(result.status==='success'&&result.audio_file_path){if(onListen)onListen(result.audio_file_path,item.name);else setPreview({name:item.name,url:convertFileSrc(result.audio_file_path)});}
          else toast.error(result.message||'尚無可播放音檔，原分段仍保留');
        }catch{toast.error('檢查／復原未完成，原音與分段仍保留');}
        finally{setBusy(null);}
      }}>檢查原音並聆聽</Button>
      <Button disabled={busy!==null} onClick={async()=>{
        setBusy(item.folder);
        try{
          const result=await invoke<{status:string;audio_file_path:string|null;message:string}>('recover_audio_from_checkpoints',{meetingFolder:item.folder,sampleRate:48000});
          if(result.status==='success'&&result.audio_file_path){toast.success(result.message||'原音已驗證；請確認匯入與處理設定');openImportDialog(result.audio_file_path);}
          else toast.error(result.message||'尚無可復原音檔，請保留資料夾');
        }catch{toast.error('復原未完成，程式未覆寫原音。請保留資料夾與分段，檢查磁碟空間、檔案權限及診斷紀錄後重試。');}
        finally{setBusy(null);}
      }}>{busy===item.folder?'正在檢查／復原…':'檢查原音並匯入'}</Button>
    </div>)}
  </section>;
}
