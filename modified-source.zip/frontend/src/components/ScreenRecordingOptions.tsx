'use client';
import { useEffect, useState } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { toast } from 'sonner';

type CaptureWindow = { id: number; pid: number; title: string };
type ScreenStatus = { selected: CaptureWindow | null; recording: boolean; paused: boolean; error: string | null };

export function ScreenRecordingOptions({ locked, inPerson }: { locked: boolean; inPerson: boolean }) {
  const [windows, setWindows] = useState<CaptureWindow[]>([]);
  const [state, setState] = useState<ScreenStatus>({ selected: null, recording: false, paused: false, error: null });
  const [busy, setBusy] = useState(false);
  const refresh = async () => {
    try { setWindows(await invoke<CaptureWindow[]>('screen_windows')); }
    catch { toast.error('無法取得視窗清單，請重試。'); }
  };
  useEffect(() => {
    let disposed = false;
    const sync = async () => {
      try { const status = await invoke<ScreenStatus>('screen_status'); if (!disposed) setState(status); }
      catch { /* App shutdown may interrupt polling. */ }
    };
    void refresh(); void sync();
    const timer = setInterval(sync, 1000);
    return () => { disposed = true; clearInterval(timer); };
  }, []);
  const select = async (id: string) => {
    setBusy(true);
    try {
      const window = id === '' ? null : windows.find(w => String(w.id) === id);
      if (window === undefined) throw new Error('視窗已失效，請重新整理。');
      await invoke('screen_select', { window });
      setState({ selected: window, recording: false, paused: false, error: null });
    } catch (error) { toast.error(String(error)); }
    finally { setBusy(false); }
  };
  if (inPerson) return null;
  const options = state.selected && !windows.some(w => w.id === state.selected?.id)
    ? [state.selected, ...windows] : windows;
  return <div className="mt-3 space-y-2 rounded-lg bg-slate-50 p-3" aria-label="會議畫面錄製">
    <div className="flex flex-wrap items-center gap-2">
      <label htmlFor="screen-window" className="font-medium">畫面錄製</label>
      <select id="screen-window" className="min-w-0 max-w-md rounded border bg-white p-2 text-sm"
        disabled={locked || busy} value={state.selected ? String(state.selected.id) : ''}
        onChange={event => void select(event.target.value)}>
        <option value="">不錄製畫面（只錄聲音）</option>
        {options.map(w => <option key={w.id} value={w.id}>{w.title}</option>)}
      </select>
      <button type="button" className="rounded border px-3 py-2 text-sm disabled:opacity-50" disabled={locked || busy} onClick={() => void refresh()}>重新整理視窗</button>
    </div>
    <p className="text-sm text-gray-600">選擇視窗後，按「開始錄音」會一起錄影；暫停與停止同步。每場會議需重新選擇，預設不錄畫面。</p>
    {state.selected && <p className="text-sm text-amber-800">請保持所選視窗可見、不要最小化或調整大小；部分硬體加速或受保護畫面可能無法錄製。聲音仍依會議模式錄製整台電腦的播放聲音。</p>}
    {state.recording && <p role="status" className="font-semibold text-red-700">● 正在錄製所選視窗</p>}
    {state.paused && <p role="status">畫面錄製已暫停</p>}
    {state.error && <p role="alert" className="font-semibold text-red-700">{state.error}</p>}
    <p className="text-xs text-gray-600">停止後存為 meeting-video.mp4，與 audio.mp4 位於同一會議資料夾。可從「設定 → 一般 → 開啟資料夾」找到。</p>
  </div>;
}
