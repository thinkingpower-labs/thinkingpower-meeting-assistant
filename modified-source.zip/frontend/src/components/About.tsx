import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { invoke } from '@tauri-apps/api/core';
import { getVersion } from '@tauri-apps/api/app';
import { Button } from './ui/button';
import { toast } from 'sonner';

export function About() {
    const [version, setVersion] = useState('載入中…');
    useEffect(() => { getVersion().then(setVersion).catch(() => {}); }, []);
    const openLink = async (url: string) => {
        try { await invoke('open_external_url', { url }); }
        catch { toast.error('無法開啟連結，請複製下方網址或電子郵件自行開啟。'); }
    };
    return (
        <div className="p-4 space-y-5 max-h-[80vh] overflow-y-auto">
            <header className="space-y-2">
                <Image src="/thinkingpower-bird.png" alt="思惟力量會議助手紫色機器鳥" width={80} height={80} />
                <h1 className="text-xl font-bold">思惟力量會議助手</h1>
                <p className="text-sm text-gray-500">版本 {version} · 社群改造版</p>
                <p className="text-sm">保留原始錄音、產生逐字稿與會議摘要。可選本機或雲端 AI；選擇雲端時，相關音訊或文字會傳送至選定服務。</p>
            </header>
            <section aria-label="思惟力量聯繫資訊" className="rounded-lg border bg-blue-50 p-4 space-y-3">
                <h2 className="font-semibold">思惟力量</h2>
                <p className="text-sm">公司網站與聯繫方式</p>
                <div><Button variant="link" className="h-auto p-0 whitespace-normal text-left" onClick={() => openLink('http://www.thinkingpower.com.tw')}>思惟力量：http://www.thinkingpower.com.tw</Button></div>
                <div><Button variant="link" className="h-auto p-0 whitespace-normal text-left" onClick={() => openLink('mailto:service@thinkingpower.com.tw')}>聯繫信箱：service@thinkingpower.com.tw</Button></div>
                <p className="text-xs text-gray-600">網站以預設瀏覽器開啟；信箱以預設郵件程式開啟，不會自動寄信。</p>
            </section>
            <section className="space-y-2 text-sm">
                <h2 className="font-semibold">開源來源與授權</h2>
                <p>基於 Meetily 社區版修改，非 Zackriya Solutions／Meetily 官方發行版本。</p>
                <p>原作者 Copyright (c) 2024 Zackriya Solutions。修改部分 Copyright (c) 2026 思惟力量 contributors。</p>
                <p>本專案程式採 MIT 授權，完整條文見下載包 LICENSE.md。第三方套件、素材及模型各依原授權，詳見 NOTICE.md 與 licenses 資料夾。</p>
                <Button variant="outline" onClick={() => openLink('https://github.com/thinkingpowerai-ux/thinkingpower-meeting-assistant')}>公開原始碼與版本下載</Button>
                <Button variant="link" onClick={() => openLink('https://github.com/Zackriya-Solutions/meetily')}>Meetily 原始專案</Button>
            </section>
            <p className="text-xs text-gray-500">AI 可能誤辨或推測內容，請播放原音核對。雲端服務用量由各服務另行計費。</p>
        </div>
    );
}
