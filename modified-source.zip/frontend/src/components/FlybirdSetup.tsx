'use client';
import { useState, useEffect } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';

export function FlybirdSetup() {
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState('');
  const [stage, setStage] = useState<'idle' | 'whisper' | 'summary' | 'loading'>('idle');
  useEffect(() => {
    const cleanup = listen<{ modelName: string; progress: number }>('model-download-progress', e => {
      if (e.payload.modelName === 'small') setProgress(e.payload.progress);
    });
    const summaryCleanup = listen<{ model: string; progress: number }>('builtin-ai-download-progress', e => {
      if (e.payload.model === 'qwen3.5:4b') setProgress(Math.round(e.payload.progress));
    });
    return () => { void cleanup.then(fn => fn()); void summaryCleanup.then(fn => fn()); };
  }, []);
  async function setup() {
    if (busy) return;
    setBusy(true); setError(''); setStage('whisper'); setProgress(0);
    try {
      await invoke('whisper_init');
      const models = await invoke<Array<{ name: string; status: string }>>('whisper_get_available_models');
      if (!models.some(m => m.name === 'small' && m.status === 'Available')) {
        await invoke('whisper_download_model', { modelName: 'small' });
      }
      await invoke('whisper_load_model', { modelName: 'small' });
      setStage('summary'); setProgress(0);
      const ready = await invoke<boolean>('builtin_ai_is_model_ready', {modelName: 'qwen3.5:4b', refresh: true});
      if (!ready) await invoke('builtin_ai_download_model', {modelName: 'qwen3.5:4b'});
      setStage('loading');
      // Completion validates a real one-token inference and persists both defaults.
      await invoke('flybird_complete_setup');
      localStorage.setItem('primaryLanguage', 'zh');
      // Reload providers so configuration is read back from the saved database.
      window.location.reload();
    } catch (e) { setError(String(e)); setBusy(false); setStage('idle'); }
  }
  return <main className="min-h-screen flex items-center justify-center bg-slate-50 p-8">
    <section className="max-w-xl bg-white rounded-2xl shadow p-8 space-y-5">
      <h1 className="text-3xl font-bold">思惟力量會議助手</h1>
      <p>基於 Meetily 社群版的繁體中文版本。錄製線上或實體會議，在這台電腦轉為逐字稿。</p>
      <p className="text-sm text-gray-600">首次準備會下載 Whisper Small（約 466 MB）與 Qwen 3.5 4B 摘要模型（約 2.6 GB），合計約 3.1 GB，並載入檢查。建議至少 16 GB 記憶體並預留 5 GB 磁碟空間；已下載的模型會直接沿用。準備完成後可離線轉錄及產生摘要，不需要帳號或 API Key。</p>
      <button onClick={setup} disabled={busy} className="rounded-lg bg-blue-700 text-white px-5 py-3 disabled:opacity-50">
        {busy ? stage === 'loading' ? '正在載入並檢查 Qwen 摘要模型，請稍候…' : `${stage === 'whisper' ? '1/2 中文轉錄模型' : '2/2 Qwen 摘要模型'}下載中… ${Math.round(progress)}%` : '準備本機轉錄與摘要'}
      </button>
      {busy && (stage === 'whisper' || stage === 'summary') && <button className="ml-3 underline" onClick={async () => {
        try { await invoke(stage === 'whisper' ? 'whisper_cancel_download' : 'builtin_ai_cancel_download', {modelName: stage === 'whisper' ? 'small' : 'qwen3.5:4b'}); }
        catch (e) { setError(String(e)); }
      }}>取消下載</button>}
      {error && <p role="alert" className="text-red-700 break-words">準備未完成：{error}。請確認連線後重試。</p>}
      <p className="text-xs text-gray-500">逐字稿仍需人工校對。請在錄音前讓與會者知悉。</p>
    </section>
  </main>;
}
