import { useEffect, useRef, useState } from 'react';
import { invoke } from '@tauri-apps/api/core';
import Link from 'next/link';
import { Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '../ui/dialog';
import { Button } from '../ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { useConfig } from '@/contexts/ConfigContext';
import { useTranscriptionModels } from '@/hooks/useTranscriptionModels';
import { LANGUAGES } from '@/constants/languages';

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  meetingId: string;
  meetingFolderPath: string | null;
  onComplete?: () => void;
}
type Connection = { connection: { provider: string; endpoint: string } };

export function RetranscribeDialog({ open, onOpenChange, meetingId, meetingFolderPath, onComplete }: Props) {
  const { selectedLanguage, transcriptModelConfig } = useConfig();
  const models = useTranscriptionModels(transcriptModelConfig, true);
  const [language, setLanguage] = useState(selectedLanguage || 'auto');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [confirmed, setConfirmed] = useState(false);
  const [connections, setConnections] = useState<Connection[]>([]);
  const [count, setCount] = useState(0);
  const starting = useRef(false);
  const wasOpen = useRef(false);
  const latestMeeting=useRef(meetingId);latestMeeting.current=meetingId;
  const selected = models.availableModels.find(m => `${m.provider}:${m.name}` === models.selectedModelKey);
  const cloud = !!selected && ['openai', 'groq', 'openrouter', 'custom-openai'].includes(selected.provider);
  const endpoint = connections.find(c => c.connection.provider === selected?.provider)?.connection.endpoint;

  useEffect(() => {
    if (open && !wasOpen.current) {
      models.resetSelection();
      void models.fetchModels();
      setLanguage(selectedLanguage || 'auto'); setError(''); setConfirmed(false); setCount(0);
    }
    wasOpen.current = open;
  }, [open, selectedLanguage, models.resetSelection, models.fetchModels]);

  useEffect(() => {
    if (!open) return;
    let active = true;
    setConnections([]);
    invoke<Connection[]>('ai_get_connections').then(value => { if (active) setConnections(value); })
      .catch(() => { if (active) setError('無法讀取服務連線，請關閉後重試。'); });
    return () => { active = false; };
  }, [open]);

  // Changing model, language or destination invalidates the previous grant.
  useEffect(() => { setConfirmed(false); }, [models.selectedModelKey, language, endpoint]);
  useEffect(() => {
    if (!busy) return;
    let active = true;
    const poll = () => invoke<{ completed_chunks: string } | null>('get_audio_job', { meetingId })
      .then(job => { if (active && job) { try { setCount(JSON.parse(job.completed_chunks).length); } catch {} } })
      .catch(() => {});
    const timer = setInterval(poll, 2000);
    return () => { active = false; clearInterval(timer); };
  }, [busy, meetingId]);

  async function start() {
    if (starting.current || !selected || (cloud && (!confirmed || !endpoint))) return;
    starting.current = true; setBusy(true); setError(''); setCount(0);
    try {
      const result = await invoke<{ segments_count: number }>('restart_recording_transcription', {
        meetingId, provider: selected.provider, model: selected.name,
        language: selected.provider === 'parakeet' || language === 'auto' ? null : language,
        cloudAuthorized: cloud && confirmed, expectedEndpoint: cloud ? endpoint : null,
      });
      toast.success(`逐字稿已儲存，共 ${result.segments_count} 段。`);
      if(latestMeeting.current===meetingId){onComplete?.(); onOpenChange(false);}
    } catch (value) { setError(String(value)); }
    finally { starting.current = false; setBusy(false); }
  }

  return <Dialog open={open} onOpenChange={onOpenChange}>
    <DialogContent className="sm:max-w-lg">
      <DialogHeader>
        <DialogTitle>以原音重新轉錄</DialogTitle>
        <DialogDescription>在同一筆會議建立新的轉錄嘗試。原音、舊稿與先前進度會保留；成功後更新此會議逐字稿。若要略過已完成分段，請使用會議上方的「接續未完成的轉錄」。</DialogDescription>
      </DialogHeader>
      {busy ? <p role="status" className="flex items-center gap-2"><Loader2 className="h-4 w-4 animate-spin"/>已加入工作清單，已保存 {count} 段。可關閉視窗繼續使用，或到錄音與轉錄中心追蹤。</p> : <div className="space-y-4">
        <label className="block text-sm">轉錄服務與模型</label>
        <Select value={models.selectedModelKey} onValueChange={models.setSelectedModelKey} disabled={models.loadingModels}>
          <SelectTrigger><SelectValue placeholder={models.loadingModels ? '載入模型中…' : '選擇模型'}/></SelectTrigger>
          <SelectContent>{models.availableModels.map(model => <SelectItem key={`${model.provider}:${model.name}`} value={`${model.provider}:${model.name}`}>{model.displayName}</SelectItem>)}</SelectContent>
        </Select>
        {!models.loadingModels && models.availableModels.length === 0 && <p>目前沒有可用模型，請先至設定下載本機模型或設定雲端服務。</p>}
        {selected?.provider !== 'parakeet' && <>
          <label className="block text-sm">辨識語言</label>
          <Select value={language} onValueChange={setLanguage}><SelectTrigger><SelectValue/></SelectTrigger>
            <SelectContent>{LANGUAGES.map(lang => <SelectItem key={lang.code} value={lang.code}>{lang.name}</SelectItem>)}</SelectContent>
          </Select>
        </>}
        {cloud && <div className="space-y-2 rounded border p-3 text-sm">
          <p className="break-all">音訊目的地：{endpoint ? `${endpoint.replace(/\/$/, '')}/audio/transcriptions` : '尚未設定，請至設定儲存服務連線。'}</p>
          <label className="flex gap-2"><input type="checkbox" checked={confirmed} disabled={!endpoint} onChange={event => setConfirmed(event.target.checked)}/>
            同意將完整原音分段傳送至 {selected?.provider} 辨識，將重新處理全部音訊，可能再次計費。{selected?.provider === 'openrouter' ? 'OpenRouter 會將音訊轉送至上游模型服務。' : ''}
          </label>
        </div>}
      </div>}
      {error && <p role="alert" className="text-sm text-red-700">{error}</p>}
      <DialogFooter>
        {busy && <Button variant="outline" onClick={async () => {
          try { await invoke('cancel_import_for_meeting_command', {meetingId}); setError('已要求停止，正在等待目前階段結束並保留進度。'); }
          catch (value) { setError(String(value)); }
        }}>停止處理</Button>}
        <Link href="/recordings" className="px-3 py-2 text-sm underline" onClick={()=>onOpenChange(false)}>查看所有工作</Link>
        <Button variant="outline" onClick={() => onOpenChange(false)}>{busy?'背景繼續／關閉':'關閉'}</Button>
        <Button disabled={busy || !meetingFolderPath || !selected || models.loadingModels || (cloud && (!confirmed || !endpoint))} onClick={start}>開始新的轉錄</Button>
      </DialogFooter>
    </DialogContent>
  </Dialog>;
}
