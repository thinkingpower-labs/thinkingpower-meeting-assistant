"use client";

import { Transcript, TranscriptSegmentData } from '@/types';
import { TranscriptView } from '@/components/TranscriptView';
import { VirtualizedTranscriptView } from '@/components/VirtualizedTranscriptView';
import { SpeakerManager } from "./SpeakerManager";
import { RecordingFileInfo } from './RecordingFileInfo';
import { TranscriptButtonGroup } from './TranscriptButtonGroup';
import { useMemo, useEffect, useState, useRef } from 'react';
import { invoke, convertFileSrc } from '@tauri-apps/api/core';

interface TranscriptPanelProps {
  transcripts: Transcript[];
  customPrompt: string;
  onPromptChange: (value: string) => void;
  onCopyTranscript: () => void;
  onOpenMeetingFolder: () => Promise<void>;
  isRecording: boolean;
  disableAutoScroll?: boolean;

  // Optional pagination props (when using virtualization)
  usePagination?: boolean;
  segments?: TranscriptSegmentData[];
  hasMore?: boolean;
  isLoadingMore?: boolean;
  totalCount?: number;
  loadedCount?: number;
  onLoadMore?: () => void;

  // Retranscription props
  meetingId?: string;
  meetingFolderPath?: string | null;
  onRefetchTranscripts?: () => Promise<void>;
}

export function TranscriptPanel({
  transcripts,
  customPrompt,
  onPromptChange,
  onCopyTranscript,
  onOpenMeetingFolder,
  isRecording,
  disableAutoScroll = false,
  usePagination = false,
  segments,
  hasMore,
  isLoadingMore,
  totalCount,
  loadedCount,
  onLoadMore,
  meetingId,
  meetingFolderPath,
  onRefetchTranscripts,
}: TranscriptPanelProps) {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [audioUrl, setAudioUrl] = useState('');
  const [audioPath, setAudioPath] = useState('');
  const [audioError, setAudioError] = useState('');
  useEffect(() => {
    let active = true;
    setAudioUrl(''); setAudioPath(''); setAudioError('');
    if (meetingId && !isRecording) invoke<string>('flybird_meeting_audio', {meetingId})
      .then(path => { if (active) { setAudioPath(path); setAudioUrl(convertFileSrc(path)); } })
      .catch(error => { if (active) setAudioError(String(error)); });
    return () => { active = false; };
  }, [meetingId, isRecording]);
  const seekAudio = (seconds: number) => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.currentTime = Math.max(0, seconds);
    audio.play().catch(() => setAudioError('無法播放音檔，請開啟錄音資料夾使用播放器對照。'));
  };
  // Convert transcripts to segments if pagination is not used but we want virtualization
  const convertedSegments = useMemo(() => {
    if (usePagination && segments) {
      return segments;
    }
    // Convert transcripts to segments for virtualization
    return transcripts.map(t => ({
      id: t.id,
      timestamp: t.audio_start_time ?? 0,
      endTime: t.audio_end_time,
      text: t.text,
      speaker: t.speaker,
      speaker_name: t.speaker_name,
      confidence: t.confidence,
    }));
  }, [transcripts, usePagination, segments]);

  return (
    <div className="flex h-full min-w-0 w-full bg-white flex-col relative @container">
      {/* Title area */}
      <div className="p-4 border-b border-gray-200">
        <TranscriptButtonGroup
          transcriptCount={usePagination ? (totalCount ?? convertedSegments.length) : (transcripts?.length || 0)}
          onCopyTranscript={onCopyTranscript}
          onOpenMeetingFolder={onOpenMeetingFolder}
          meetingId={meetingId}
          meetingFolderPath={meetingFolderPath}
          onRefetchTranscripts={onRefetchTranscripts}
        />
        {!isRecording && <RecordingFileInfo folderPath={meetingFolderPath} audioPath={audioPath}/>}
      </div>

      {!isRecording && meetingId && <div className="px-4 py-2 border-b">
        {audioUrl && <audio ref={audioRef} controls preload="metadata" src={audioUrl} className="w-full" aria-label="原始錄音播放器"
          onError={() => setAudioError('此格式無法直接播放，請開啟錄音資料夾使用播放器對照。')}/>}
        <p className="text-xs text-gray-600 mt-1">{audioError || '點逐字稿時間可跳到該段原音。請核對專有名詞、數字與決議。'}</p>
      </div>}
      {!isRecording && meetingId && <SpeakerManager key={meetingId} meetingId={meetingId} revision={transcripts[0]?.id} onSaved={onRefetchTranscripts}/>}
      {/* Transcript content - use virtualized view for better performance */}
      <div className="flex-1 overflow-hidden pb-4">
        <VirtualizedTranscriptView
          segments={convertedSegments}
          isRecording={isRecording}
          isPaused={false}
          isProcessing={false}
          isStopping={false}
          enableStreaming={false}
          showConfidence={true}
          disableAutoScroll={disableAutoScroll}
          hasMore={hasMore}
          isLoadingMore={isLoadingMore}
          totalCount={totalCount}
          loadedCount={loadedCount}
          onLoadMore={onLoadMore}
          onSeek={audioUrl ? seekAudio : undefined}
        />
      </div>

      {/* Custom prompt input at bottom of transcript section */}
      {!isRecording && convertedSegments.length > 0 && (
        <div className="p-1 border-t border-gray-200">
          <textarea
            placeholder="補充摘要所需背景，例如與會者、會議目的或專有名詞…"
            className="w-full px-3 py-2 border border-gray-200 rounded-md text-sm focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 bg-white shadow-sm min-h-[80px] resize-y"
            value={customPrompt}
            onChange={(e) => onPromptChange(e.target.value)}
          />
        </div>
      )}
    </div>
  );
}
