"use client";

import { useState, useCallback, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ButtonGroup } from '@/components/ui/button-group';
import { Copy, FolderOpen, RefreshCw } from 'lucide-react';
import Analytics from '@/lib/analytics';
import { RetranscribeDialog } from './RetranscribeDialog';
import { useConfig } from '@/contexts/ConfigContext';


interface TranscriptButtonGroupProps {
  transcriptCount: number;
  onCopyTranscript: () => void;
  onOpenMeetingFolder: () => Promise<void>;
  meetingId?: string;
  meetingFolderPath?: string | null;
  onRefetchTranscripts?: () => Promise<void>;
}


export function TranscriptButtonGroup({
  transcriptCount,
  onCopyTranscript,
  onOpenMeetingFolder,
  meetingId,
  meetingFolderPath,
  onRefetchTranscripts,
}: TranscriptButtonGroupProps) {
  const { betaFeatures } = useConfig();
  const [showRetranscribeDialog, setShowRetranscribeDialog] = useState(false);
  const searchParams = useSearchParams();
  const [showNextStep, setShowNextStep] = useState(false);
  const recordingFailed = searchParams.get('recordingResult') === 'failed';
  useEffect(() => {
    if (!meetingId || searchParams.get('source') !== 'recording') return;
    const key = `recording-next-step-${meetingId}`;
    if (!sessionStorage.getItem(key)) { setShowNextStep(true); sessionStorage.setItem(key, 'shown'); }
  }, [meetingId, searchParams]);

  const handleRetranscribeComplete = useCallback(async () => {
    // Refetch transcripts to show the updated data
    if (onRefetchTranscripts) {
      await onRefetchTranscripts();
    }
  }, [onRefetchTranscripts]);

  return (
    <div className="flex items-center justify-center w-full gap-2">
      <Dialog open={showNextStep} onOpenChange={setShowNextStep}><DialogContent>
        <DialogHeader><DialogTitle>{recordingFailed ? '原始錄音已保存，請完成後續處理' : '錄音已保存，接下來可以這樣做'}</DialogTitle>
        <DialogDescription>{recordingFailed ? '後續處理尚未全部完成。請先查看上方錯誤訊息：若逐字稿已完成，只需按「產生摘要」；若轉錄失敗，請重試轉錄。' : '逐字稿已儲存。請先播放原音核對內容；要整理會議紀錄，請按右側「產生摘要」。開啟自動摘要時，請查看右側結果或錯誤訊息。'}</DialogDescription></DialogHeader>
        <p className="text-sm">「重新轉錄」會再次辨識原始錄音，適合逐字稿漏字或要更換轉錄模型時使用；雲端可能再次計費。</p>
        <Button onClick={() => setShowNextStep(false)}>知道了，查看會議</Button>
        {recordingFailed && transcriptCount === 0 && meetingFolderPath && <Button variant="outline" onClick={() => {setShowNextStep(false);setShowRetranscribeDialog(true);}}>選擇轉錄服務並處理</Button>}
      </DialogContent></Dialog>
      <ButtonGroup>
        <Button
          variant="outline"
          size="sm"
          className="px-2 @[22rem]:px-3"
          onClick={() => {
            Analytics.trackButtonClick('copy_transcript', 'meeting_details');
            onCopyTranscript();
          }}
          disabled={transcriptCount === 0}
          title={transcriptCount === 0 ? "尚無逐字稿" : "複製逐字稿"}
        >
          <Copy />
          <span className="hidden @[22rem]:inline">複製</span>
        </Button>

        <Button
          size="sm"
          variant="outline"
          className="px-2 @[22rem]:px-4"
          onClick={() => {
            Analytics.trackButtonClick('open_recording_folder', 'meeting_details');
            onOpenMeetingFolder();
          }}
          title="開啟錄音資料夾"
        >
          <FolderOpen className="@[22rem]:mr-2" size={18} />
          <span className="hidden @[22rem]:inline">錄音</span>
        </Button>

        {betaFeatures.importAndRetranscribe && meetingId && meetingFolderPath && (
          <Button
            size="sm"
            variant="outline"
            className="bg-gradient-to-r from-blue-50 to-purple-50 hover:from-blue-100 hover:to-purple-100 border-blue-200 px-2 @[22rem]:px-4"
            onClick={() => {
              Analytics.trackButtonClick('enhance_transcript', 'meeting_details');
              setShowRetranscribeDialog(true);
            }}
            title="以原始錄音重新轉錄"
          >
            <RefreshCw className="@[22rem]:mr-2" size={18} />
            <span className="hidden @[22rem]:inline">重新轉錄</span>
          </Button>
        )}
      </ButtonGroup>

      {betaFeatures.importAndRetranscribe && meetingId && meetingFolderPath && (
        <RetranscribeDialog
          open={showRetranscribeDialog}
          onOpenChange={setShowRetranscribeDialog}
          meetingId={meetingId}
          meetingFolderPath={meetingFolderPath}
          onComplete={handleRetranscribeComplete}
        />
      )}
    </div>
  );
}
