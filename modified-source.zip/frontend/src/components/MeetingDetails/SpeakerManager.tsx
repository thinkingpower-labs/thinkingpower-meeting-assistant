'use client';
import { useEffect, useState } from 'react';
import { invoke } from '@tauri-apps/api/core';

type Speaker = {speaker_id: string; display_name: string};
export function SpeakerManager({meetingId, revision, onSaved}: {meetingId: string; revision?: unknown; onSaved?: () => Promise<void>}) {
  const [speakers, setSpeakers] = useState<Speaker[]>([]);
  const [names, setNames] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState('');
  const [message, setMessage] = useState('');
  const [loadError, setLoadError] = useState('');
  useEffect(() => {
    let active = true;
    invoke<Speaker[]>('list_meeting_speakers', {meetingId}).then(rows => {
      if (!active) return;
      setSpeakers(rows); setNames(Object.fromEntries(rows.map(s => [s.speaker_id, s.display_name]))); setLoadError('');
    }).catch(() => {if (active) setLoadError('無法讀取說話人，請重新開啟會議。');});
    return () => {active = false;};
  }, [meetingId, revision]);
  if (loadError) return <p role="alert" className="px-4 py-2 text-sm text-red-700">{loadError}</p>;
  if (!speakers.length) return null;
  return <details className="border-b px-4 py-2 max-h-60 overflow-auto">
    <summary className="cursor-pointer text-sm font-semibold">說話人姓名（{speakers.length} 位）</summary>
    <p className="text-xs text-gray-600 my-2">依聲音分組，請聆聽原音核對後命名。儲存後套用整場逐字稿；既有摘要請重新產生以套用姓名。</p>
    {speakers.map(s => <form key={s.speaker_id} className="flex items-center gap-2 mb-2" onSubmit={async e => {
      e.preventDefault(); setSaving(s.speaker_id); setMessage('');
      try {
        await invoke('rename_meeting_speaker', {meetingId, speakerId:s.speaker_id, displayName:names[s.speaker_id]});
        setSpeakers(rows => rows.map(row => row.speaker_id === s.speaker_id ? {...row, display_name:names[s.speaker_id].trim()} : row));
        await onSaved?.(); setMessage('姓名已儲存；複製、匯出及新產生的摘要會使用此姓名。');
      } catch (error) {setMessage(String(error));} finally {setSaving('');}
    }}>
      <label className="sr-only" htmlFor={`speaker-${s.speaker_id}`}>修改 {s.display_name} 的姓名</label>
      <input id={`speaker-${s.speaker_id}`} value={names[s.speaker_id] ?? s.display_name} maxLength={80} required disabled={!!saving}
        onChange={e => setNames({...names,[s.speaker_id]:e.target.value})} className="border rounded px-2 py-1 text-sm min-w-0 flex-1"/>
      <button type="submit" disabled={!!saving || !names[s.speaker_id]?.trim() || names[s.speaker_id] === s.display_name} className="border rounded px-3 py-1 text-sm disabled:opacity-40">{saving === s.speaker_id ? '儲存中…' : '儲存'}</button>
    </form>)}
    {message && <p role="status" className="text-sm">{message}</p>}
  </details>;
}
