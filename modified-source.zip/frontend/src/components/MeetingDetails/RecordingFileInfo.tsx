'use client';
import { toast } from 'sonner';

export function storedFileName(path?: string | null): string {
  return path?.replace(/[\\/]+$/, '').split(/[\\/]/).pop() || '';
}

export function RecordingFileInfo({folderPath, audioPath}: {folderPath?: string | null; audioPath?: string | null}) {
  const folder = storedFileName(folderPath);
  const audio = storedFileName(audioPath);
  if (!folderPath && !audioPath) return <p className="mt-2 text-xs text-gray-500">原始檔名：此會議未保留錄音路徑。</p>;
  async function copy(value: string) {
    try { await navigator.clipboard.writeText(value); toast.success('已複製錄音路徑'); }
    catch { toast.error('無法複製，請選取畫面上的名稱複製。'); }
  }
  return <div className="mt-3 space-y-1 text-xs text-gray-600 min-w-0" aria-label="原始錄音檔案資訊">
    <p className="break-all" title={audioPath || undefined}><span className="font-medium text-gray-800">原始檔名：</span>{audio || '尚未取得原音檔名'}</p>
    <p className="break-all" title={folderPath || undefined}><span className="font-medium text-gray-800">錄音資料夾：</span>{folder || '未保留路徑'}</p>
    <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
      {folderPath && <button type="button" className="underline underline-offset-2 hover:text-blue-700" onClick={() => void copy(folderPath)}>複製資料夾路徑</button>}
      {audioPath && <button type="button" className="underline underline-offset-2 hover:text-blue-700" onClick={() => void copy(audioPath)}>複製音檔路徑</button>}
    </div>
    <p className="text-gray-500">會議改名不會改動以上名稱；到 Music／音樂資料夾時，請依「錄音資料夾」對照，或按上方「錄音」直接開啟。</p>
  </div>;
}
