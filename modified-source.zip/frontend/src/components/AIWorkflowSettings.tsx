'use client';

import { useEffect, useState } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { toast } from 'sonner';
import { useConfig } from '@/contexts/ConfigContext';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Switch } from './ui/switch';
import { TextModelPicker } from './TextModelPicker';

export const serviceNames: Record<string, string> = {
  'builtin-ai': '內建 AI（離線）', claude: 'Claude', 'custom-openai': '自訂伺服器（OpenAI 相容）',
  gemini: 'Google Gemini', groq: 'Groq', ollama: 'Ollama', openai: 'OpenAI', openrouter: 'OpenRouter',
  whisper: '內建 Whisper（離線）', localWhisper: '內建 Whisper（離線）', parakeet: 'Parakeet（離線）',
};
type Connection = { provider: string; endpoint: string; text_model: string; audio_model: string; text_verified: boolean; audio_verified: boolean };
type Entry = { connection: Connection; has_key: boolean };
type Catalog = { providers: { provider: string; models: string[] }[] };

export function AIWorkflowSettings() {
  const { modelConfig, setModelConfig, transcriptModelConfig, setTranscriptModelConfig, isAutoSummary, toggleIsAutoSummary } = useConfig();
  const [entries, setEntries] = useState<Entry[]>([]);
  const [modelRevision, setModelRevision] = useState(0);
  const [provider, setProvider] = useState('openai');
  const [draft, setDraft] = useState<Connection | null>(null);
  const [key, setKey] = useState('');
  const [catalog, setCatalog] = useState<Catalog>({ providers: [] });
  const [localModels, setLocalModels] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [testConfirmed, setTestConfirmed] = useState(false);
  const [sttProvider, setSttProvider] = useState<string>(transcriptModelConfig.provider);
  const [sttModel, setSttModel] = useState(transcriptModelConfig.model);
  const [summaryProvider, setSummaryProvider] = useState<string>(modelConfig.provider);
  const [summaryModel, setSummaryModel] = useState(modelConfig.model);
  const refresh = async () => {
    const data = await invoke<Entry[]>('ai_get_connections'); setEntries(data);
    setDraft(data.find(item => item.connection.provider === provider)?.connection || null);
    setModelRevision(value => value + 1);
  };
  useEffect(() => {
    refresh().catch(() => toast.error('無法載入服務設定'));
    invoke<Catalog>('cloud_transcription_catalog').then(setCatalog).catch(() => toast.error('無法載入轉錄模型'));
    invoke<{name: string; status: unknown}[]>('whisper_get_available_models').then(models => setLocalModels(models.filter(m => m.status === 'Available').map(m => m.name))).catch(() => {});
  }, []);
  useEffect(() => { setDraft(entries.find(item => item.connection.provider === provider)?.connection || null); setKey(''); setTestConfirmed(false); }, [provider, entries]);
  const run = async (action: () => Promise<void>) => { setBusy(true); try { await action(); } catch (error) { toast.error(String(error)); } finally { setBusy(false); } };
  const audioModels = (value: string) => value === 'localWhisper' ? localModels : catalog.providers.find(p => p.provider === value)?.models || [];
  const custom = entries.find(e => e.connection.provider === 'custom-openai')?.connection;
  const summaryChanged = (value: string) => { setSummaryProvider(value); setSummaryModel(entries.find(e => e.connection.provider === value)?.connection.text_model || ''); };
  return <div className="space-y-6 mt-4">
    <section className="bg-white border rounded-lg p-6 space-y-4">
      <h2 className="text-lg font-semibold">AI 服務連線</h2>
      {provider === "gemini" && <p className="text-sm text-amber-800">使用 Google AI Studio 的 Gemini API Key，不是 Google 帳號密碼。API 與 Gemini 訂閱分開計費／計額；請先確認所選 API 方案的費用與資料使用條款，再傳送會議內容。</p>}
      <p className="text-sm text-gray-600">每個服務只需設定一份 Key，逐字稿與摘要共用。金鑰由 Windows 安全機制加密，不會顯示已儲存的內容。</p>
      <label className="block">服務<select className="block border rounded p-2 w-full" value={provider} onChange={e => setProvider(e.target.value)}>{entries.map(e => <option key={e.connection.provider} value={e.connection.provider}>{serviceNames[e.connection.provider]}</option>)}</select></label>
      {draft && <>
        {provider !== 'builtin-ai' && <label className="block">伺服器網址<Input value={draft.endpoint} readOnly={!['ollama', 'custom-openai'].includes(provider)} onChange={e => setDraft({...draft, endpoint: e.target.value})}/></label>}
        {!['builtin-ai'].includes(provider) && <label className="block">API Key{['ollama', 'custom-openai'].includes(provider) ? '（可不填）' : ''}<Input type="password" autoComplete="off" value={key} placeholder={entries.find(e => e.connection.provider === provider)?.has_key ? '已安全儲存；留空保留，輸入新值可更換' : '尚未設定'} onChange={e => setKey(e.target.value)}/></label>}
        <div>文字模型名稱<TextModelPicker provider={provider} value={draft.text_model} revision={modelRevision} onChange={value => setDraft({...draft, text_model: value})}/></div>
        {(audioModels(provider).length > 0 || provider === 'custom-openai') && <label className="block">語音轉錄模型{provider === 'custom-openai' ? <Input value={draft.audio_model} onChange={e => setDraft({...draft, audio_model: e.target.value})}/> : <select className="block border rounded p-2 w-full" value={draft.audio_model} onChange={e => setDraft({...draft, audio_model: e.target.value})}><option value="">請選擇模型</option>{audioModels(provider).map(model => <option key={model}>{model}</option>)}</select>}</label>}
        <div className="flex gap-2"><Button disabled={busy} onClick={() => run(async () => { if (provider === 'builtin-ai') await invoke('builtin_ai_prepare_model', {modelName: draft.text_model}); await invoke('ai_save_connection', {config: draft, apiKey: key || null}); setKey(''); await refresh(); toast.success('連線設定已儲存'); })}>儲存此服務</Button><Button variant="outline" disabled={busy} onClick={() => run(async () => { await invoke('ai_remove_connection', {provider}); await refresh(); toast.success('已移除此服務連線與 Key'); })}>移除連線與 Key</Button></div>
        <label className="flex gap-2 text-sm"><input type="checkbox" checked={testConfirmed} onChange={e => setTestConfirmed(e.target.checked)}/>我同意向此服務傳送合成測試文字或一秒靜音；雲端測試可能計費，不包含任何會議內容。</label>
        {draft.audio_model === "gpt-4o-transcribe-diarize" && <p className="text-sm text-amber-800">此模型請透過匯入錄音或「以原音重新轉錄」驗證說話人，不適用一秒靜音測試。最長 130 分鐘；公告於 2027/02/26 停用。</p>}
        <p className="text-sm">先儲存，再分別測試文字與音訊端點。端點回應成功不代表長錄音品質已驗收。</p>
        <div className="flex gap-2">{(['text', 'audio'] as const).filter(kind => kind === 'text' || audioModels(provider).length > 0 || provider === 'custom-openai').map(kind => <Button key={kind} variant="outline" disabled={busy || !testConfirmed || (kind === 'audio' && draft.audio_model === 'gpt-4o-transcribe-diarize')} onClick={() => run(async () => { const message = await invoke<string>('ai_test_connection', {provider, capability: kind, confirmed: testConfirmed}); toast.success(message); await refresh(); })}>{kind === 'text' ? '測試文字端點' : '測試音訊端點'}</Button>)}</div>
        <p className="text-sm text-gray-600">文字端點：{draft.text_verified ? '測試通過' : '尚未驗證'}；音訊端點：{draft.audio_verified ? '測試通過' : '尚未驗證'}。雲端長音檔實際呼叫驗收尚未完成。</p>
      </>}
    </section>
    <section className="bg-white border rounded-lg p-6 space-y-4">
      <h2 className="text-lg font-semibold">處理流程</h2>
      <label className="block">1. 語音轉逐字稿<select className="block border rounded p-2 w-full" value={sttProvider} onChange={e => { setSttProvider(e.target.value); setSttModel(audioModels(e.target.value)[0] || custom?.audio_model || ''); }}><option value="localWhisper">內建 Whisper（離線）</option>{catalog.providers.map(p => <option key={p.provider} value={p.provider}>{serviceNames[p.provider]}</option>)}{custom?.audio_verified && <option value="custom-openai">自訂伺服器（音訊端點已測試）</option>}</select></label>
      <select aria-label="語音轉錄模型" className="border rounded p-2 w-full" value={sttModel} onChange={e => setSttModel(e.target.value)}>{(sttProvider === 'custom-openai' ? [custom?.audio_model || ''] : audioModels(sttProvider)).map(model => <option key={model}>{model}</option>)}</select>
      {sttModel === "gpt-4o-transcribe-diarize" && <p className="text-sm text-amber-800">OpenAI 說話人分離：整場音訊壓縮後送出，完成後可修改姓名；相容模型公告於 2027/02/26 停用。</p>}
      <p className="text-sm">離線模型請至「語音轉錄」頁下載。Claude、Ollama 未列為語音轉錄服務。</p>
      <label className="block">2. 逐字稿產生摘要／會議紀錄<select className="block border rounded p-2 w-full" value={summaryProvider} onChange={e => summaryChanged(e.target.value)}>{entries.map(e => <option key={e.connection.provider} value={e.connection.provider}>{serviceNames[e.connection.provider]}</option>)}</select></label>
      <TextModelPicker provider={summaryProvider} value={summaryModel} revision={modelRevision} onChange={setSummaryModel}/>
      <label className="flex gap-3 items-center"><Switch checked={isAutoSummary} onCheckedChange={toggleIsAutoSummary}/>轉錄完成後自動產生摘要</label>
      <p className="text-sm">儲存設定不會上傳既有會議。開始處理時會列出本次音訊與逐字稿的傳送對象。</p>
      <Button disabled={busy || !sttModel || (isAutoSummary && !summaryModel)} onClick={() => run(async () => {
        if (summaryProvider === 'builtin-ai') await invoke('builtin_ai_prepare_model', {modelName: summaryModel});
        await invoke('api_save_transcript_config', {provider: sttProvider, model: sttModel, apiKey: null});
        const endpoint = entries.find(e => e.connection.provider === summaryProvider)?.connection.endpoint;
        await invoke('api_save_model_config', {provider: summaryProvider, model: summaryModel, whisperModel: sttModel, apiKey: null, ollamaEndpoint: summaryProvider === 'ollama' ? endpoint?.replace(/\/v1\/?$/, '') : null});
        setTranscriptModelConfig({provider: sttProvider as typeof transcriptModelConfig.provider, model: sttModel, apiKey: null});
        setModelConfig({...modelConfig, provider: summaryProvider as typeof modelConfig.provider, model: summaryModel, apiKey: null,
          ollamaEndpoint: summaryProvider === 'ollama' ? endpoint?.replace(/\/v1\/?$/, '') : undefined,
          customOpenAIEndpoint: summaryProvider === 'custom-openai' ? endpoint : undefined});
        const {emit} = await import('@tauri-apps/api/event');
        await emit('model-config-updated', {...modelConfig, provider: summaryProvider, model: summaryModel, apiKey: null, customOpenAIApiKey: null,
          ollamaEndpoint: summaryProvider === 'ollama' ? endpoint?.replace(/\/v1\/?$/, '') : null});
        toast.success('已儲存兩步處理流程');
      })}>儲存處理流程</Button>
    </section>
  </div>;
}
