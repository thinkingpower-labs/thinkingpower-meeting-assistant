'use client';
export default function AnalyticsConsentSwitch() {
  return <section className="p-4 rounded border bg-slate-50"><h3 className="font-semibold">本機隱私</h3><p className="mt-2 text-sm">此改造版停用使用分析回傳。原始錄音與結果保留本機。選用雲端轉錄時會傳送音訊；選用雲端摘要時會傳送逐字稿與補充說明。開始處理前請核對目的服務。</p></section>;
}
