'use client';
import Link from 'next/link';
import { useState } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { toast } from 'sonner';
import { Button } from './ui/button';
import { useTranscriptionTasks, isActiveTask, type TranscriptionTask } from '@/hooks/useTranscriptionTasks';
export function TranscriptionCenterShortcut(){
  const {tasks}=useTranscriptionTasks();const count=tasks.filter(isActiveTask).length;
  return <Link href="/recordings" className="fixed bottom-5 right-5 z-40 rounded-full border bg-white px-4 py-3 text-sm shadow-lg">錄音與轉錄中心{count>0?` · ${count} 筆處理中`:''}</Link>;
}
const statuses:Record<string,string>={queued:'排隊中',running:'處理中',cancelling:'取消中',cancelled:'已取消',failed:'失敗，可接續',complete:'完成'};
const stages:Record<string,string>={queued:'等待工作槽',copying:'保存原音',decoding:'轉換音訊',transcribing:'辨識音訊',uploading:'等待雲端回應',saving:'儲存逐字稿',complete:'完成'};
export function TranscriptionTaskList({tasks,onListen}:{tasks:TranscriptionTask[];onListen?:(id:string,title:string)=>void}){
  const [pending,setPending]=useState<string[]>([]);
  return <div className="space-y-3">{tasks.map(task=><article key={task.job_id} className="rounded-xl border bg-white p-4 space-y-2" aria-label={`轉錄工作：${task.title}`}>
    <div className="flex flex-wrap justify-between gap-2"><h3 className="font-semibold">{task.title}</h3><span>{statuses[task.status]||task.status}</span></div>
    <p className="text-sm text-gray-600">{task.provider}／{task.model||'預設模型'} · {stages[task.stage]||task.stage}</p>
    <progress aria-label={`${task.title} 轉錄進度`} max={100} value={task.progress_percentage} className="w-full"/>
    <p className="text-sm">{task.progress_percentage}% · 已保存 {task.completed}{task.total>0?`／${task.total}`:''} 段</p>
    <p className="text-sm break-words" role="status">{task.message}</p>
    <div className="flex gap-2">
      {task.meeting_id&&<><Button size="sm" variant="outline" onClick={()=>onListen?.(task.meeting_id!,task.title)}>聆聽原音</Button><Link className="px-3 py-2 text-sm underline" href={`/meeting-details?id=${encodeURIComponent(task.meeting_id)}`}>開啟會議／接續</Link></>}
      {isActiveTask(task)&&<Button size="sm" variant="outline" disabled={task.status==='cancelling'||pending.includes(task.job_id)} onClick={async()=>{
        setPending(old=>[...old,task.job_id]);
        try{await invoke('cancel_transcription_task',{jobId:task.job_id});toast.info('已要求取消這筆工作，正在保留目前分段');}
        catch(error){toast.error(String(error));}
        finally{setPending(old=>old.filter(id=>id!==task.job_id));}
      }}>{task.status==='cancelling'?'正在取消…':'取消這筆轉錄'}</Button>}
    </div>
  </article>)}</div>;
}
