'use client';
import { useEffect, useState } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { toast } from 'sonner';
import { Button } from './ui/button';
import { serviceNames } from './AIWorkflowSettings';
import Link from 'next/link';
import { useTranscriptionTasks, isActiveTask } from '@/hooks/useTranscriptionTasks';

type Job = { meeting_id: string; stage: string; provider: string; model: string; endpoint: string | null; completed_chunks: string; error: string | null };
export function AudioJobStatus({meetingId, onUpdated}: {meetingId: string; onUpdated?: () => void}) {
  const [job, setJob] = useState<Job | null>(null);
  const [busy, setBusy] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const {tasks}=useTranscriptionTasks();
  const running=tasks.find(task=>task.meeting_id===meetingId&&isActiveTask(task));
  useEffect(() => {
    let active = true;
    const refresh = () => invoke<Job | null>('get_audio_job', {meetingId}).then(value => { if(active) setJob(value); }).catch(() => {});
    refresh(); const timer = setInterval(refresh, 4000);
    return () => { active = false; clearInterval(timer); };
  }, [meetingId]);
  if (!job) return null;
  const completed = ['transcribed', 'complete', 'summarizing', 'summary_failed'].includes(job.stage);
  const cloud = ['openai', 'groq', 'openrouter', 'custom-openai'].includes(job.provider);
  let count = 0; try { count = JSON.parse(job.completed_chunks).length; } catch {}
  const stages: Record<string, string> = {waiting: '等待處理', cancelled:'已取消，可接續', interrupted: '上次轉錄已中斷，可接續或選擇重新轉錄', uploading: '上傳中或上次上傳尚未確認', transcribing: '轉錄中', failed: '處理失敗', transcribed: '逐字稿已儲存', summarizing: '產生摘要中', complete: '完成'};
  return <div className="border-b bg-blue-50 px-4 py-3 text-sm space-y-2">
    <p>{job.stage === 'summary_failed' ? '摘要失敗，逐字稿仍保留' : stages[job.stage] || job.stage} · 已保存 {count} 段 · {serviceNames[job.provider]}／{job.model}</p>
    {job.error && <p className="text-red-700">{job.error}</p>}
    <Link href="/recordings" className="inline-block underline">開啟錄音與轉錄中心，查看所有工作</Link>
    {running&&<div className="space-y-2"><p>{running.message} · {running.progress_percentage}% · 已保存 {running.completed}{running.total?`／${running.total}`:''} 段</p><progress aria-label="此會議轉錄進度" value={running.progress_percentage} max={100} className="w-full"/><Button size="sm" variant="outline" disabled={running.status==='cancelling'} onClick={async()=>{try{await invoke('cancel_transcription_task',{jobId:running.job_id});toast.info('已要求取消這筆工作');}catch(error){toast.error(String(error));}}}>取消這筆轉錄</Button></div>}
    {!completed && !running && <>
      <p>原始錄音與已完成分段保留在本機。接續處理會沿用同一筆會議，略過已保存的分段。</p>
      {cloud && <p className="break-all">音訊目的地：{job.endpoint}／audio/transcriptions{job.provider === 'openrouter' ? '（由 OpenRouter 轉送至上游模型服務）' : ''}</p>}
      {cloud && <label className="flex gap-2"><input type="checkbox" checked={confirmed} onChange={event => setConfirmed(event.target.checked)}/>同意將尚未完成的音訊送至 {serviceNames[job.provider]}。上次逾時可能已計費，重試可能增加費用；請先確認服務用量。</label>}
      <Button size="sm" disabled={busy || (cloud && !confirmed)} onClick={async () => {
        setBusy(true);
        try { await invoke('resume_import_audio_command', {meetingId, cloudAuthorized: confirmed}); toast.success('逐字稿已完成'); onUpdated?.(); }
        catch(error) { toast.error(String(error)); }
        finally { setBusy(false); }
      }}>{busy ? '接續處理中…' : '接續未完成的轉錄'}</Button>
    </>}
    {completed && <p>若摘要失敗，只需重新產生摘要。AI 可能誤辨或推測人名、期限與決議，請播放原音核對。</p>}
  </div>;
}
