CREATE TABLE IF NOT EXISTS audio_jobs (
    meeting_id TEXT PRIMARY KEY NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
    source_path TEXT NOT NULL,
    provider TEXT NOT NULL,
    model TEXT,
    language TEXT,
    stage TEXT NOT NULL DEFAULT 'waiting',
    completed_chunks TEXT NOT NULL DEFAULT '[]',
    error TEXT,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
