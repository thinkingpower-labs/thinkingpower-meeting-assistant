ALTER TABLE audio_jobs ADD COLUMN attempt_id TEXT;
CREATE TABLE audio_job_history (
    id TEXT PRIMARY KEY NOT NULL,
    meeting_id TEXT NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
    job_json TEXT NOT NULL,
    transcripts_json TEXT NOT NULL DEFAULT '[]',
    archived_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
