CREATE TABLE IF NOT EXISTS service_connections (
    provider TEXT PRIMARY KEY NOT NULL,
    endpoint TEXT NOT NULL,
    text_model TEXT NOT NULL DEFAULT '',
    audio_model TEXT NOT NULL DEFAULT '',
    text_verified INTEGER NOT NULL DEFAULT 0,
    audio_verified INTEGER NOT NULL DEFAULT 0
);
