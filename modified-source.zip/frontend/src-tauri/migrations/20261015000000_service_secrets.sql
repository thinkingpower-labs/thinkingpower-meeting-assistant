-- Keys are encrypted by Windows user-bound DPAPI before reaching SQLite.
CREATE TABLE IF NOT EXISTS service_secrets (
    provider TEXT PRIMARY KEY NOT NULL,
    protected_key BLOB NOT NULL
);
