ALTER TABLE audio_jobs ADD COLUMN source_sha256 TEXT;
ALTER TABLE audio_jobs ADD COLUMN endpoint TEXT;
