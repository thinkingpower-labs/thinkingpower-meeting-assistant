# ThinkingPower meeting templates

Five English instruction templates: General Meeting Minutes (default), Team Retrospective and Improvement, Client and Partnership Discussions, Interview Notes, Course and Lecture Notes.

All use common_rules.txt and directly follow the selected summary language; Auto follows the dominant transcript language. English instructions do not require English output.

Legacy daily_standup and project_sync selections resolve to standard_meeting. The psychiatric template is retired. User custom files are not deleted.

Source loading order: user custom template, bundled template, embedded fallback. All five shipped templates have embedded fallbacks.
