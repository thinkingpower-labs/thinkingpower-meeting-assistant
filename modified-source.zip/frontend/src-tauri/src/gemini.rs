//! Google Gemini native Interactions API. Credentials never enter URLs or logs.
use base64::Engine;
use serde_json::{json, Value};
use std::{path::Path, time::Duration};
use tokio_util::sync::CancellationToken;
use crate::audio::{cloud_transcription::CloudTranscript, diarization::Segment, transcription_tasks::Task};

pub const ENDPOINT: &str = "https://generativelanguage.googleapis.com/v1beta";
pub const AUDIO_MODEL: &str = "gemini-3.8-flash";
pub const SPEAKER_MODEL: &str = "gemini-3.5-transcribe";

pub fn text_models(value: &Value) -> Vec<String> {
    let mut ids = value["models"].as_array().into_iter().flatten().filter_map(|v| {
        let id = v["name"].as_str()?.strip_prefix("models/").unwrap_or(v["name"].as_str()?);
        if !id.starts_with("gemini-") || ["image","tts","live","embedding","transcribe","robotics"].iter().any(|s|id.contains(s)) {return None;}
        Some(id.to_string())
    }).collect::<Vec<_>>();
    ids.sort();ids.dedup();ids
}

async fn request(base: &str, key: &str, body: Value, token: Option<&CancellationToken>) -> Result<Value,String> {
    if key.trim().is_empty() {return Err("請先在 Google Gemini 連線儲存 API Key。".into());}
    let client = reqwest::Client::builder().connect_timeout(Duration::from_secs(15)).timeout(Duration::from_secs(if body["model"]==SPEAKER_MODEL {1800}else{300}))
        .redirect(reqwest::redirect::Policy::none()).build().map_err(|_|"無法建立 Google 連線")?;
    let operation = async {
        let mut response=client.post(format!("{}/interactions",base.trim_end_matches('/'))).header("x-goog-api-key",key)
            .json(&body).send().await.map_err(crate::audio::cloud_transcription::network_error)?;
        if !response.status().is_success(){return Err(crate::audio::cloud_transcription::status_error(response.status().as_u16()));}
        let mut bytes=Vec::new();
        while let Some(chunk)=response.chunk().await.map_err(crate::audio::cloud_transcription::network_error)? {
            if bytes.len()+chunk.len()>16_000_000{return Err("Google 結果超過大小上限，未自動重送。".into());}
            bytes.extend_from_slice(&chunk);
        }
        let value:Value=serde_json::from_slice(&bytes).map_err(|_|"Google 回傳格式無法讀取，未自動重送。")?;
        if value["status"]!="completed" {return Err("Google 尚未完整完成此次處理；原音、舊稿與已保存內容仍保留，未自動重送。".into());}
        Ok(value)
    };
    if let Some(token)=token {tokio::select!{biased;_=token.cancelled()=>Err("已取消 Google 請求等待；已送出內容仍可能計費，未自動重送。".into()),result=operation=>result}}
    else {operation.await}
}

fn output_text(value:&Value)->Result<String,String>{
    let text=value["steps"].as_array().into_iter().flatten().filter(|step|step["type"]=="model_output")
        .flat_map(|step|step["content"].as_array().into_iter().flatten()).filter(|content|content["type"]=="text")
        .filter_map(|content|content["text"].as_str()).collect::<Vec<_>>().join("\n");
    if text.trim().is_empty(){Err("Google 未回傳可用文字；舊內容保留。".into())}else{Ok(text)}
}

pub async fn summary(base:&str,key:&str,model:&str,system:&str,user:&str,token:Option<&CancellationToken>)->Result<String,String>{
    let value=request(base,key,json!({"model":model,"system_instruction":system,"input":user,"store":false}),token).await?;
    output_text(&value)
}

pub async fn transcribe_chunk(base:&str,key:Option<&str>,model:&str,language:Option<&str>,samples:&[f32])->Result<CloudTranscript,String>{
    if model!=AUDIO_MODEL{return Err("Google 分段轉錄模型不受支援，請重新選擇。".into());}
    let prompt=format!("Transcribe every spoken word verbatim from this audio, preserving repetitions and filler words. Do not summarize or infer speaker names. Return only the transcript, no markdown. Language hint: {}. For Chinese, use Traditional Chinese characters. Do not invent speech during silence.",language.unwrap_or("auto"));
    let value=request(base,key.unwrap_or(""),json!({"model":model,"store":false,"input":[{"type":"text","text":prompt},
        {"type":"audio","mime_type":"audio/wav","data":base64::engine::general_purpose::STANDARD.encode(crate::audio::cloud_transcription::wav(samples))}]}),None).await?;
    Ok(CloudTranscript{text:output_text(&value)?,segments:None,words:None,usage:value.get("usage").cloned()})
}

pub async fn test_audio(base:&str,key:Option<&str>,model:&str)->Result<(),String>{
    if ![AUDIO_MODEL,SPEAKER_MODEL].contains(&model){return Err("請先選擇支援的 Google 音訊模型。".into());}
    let mut body=json!({"model":model,"store":false,"input":[{"type":"audio","mime_type":"audio/wav",
        "data":base64::engine::general_purpose::STANDARD.encode(crate::audio::cloud_transcription::wav(&[0.0;16000]))}]});
    if model==SPEAKER_MODEL{body["generation_config"]=json!({"transcription_config":{"mode":{"type":"verbatim","diarization_mode":"speaker","timestamp_granularities":["word"]}}});}
    request(base,key.unwrap_or(""),body,None).await?;Ok(())
}

fn seconds(value:&Value)->Result<f64,String>{
    let parsed=value.as_str().and_then(|s|s.strip_suffix('s')).and_then(|s|s.parse::<f64>().ok())
        .filter(|n|n.is_finite()&&*n>=0.0).ok_or("Google 詞語時間格式不完整；舊稿保留。")?;
    Ok(parsed)
}

pub fn speaker_segments(value:&Value,duration:f64)->Result<Vec<Segment>,String>{
    if value["status"]!="completed" {return Err("Google 說話人結果尚未完成。".into());}
    let mut segments:Vec<Segment>=Vec::new();
    for step in value["steps"].as_array().into_iter().flatten().filter(|s|s["type"]=="model_output") {
        for content in step["content"].as_array().into_iter().flatten().filter(|c|c["type"]=="text") {
            for word in content["annotations"].as_array().into_iter().flatten().filter(|a|a["type"]=="word_info") {
                let text=word["text"].as_str().filter(|s|!s.trim().is_empty()).ok_or("Google 詞語內容不完整。")?.to_string();
                let start=seconds(&word["start_offset"])?;let end=seconds(&word["end_offset"])?;
                let speaker=word["speaker"].as_str().filter(|s|!s.is_empty()).ok_or("Google 未提供完整的說話人標示，舊稿保留。")?.to_string();
                if let Some(last)=segments.last_mut(){
                    if last.speaker.as_deref()==Some(&speaker)&&start>=last.end&&start-last.end<=1.0&&end-last.start<=20.0&&end>start{
                        if last.text.chars().last().is_some_and(|c|c.is_ascii_alphanumeric())&&text.chars().next().is_some_and(|c|c.is_ascii_alphanumeric()){last.text.push(' ');}
                        last.text.push_str(&text);last.end=end;continue;
                    }
                }
                segments.push(Segment{start,end,text,speaker:Some(speaker)});
            }
        }
    }
    // Reuse the same strict timing and label validation as other speaker providers.
    let bytes=serde_json::to_vec(&json!({"segments":segments})).map_err(|_|"無法處理 Google 分段")?;
    crate::audio::diarization::parse(&bytes,duration).map_err(|e|e.to_string())
}

pub(crate) async fn diarize(source:&Path,folder:&Path,base:&str,key:Option<&str>,duration:f64,task:&Task)->Result<Vec<Segment>,String>{
    let cache=folder.join("gemini-speakers.json");
    if cache.exists(){
        if std::fs::metadata(&cache).map_err(|_|"無法讀取 Google 快取")?.len()>16_000_000{return Err("Google 快取超過大小上限。".into());}
        let value=serde_json::from_slice(&std::fs::read(&cache).map_err(|_|"無法讀取 Google 快取")?).map_err(|_|"Google 快取格式損壞，為避免重複付費已停止。")?;
        return speaker_segments(&value,duration);
    }
    if duration>1800.0{return Err("Google 說話人分離最多 30 分鐘；更長錄音可選 Google 一般分段轉錄，或其他服務。原音與舊稿保留，尚未上傳。".into());}
    task.check()?;
    task.progress("decoding",25,"準備 Google 說話人辨識音訊…");
    let compressed=folder.join("gemini-upload.mp3");
    let args=["-hide_banner","-nostdin","-loglevel","error","-y","-i"].iter().map(std::ffi::OsString::from)
        .chain(std::iter::once(source.as_os_str().to_owned())).chain(["-vn","-ac","1","-ar","16000","-c:a","libmp3lame","-b:a","24k"].iter().map(std::ffi::OsString::from))
        .chain(std::iter::once(compressed.as_os_str().to_owned())).collect::<Vec<_>>();
    let token=task.cancellation_token();
    tokio::select!{biased;_=token.cancelled()=>return Err("已取消，尚未上傳 Google。".into()),r=crate::audio::recording_safety::ffmpeg(&args,Duration::from_secs(900),folder,"gemini_encode")=>r.map_err(|_|"無法準備 Google 音訊，原音保留。")?}
    let size=std::fs::metadata(&compressed).map_err(|_|"找不到 Google 辨識音訊")?.len();
    // Base64 plus prompt/config must stay below Google's 20 MB inline limit.
    if size==0||size>14_000_000{return Err("Google 音訊超過內嵌請求上限，尚未上傳。".into());}
    task.check()?;task.chunks(0,1);task.progress("uploading",40,"Google 正在辨識說話人；服務未提供實際百分比，取消後仍可能計費。");
    let audio=base64::engine::general_purpose::STANDARD.encode(std::fs::read(&compressed).map_err(|_|"無法讀取 Google 辨識音訊")?);
    let value=request(base,key.unwrap_or(""),json!({"model":SPEAKER_MODEL,"store":false,"input":[{"type":"audio","mime_type":"audio/mp3","data":audio}],
        "generation_config":{"transcription_config":{"mode":{"type":"verbatim","diarization_mode":"speaker","timestamp_granularities":["word"]}}}}),Some(&token)).await?;
    crate::audio::recording_safety::atomic_json(&cache,&value).map_err(|_|"無法保存 Google 結果；原音與舊稿保留。")?;
    let _=std::fs::remove_file(compressed);task.check()?;
    speaker_segments(&value,duration)
}

#[cfg(test)] mod tests{
    use super::*;
    fn fixture()->Value{json!({"status":"completed","steps":[{"type":"model_output","content":[{"type":"text","text":"Hello world你好","annotations":[
        {"type":"word_info","text":"Hello","speaker":"A","start_offset":"0s","end_offset":"1s"},
        {"type":"word_info","text":"world","speaker":"A","start_offset":"1s","end_offset":"2s"},
        {"type":"word_info","text":"你好","speaker":"B","start_offset":"2s","end_offset":"3s"}]}]}]})}
    #[test]fn parses_native_words_without_guessing_names(){
        let value=fixture();let rows=speaker_segments(&value,3.0).unwrap();assert_eq!(rows.len(),2);assert_eq!(rows[0].text,"Hello world");assert_eq!(rows[1].speaker.as_deref(),Some("B"));
        assert!(speaker_segments(&value,0.1).is_err());
        let mut missing=value.clone();missing["steps"][0]["content"][0]["annotations"][0]["speaker"]=Value::Null;assert!(speaker_segments(&missing,3.0).is_err());
        assert_eq!(text_models(&json!({"models":[{"name":"models/gemini-3.8-flash"},{"name":"models/gemini-3.5-transcribe"},{"name":"models/gemini-3.8-flash-tts"}]})),vec![AUDIO_MODEL]);
    }
    #[tokio::test]async fn native_transport_uses_header_stateless_body_and_completed_output(){
        use tokio::{net::TcpListener,io::{AsyncReadExt,AsyncWriteExt}};
        let listener=TcpListener::bind("127.0.0.1:0").await.unwrap();let address=listener.local_addr().unwrap();
        let server=tokio::spawn(async move{
            let(mut stream,_)=listener.accept().await.unwrap();let mut data=Vec::new();let mut buffer=[0u8;8192];
            loop{let n=stream.read(&mut buffer).await.unwrap();assert!(n>0);data.extend_from_slice(&buffer[..n]);if let Some(end)=data.windows(4).position(|w|w==b"\r\n\r\n"){
                let header=String::from_utf8_lossy(&data[..end]).to_lowercase();let length:usize=header.lines().find_map(|l|l.strip_prefix("content-length:")).unwrap().trim().parse().unwrap();
                if data.len()>=end+4+length{assert!(header.starts_with("post /interactions ")&&header.contains("x-goog-api-key: fake-google-key"));let body:Value=serde_json::from_slice(&data[end+4..]).unwrap();assert_eq!(body["store"],false);assert_eq!(body["model"],AUDIO_MODEL);assert_eq!(body["input"][1]["mime_type"],"audio/wav");break;}}
            }
            let body=fixture().to_string();stream.write_all(format!("HTTP/1.1 200 OK\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",body.len(),body).as_bytes()).await.unwrap();
        });
        let result=transcribe_chunk(&format!("http://{address}"),Some("fake-google-key"),AUDIO_MODEL,Some("zh"),&[0.1;1600]).await.unwrap();assert_eq!(result.text,"Hello world你好");server.await.unwrap();
        let token=CancellationToken::new();token.cancel();assert!(summary("http://127.0.0.1:1","fake",AUDIO_MODEL,"sys","user",Some(&token)).await.unwrap_err().contains("取消"));
    }
    #[tokio::test]async fn whole_speaker_request_is_cached_and_oversize_stops_before_upload(){
        use tokio::{net::TcpListener,io::{AsyncReadExt,AsyncWriteExt}};
        let listener=TcpListener::bind("127.0.0.1:0").await.unwrap();let address=listener.local_addr().unwrap();
        let server=tokio::spawn(async move{
            let(mut stream,_)=listener.accept().await.unwrap();let mut data=Vec::new();let mut buffer=[0u8;8192];
            loop{let n=stream.read(&mut buffer).await.unwrap();assert!(n>0);data.extend_from_slice(&buffer[..n]);if let Some(end)=data.windows(4).position(|w|w==b"\r\n\r\n"){
                let header=String::from_utf8_lossy(&data[..end]).to_lowercase();let length:usize=header.lines().find_map(|l|l.strip_prefix("content-length:")).unwrap().trim().parse().unwrap();
                if data.len()>=end+4+length{let body:Value=serde_json::from_slice(&data[end+4..]).unwrap();assert_eq!(body["model"],SPEAKER_MODEL);assert_eq!(body["store"],false);assert_eq!(body["input"][0]["mime_type"],"audio/mp3");assert_eq!(body["generation_config"]["transcription_config"]["mode"]["diarization_mode"],"speaker");assert!(body["input"][0]["data"].as_str().unwrap().len()>100);break;}}
            }
            let body=fixture().to_string();stream.write_all(format!("HTTP/1.1 200 OK\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",body.len(),body).as_bytes()).await.unwrap();
        });
        let dir=tempfile::tempdir().unwrap();let source=dir.path().join("source.wav");std::fs::write(&source,crate::audio::cloud_transcription::wav(&vec![0.1;48000])).unwrap();
        let task=Task::register(None,"Google synthetic".into(),"gemini".into(),Some(SPEAKER_MODEL.into()),None).unwrap();
        let rows=diarize(&source,dir.path(),&format!("http://{address}"),Some("fake-google-key"),3.0,&task).await.unwrap();server.await.unwrap();assert_eq!(rows.len(),2);
        assert_eq!(diarize(&source,dir.path(),"http://127.0.0.1:1",None,3.0,&task).await.unwrap().len(),2);
        let other=dir.path().join("too-long");std::fs::create_dir(&other).unwrap();
        assert!(diarize(&source,&other,"http://127.0.0.1:1",None,1801.0,&task).await.unwrap_err().contains("30 分鐘"));
        assert!(!other.join("gemini-upload.mp3").exists());task.finish(true,None);
    }
}
