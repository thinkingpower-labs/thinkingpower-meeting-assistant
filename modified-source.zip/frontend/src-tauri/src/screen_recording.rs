//! Optional, local-only window recording. Never fall back to desktop capture.
use once_cell::sync::Lazy;
use serde::{Deserialize, Serialize};
use std::{fs, io::Write, path::PathBuf, process::{Child, Command, Stdio}, sync::Mutex, time::{Duration, Instant}};

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct CaptureWindow { pub id: usize, pub pid: u32, pub title: String }

#[cfg(windows)]
mod native {
    use super::*;
    #[link(name = "user32")]
    extern "system" {
        fn EnumWindows(callback: unsafe extern "system" fn(isize, isize) -> i32, data: isize) -> i32;
        fn IsWindowVisible(hwnd: isize) -> i32;
        fn IsIconic(hwnd: isize) -> i32;
        fn GetWindowTextW(hwnd: isize, text: *mut u16, count: i32) -> i32;
        fn GetWindowThreadProcessId(hwnd: isize, pid: *mut u32) -> u32;
    }
    unsafe extern "system" fn collect(hwnd: isize, data: isize) -> i32 {
        if IsWindowVisible(hwnd) == 0 || IsIconic(hwnd) != 0 { return 1; }
        let mut title = [0u16; 1024];
        let len = GetWindowTextW(hwnd, title.as_mut_ptr(), title.len() as i32);
        let mut pid = 0;
        GetWindowThreadProcessId(hwnd, &mut pid);
        if len > 0 {
            let windows = &mut *(data as *mut Vec<CaptureWindow>);
            windows.push(CaptureWindow { id: hwnd as usize, pid, title: String::from_utf16_lossy(&title[..len as usize]) });
        }
        1
    }
    pub fn windows() -> Vec<CaptureWindow> {
        let mut windows: Vec<CaptureWindow> = Vec::new();
        unsafe { EnumWindows(collect, &mut windows as *mut _ as isize); }
        windows.sort_by(|a, b| a.title.cmp(&b.title));
        windows
    }
}

#[tauri::command]
pub fn screen_windows() -> Vec<CaptureWindow> {
    #[cfg(windows)] { native::windows() }
    #[cfg(not(windows))] { Vec::new() }
}

static SELECTED: Lazy<Mutex<Option<CaptureWindow>>> = Lazy::new(|| Mutex::new(None));
static SESSION: Lazy<Mutex<Option<ScreenSession>>> = Lazy::new(|| Mutex::new(None));

#[tauri::command]
pub async fn screen_select(window: Option<CaptureWindow>) -> Result<(), String> {
    if crate::audio::recording_commands::is_recording().await || SESSION.lock().unwrap().is_some() {
        return Err("請先停止錄音，再變更錄影視窗。".into());
    }
    if let Some(ref w) = window { validate_window(w)?; }
    *SELECTED.lock().unwrap() = window;
    Ok(())
}

fn validate_window(w: &CaptureWindow) -> Result<(), String> {
    if screen_windows().iter().any(|current| current.id == w.id && current.pid == w.pid) { Ok(()) }
    else { Err("選取的視窗已關閉或最小化，請重新選擇。".into()) }
}

#[derive(Serialize)]
pub struct ScreenStatus { selected: Option<CaptureWindow>, recording: bool, paused: bool, error: Option<String> }
#[tauri::command]
pub fn screen_status() -> ScreenStatus {
    let mut session = SESSION.lock().unwrap();
    if let Some(s) = session.as_mut() {
        #[cfg(windows)]
        if let Some(capture) = s.capture.as_ref() { if let Some(error) = capture.error() { s.error = Some(error); } }
        if let Some(child) = s.child.as_mut() {
            if let Ok(Some(_)) = child.try_wait() {
                s.error = Some("視窗錄影已中斷；聲音錄製仍繼續。停止後請檢查影片。".into());
                s.child = None;
            }
        }
        ScreenStatus { selected: Some(s.window.clone()), recording: s.child.is_some(), paused: s.paused, error: s.error.clone() }
    } else {
        ScreenStatus { selected: SELECTED.lock().unwrap().clone(), recording: false, paused: false, error: None }
    }
}

pub fn preflight(in_person: bool, auto_save: bool) -> Result<(), String> {
    if in_person { return Ok(()); }
    if let Some(w) = SELECTED.lock().unwrap().as_ref() {
        if !auto_save { return Err("錄製視窗前，請先在設定開啟「儲存錄音檔」。".into()); }
        validate_window(w)?;
    }
    Ok(())
}

fn ffmpeg() -> Result<Command, String> {
    let path = crate::audio::ffmpeg::find_ffmpeg_path().ok_or("找不到影片編碼程式。")?;
    let mut command = Command::new(path);
    #[cfg(windows)] {
        use std::os::windows::process::CommandExt;
        command.creation_flags(0x08000000);
    }
    Ok(command)
}

pub struct ScreenSession {
    window: CaptureWindow,
    folder: PathBuf,
    child: Option<Child>,
    #[cfg(windows)]
    capture: Option<crate::screen_capture_windows::Capture>,
    parts: Vec<PathBuf>,
    paused: bool,
    error: Option<String>,
}
impl ScreenSession {
    fn start_part(&mut self) -> Result<(), String> {
        validate_window(&self.window)?;
        let path = self.folder.join(format!("screen-part-{:04}.mkv", self.parts.len()));
        let log = fs::File::create(self.folder.join(format!("screen-part-{:04}.log", self.parts.len()))).map_err(|e| e.to_string())?;
        #[cfg(not(windows))]
        return Err("視窗錄影目前只支援 Windows。".into());
        #[cfg(windows)]
        let mut capture = crate::screen_capture_windows::Capture::new(self.window.id)?;
        #[cfg(windows)]
        let (width, height) = capture.size();
        #[cfg(not(windows))]
        let (width, height) = (0, 0);
        let mut child = ffmpeg()?.args(["-hide_banner", "-loglevel", "warning", "-n", "-use_wallclock_as_timestamps", "1", "-f", "rawvideo", "-pixel_format", "bgra", "-video_size"])
            .arg(format!("{}x{}", width, height)).args(["-framerate", "15", "-i", "pipe:0"])
            .args(["-an", "-vf", "scale=1920:1080:force_original_aspect_ratio=decrease:force_divisible_by=2,pad=1920:1080:(ow-iw)/2:(oh-ih)/2", "-c:v", "libx264", "-preset", "ultrafast", "-crf", "23", "-threads", "2", "-pix_fmt", "yuv420p", "-g", "30", "-flush_packets", "1"])
            .arg(&path).stdin(Stdio::piped()).stdout(Stdio::null()).stderr(log).spawn().map_err(|e| e.to_string())?;
        #[cfg(windows)] {
            capture.feed(child.stdin.take().ok_or("無法開啟影片寫入通道。")?);
            self.capture = Some(capture);
        }
        std::thread::sleep(Duration::from_millis(350));
        if child.try_wait().map_err(|e| e.to_string())?.is_some() {
            return Err("無法錄製此視窗，請保持視窗開啟且不要最小化，再重試。".into());
        }
        self.parts.push(path);
        self.child = Some(child);
        Ok(())
    }
    fn stop_part(&mut self) {
        #[cfg(windows)]
        if let Some(capture) = self.capture.as_mut() {
            if let Some(error) = capture.error() { self.error = Some(error); }
            capture.request_stop();
        }
        if let Some(mut child) = self.child.take() {
            if let Some(mut stdin) = child.stdin.take() { let _ = stdin.write_all(b"q\n"); }
            let deadline = Instant::now() + Duration::from_secs(5);
            loop {
                match child.try_wait() {
                    Ok(Some(status)) => {
                        if !status.success() { self.error = Some("部分錄影未正常結束，已保留原始片段。".into()); }
                        break;
                    }
                    _ if Instant::now() >= deadline => {
                        let _ = child.kill(); let _ = child.wait();
                        self.error = Some("錄影停止逾時，已保留可復原片段。".into()); break;
                    }
                    _ => std::thread::sleep(Duration::from_millis(50)),
                }
            }
        }
        #[cfg(windows)]
        if let Some(mut capture) = self.capture.take() { capture.join(); }
    }
    pub fn finish(mut self) -> Result<String, String> {
        self.stop_part();
        if self.parts.is_empty() { return Err("沒有可合併的錄影片段。".into()); }
        // Relative, application-generated names only. No shell or user-supplied concat directives.
        let list = self.parts.iter().map(|p| format!("file '{}'\n", p.file_name().unwrap().to_string_lossy())).collect::<String>();
        fs::write(self.folder.join("screen-parts.txt"), list).map_err(|e| e.to_string())?;
        let audio = self.folder.join("audio.mp4");
        let output = self.folder.join("meeting-video.mp4");
        let silent = self.folder.join("screen-video.mp4");
        let mut command = ffmpeg()?;
        command.current_dir(&self.folder).args(["-hide_banner", "-loglevel", "error", "-n", "-f", "concat", "-safe", "1", "-i", "screen-parts.txt"]);
        if audio.exists() {
            command.arg("-i").arg(&audio).args(["-map", "0:v:0", "-map", "1:a:0", "-c", "copy", "-movflags", "+faststart"]).arg(&output);
        } else {
            command.args(["-c", "copy", "-movflags", "+faststart"]).arg(&silent);
        }
        let log = fs::File::create(self.folder.join("screen-merge.log")).map_err(|e| e.to_string())?;
        let mut child = command.stdin(Stdio::null()).stdout(Stdio::null()).stderr(log).spawn().map_err(|e| e.to_string())?;
        let deadline = Instant::now() + Duration::from_secs(180);
        loop {
            if let Some(status) = child.try_wait().map_err(|e| e.to_string())? {
                if !status.success() { return Err("影片合併失敗，原始錄影片段與音檔仍保留在會議資料夾。".into()); }
                break;
            }
            if Instant::now() > deadline { let _ = child.kill(); let _ = child.wait(); return Err("影片合併逾時，已保留原始片段與音檔。".into()); }
            std::thread::sleep(Duration::from_millis(100));
        }
        if let Some(error) = self.error.as_ref() { return Err(error.clone()); }
        if !audio.exists() { return Err("畫面已存為 screen-video.mp4，但找不到完整音檔；請檢查錄音存檔。".into()); }
        Ok(output.to_string_lossy().into_owned())
    }
}
impl Drop for ScreenSession { fn drop(&mut self) { self.stop_part(); } }

pub fn start(folder: Option<PathBuf>, in_person: bool) -> Result<(), String> {
    if in_person { return Ok(()); }
    let Some(window) = SELECTED.lock().unwrap().take() else { return Ok(()); };
    let folder = folder.ok_or("無法建立會議資料夾，視窗錄影未開始。")?;
    let mut guard = SESSION.lock().unwrap();
    if guard.is_some() { return Err("上一段影片仍在處理。".into()); }
    let mut session = ScreenSession { window, folder, child: None, #[cfg(windows)] capture: None, parts: Vec::new(), paused: false, error: None };
    session.start_part()?;
    *guard = Some(session);
    Ok(())
}
pub fn pause() { if let Some(s) = SESSION.lock().unwrap().as_mut() { s.stop_part(); s.paused = true; } }
pub fn resume() -> Result<(), String> {
    if let Some(s) = SESSION.lock().unwrap().as_mut() {
        if s.paused { s.start_part().map_err(|e| { s.error = Some(e.clone()); e })?; s.paused = false; }
    }
    Ok(())
}
pub fn stop() -> Option<ScreenSession> {
    let mut session = SESSION.lock().unwrap().take();
    // Request EOF immediately. Join/merge only after audio capture has stopped.
    #[cfg(windows)]
    if let Some(s) = session.as_mut() {
        if let Some(capture) = s.capture.as_mut() {
            if let Some(error) = capture.error() { s.error = Some(error); }
            capture.request_stop();
        }
    }
    session
}

#[cfg(all(test, windows))]
mod tests {
    use super::*;
    #[test]
    fn missing_window_never_falls_back_to_desktop() {
        assert!(validate_window(&CaptureWindow { id: 0, pid: 0, title: "missing".into() }).is_err());
    }
    #[test]
    #[ignore = "requires an explicitly selected test window; records no microphone"]
    fn records_selected_window_pauses_and_muxes_synthetic_audio() {
        assert!(SELECTED.lock().unwrap().is_none());
        start(None, false).unwrap();
        assert!(stop().is_none()); // Default/opt-out performs no capture or file creation.
        let id: usize = std::env::var("FLYBIRD_CAPTURE_TEST_HWND").unwrap().parse().unwrap();
        let window = screen_windows().into_iter().find(|w| w.id == id).expect("test window must be visible");
        let folder = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../../audit")
            .join(format!("screen-test-{}", chrono::Utc::now().format("%Y%m%d-%H%M%S")));
        fs::create_dir_all(&folder).unwrap();
        *SELECTED.lock().unwrap() = Some(window.clone());
        assert!(preflight(false, false).is_err());
        start(Some(folder.clone()), true).unwrap(); // In-person mode never captures.
        assert!(stop().is_none());
        start(Some(folder.clone()), false).unwrap();
        assert!(screen_status().recording);
        assert!(SELECTED.lock().unwrap().is_none()); // Selection is one meeting only.
        std::thread::sleep(Duration::from_secs(3));
        pause(); assert!(screen_status().paused);
        std::thread::sleep(Duration::from_secs(2));
        resume().unwrap(); assert!(screen_status().recording);
        std::thread::sleep(Duration::from_secs(3));
        let session = stop().unwrap();
        let status = ffmpeg().unwrap().args(["-hide_banner", "-loglevel", "error", "-n", "-f", "lavfi", "-i", "sine=frequency=440:duration=7", "-c:a", "aac"])
            .arg(folder.join("audio.mp4")).status().unwrap();
        assert!(status.success());
        let path = session.finish().unwrap();
        assert!(fs::metadata(&path).unwrap().len() > 1000);
        // Decode BOTH tracks, so a playable-looking but truncated/corrupt file fails.
        let status = ffmpeg().unwrap().args(["-hide_banner", "-loglevel", "error", "-xerror", "-i"])
            .arg(&path).args(["-map", "0:v:0", "-map", "0:a:0", "-f", "null", "-"]).status().unwrap();
        assert!(status.success());
        assert!(folder.join("audio.mp4").exists());
        println!("SCREEN_TEST_OUTPUT={}", path);
    }
}
