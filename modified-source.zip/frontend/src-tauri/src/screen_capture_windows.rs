//! Windows Graphics Capture isolates the selected HWND even when another app covers it.
use std::{io::Write, process::ChildStdin, sync::{Arc, Mutex, atomic::{AtomicBool, Ordering}}, thread::JoinHandle, time::{Duration, Instant}};
use windows_capture::{capture::{CaptureControl, Context, GraphicsCaptureApiHandler}, frame::Frame,
    graphics_capture_api::InternalCaptureControl, settings::*, window::Window};

#[derive(Default)]
struct Latest { width: u32, height: u32, pixels: Arc<Vec<u8>>, error: Option<String> }
struct Handler { latest: Arc<Mutex<Latest>> }
impl GraphicsCaptureApiHandler for Handler {
    type Flags = Arc<Mutex<Latest>>;
    type Error = String;
    fn new(ctx: Context<Self::Flags>) -> Result<Self, String> { Ok(Self { latest: ctx.flags }) }
    fn on_frame_arrived(&mut self, frame: &mut Frame<'_>, control: InternalCaptureControl) -> Result<(), String> {
        let (width, height) = (frame.width(), frame.height());
        let result = (|| {
            let buffer = frame.buffer().map_err(|e| e.to_string())?;
            let mut scratch = Vec::new();
            let pixels = Arc::new(buffer.as_nopadding_buffer(&mut scratch).to_vec());
            let mut latest = self.latest.lock().unwrap();
            if latest.width != 0 && (latest.width != width || latest.height != height) {
                return Err("錄影視窗大小已變更，畫面錄製已停止；聲音仍繼續。".to_string());
            }
            latest.width = width; latest.height = height; latest.pixels = pixels;
            Ok(())
        })();
        if let Err(error) = result { self.latest.lock().unwrap().error = Some(error); control.stop(); }
        Ok(())
    }
    fn on_closed(&mut self) -> Result<(), String> {
        self.latest.lock().unwrap().error = Some("所選視窗已關閉，畫面錄製已停止；聲音仍繼續。".into());
        Ok(())
    }
}
pub struct Capture {
    control: Option<CaptureControl<Handler, String>>,
    latest: Arc<Mutex<Latest>>,
    halt: Arc<AtomicBool>,
    feeder: Option<JoinHandle<()>>,
}
impl Capture {
    pub fn new(hwnd: usize) -> Result<Self, String> {
        let latest = Arc::new(Mutex::new(Latest::default()));
        let settings = Settings::new(Window::from_raw_hwnd(hwnd as *mut _), CursorCaptureSettings::Default,
            DrawBorderSettings::Default, SecondaryWindowSettings::Default,
            MinimumUpdateIntervalSettings::Default, DirtyRegionSettings::Default, ColorFormat::Bgra8, latest.clone());
        let control = Handler::start_free_threaded(settings).map_err(|e| e.to_string())?;
        let result = Self { control: Some(control), latest, halt: Arc::new(AtomicBool::new(false)), feeder: None };
        let deadline = Instant::now() + Duration::from_secs(5);
        loop {
            if result.latest.lock().unwrap().width > 0 { return Ok(result); }
            if let Some(error) = result.error() { return Err(error); }
            if Instant::now() > deadline { return Err("無法取得視窗畫面，請保持視窗開啟且不要最小化。".into()); }
            std::thread::sleep(Duration::from_millis(20));
        }
    }
    pub fn size(&self) -> (u32, u32) { let latest = self.latest.lock().unwrap(); (latest.width, latest.height) }
    pub fn error(&self) -> Option<String> {
        self.latest.lock().unwrap().error.clone().or_else(|| {
            self.control.as_ref().filter(|c| c.is_finished()).map(|_| "視窗擷取已中斷，聲音仍繼續。".into())
        })
    }
    pub fn feed(&mut self, mut stdin: ChildStdin) {
        let latest = self.latest.clone(); let halt = self.halt.clone();
        self.feeder = Some(std::thread::spawn(move || {
            let mut next = Instant::now();
            while !halt.load(Ordering::SeqCst) {
                let pixels = { let state = latest.lock().unwrap(); if state.error.is_some() { break; } state.pixels.clone() };
                if stdin.write_all(&pixels).is_err() { break; }
                next += Duration::from_micros(66_667);
                if let Some(wait) = next.checked_duration_since(Instant::now()) { std::thread::sleep(wait); }
                else { next = Instant::now(); }
            }
            // Dropping stdin sends EOF, allowing FFmpeg to finalize its Matroska file.
        }));
    }
    pub fn request_stop(&mut self) {
        self.halt.store(true, Ordering::SeqCst);
        if let Some(control) = self.control.take() { let _ = control.stop(); }
    }
    pub fn join(&mut self) { if let Some(feeder) = self.feeder.take() { let _ = feeder.join(); } }
}
impl Drop for Capture { fn drop(&mut self) { self.request_stop(); /* Encoder owner closes the pipe before joining. */ } }
