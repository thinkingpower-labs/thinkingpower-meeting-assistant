use std::path::PathBuf;
use anyhow::{Result, anyhow};
use log::{info, warn};
use super::encode::encode_single_audio;
use super::recording_state::AudioChunk;
use serde::{Serialize, Deserialize};

#[cfg(test)]
use super::ffmpeg::find_ffmpeg_path;

/// Audio data without device type (we only store mixed audio)
#[derive(Clone)]
struct AudioData {
    data: Vec<f32>,
    // sample_rate: u32,
}

/// Incremental audio saver that writes checkpoints every 30 seconds
/// to minimize memory usage and enable crash recovery
pub struct IncrementalAudioSaver {
    checkpoint_buffer: Vec<AudioData>,
    checkpoint_interval_samples: usize,  // 30s at 48kHz = 1,440,000 samples
    checkpoint_count: u32,
    checkpoints_dir: PathBuf,
    meeting_folder: PathBuf,
    sample_rate: u32,
}

impl IncrementalAudioSaver {
    /// Create a new incremental saver
    ///
    /// # Arguments
    /// * `meeting_folder` - Path to the meeting folder (contains .checkpoints/)
    /// * `sample_rate` - Sample rate of audio (typically 48000)
    pub fn new(meeting_folder: PathBuf, sample_rate: u32) -> Result<Self> {
        let checkpoints_dir = meeting_folder.join(".checkpoints");

        // Verify checkpoints directory exists
        if !checkpoints_dir.exists() {
            return Err(anyhow!("Checkpoints directory does not exist: {}", checkpoints_dir.display()));
        }

        Ok(Self {
            checkpoint_buffer: Vec::new(),
            checkpoint_interval_samples: sample_rate as usize * 30, // 30 seconds
            checkpoint_count: 0,
            checkpoints_dir,
            meeting_folder,
            sample_rate,
        })
    }

    /// Add an audio chunk to the buffer
    /// Automatically saves a checkpoint when buffer reaches 30 seconds
    pub fn add_chunk(&mut self, chunk: AudioChunk) -> Result<()> {
        let audio_data = AudioData {
            data: chunk.data,
            // sample_rate: chunk.sample_rate,
        };

        self.checkpoint_buffer.push(audio_data);

        // Calculate total samples in buffer
        let total_samples: usize = self.checkpoint_buffer
            .iter()
            .map(|c| c.data.len())
            .sum();

        // Save checkpoint when buffer reaches threshold (30 seconds)
        if total_samples >= self.checkpoint_interval_samples {
            self.save_checkpoint()?;
            self.checkpoint_buffer.clear();
        }

        Ok(())
    }

    /// Save current buffer as a checkpoint file
    fn save_checkpoint(&mut self) -> Result<()> {
        // Concatenate all chunks in buffer
        let audio_data: Vec<f32> = self.checkpoint_buffer
            .iter()
            .flat_map(|c| &c.data)
            .cloned()
            .collect();

        if audio_data.is_empty() {
            warn!("Attempted to save empty checkpoint, skipping");
            return Ok(());
        }

        // Generate checkpoint filename
        let checkpoint_path = self.checkpoints_dir
            .join(format!("audio_chunk_{:03}.mp4", self.checkpoint_count));

        let candidate=tempfile::Builder::new().prefix(".checkpoint-").suffix(".mp4").tempfile_in(&self.checkpoints_dir)?;
        // Encode and save checkpoint
        encode_single_audio(
            bytemuck::cast_slice(&audio_data),
            self.sample_rate,
            1,  // mono
            &candidate.path().to_path_buf()
        )?;
        candidate.as_file().sync_all()?;
        candidate.persist_noclobber(&checkpoint_path).map_err(|_|anyhow!("無法提交錄音分段；未覆寫既有分段"))?;

        let duration_seconds = audio_data.len() as f32 / self.sample_rate as f32;
        self.checkpoint_count += 1;
        let _=super::recording_safety::event(&self.meeting_folder,"checkpoint","synced",self.checkpoint_count as u64);

        info!("Saved checkpoint {}: {:.2}s of audio ({} samples)",
              self.checkpoint_count,
              duration_seconds,
              audio_data.len());

        Ok(())
    }

    /// Finalize the recording: save final checkpoint, merge all checkpoints, cleanup
    ///
    /// Returns the path to the final merged audio.mp4 file
    pub async fn finalize(&mut self) -> Result<PathBuf> {
        info!("Finalizing incremental recording...");

        // Save final buffer if not empty
        if !self.checkpoint_buffer.is_empty() {
            info!("Saving final checkpoint with remaining {} chunks", self.checkpoint_buffer.len());
            self.save_checkpoint()?;
            self.checkpoint_buffer.clear();
        }

        if self.checkpoint_count == 0 {
            return Err(anyhow!("No audio checkpoints to merge - recording may have failed"));
        }

        let paths: Vec<_> = (0..self.checkpoint_count).map(|i|self.checkpoints_dir.join(format!("audio_chunk_{:03}.mp4",i))).collect();
        super::recording_safety::merge(&self.meeting_folder, &paths).await
    }

    /// Get the meeting folder path
    pub fn get_meeting_folder(&self) -> &PathBuf {
        &self.meeting_folder
    }

    /// Get current checkpoint count
    pub fn get_checkpoint_count(&self) -> u32 {
        self.checkpoint_count
    }
}

/// Audio recovery status for transcript recovery feature
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AudioRecoveryStatus {
    pub status: String, // "success" | "partial" | "failed" | "none"
    pub chunk_count: u32,
    pub estimated_duration_seconds: f64,
    pub audio_file_path: Option<String>,
    pub message: String,
}

/// Recover audio from checkpoint files
/// This is called by the transcript recovery system to merge audio chunks after a crash
#[tauri::command]
pub async fn recover_audio_from_checkpoints(
    meeting_folder: String,
    sample_rate: u32
) -> Result<AudioRecoveryStatus, String> {
    // Keep the public IPC name `sampleRate`; the encoded checkpoint stream
    // already carries its sample rate and does not need resampling here.
    let _ = sample_rate;
    if super::recording_commands::is_recording().await {return Err("正在錄音或保存，請完成停止後再復原".into());}
    info!("Starting audio recovery for folder: {}", meeting_folder);

    let folder_path = super::recording_safety::checked_recording_folder(&meeting_folder)?;
    let checkpoints_dir = folder_path.join(".checkpoints");

    // Check if checkpoints directory exists
    if !checkpoints_dir.exists() {
        let audio=super::retranscription::find_audio_file(&folder_path).map_err(|_|"找不到原音或保留分段")?;
        super::recording_safety::validate_audio(&audio,&folder_path).await.map_err(|e|e.to_string())?;
        return Ok(AudioRecoveryStatus{status:"success".into(),chunk_count:0,estimated_duration_seconds:0.0,
            audio_file_path:Some(audio.to_string_lossy().into()),message:"現存原音已通過完整解碼檢查；沒有分段可交叉核對，請播放確認內容。".into()});

    }

    // Scan for checkpoint files
    let mut checkpoint_files: Vec<_> = std::fs::read_dir(&checkpoints_dir)
        .map_err(|e| format!("Failed to read checkpoints directory: {}", e))?
        .filter_map(|entry| entry.ok())
        .filter(|entry| {
            entry.file_name().to_string_lossy().starts_with("audio_chunk_") && entry.path().extension().and_then(|s| s.to_str()) == Some("mp4")
        })
        .collect();

    if checkpoint_files.is_empty() {
        info!("No checkpoint files found in: {}", checkpoints_dir.display());
        return Ok(AudioRecoveryStatus {
            status: "none".to_string(),
            chunk_count: 0,
            estimated_duration_seconds: 0.0,
            audio_file_path: None,
            message: "No audio checkpoint files found".to_string(),
        });
    }

    // Sort by filename (audio_chunk_000.mp4, audio_chunk_001.mp4, etc.)
    checkpoint_files.sort_by_key(|entry|entry.path().file_stem().and_then(|s|s.to_str()).and_then(|s|s.strip_prefix("audio_chunk_")).and_then(|s|s.parse::<u64>().ok()).unwrap_or(u64::MAX));

    let chunk_count = checkpoint_files.len() as u32;
    let estimated_duration = (chunk_count as f64) * 30.0; // 30 seconds per chunk

    info!("Found {} checkpoint files, estimated duration: {:.2}s", chunk_count, estimated_duration);

    let paths: Vec<_> = checkpoint_files.iter().map(|e|e.path()).collect();
    let output=super::recording_safety::merge(&folder_path,&paths).await.map_err(|e|e.to_string())?;
    // Commit a recoverable audio state, but do not create a duplicate meeting or start AI.
    let metadata=folder_path.join("metadata.json");
    if metadata.exists() {
        if let Some(mut data)=std::fs::read(&metadata).ok().and_then(|b|serde_json::from_slice::<serde_json::Value>(&b).ok()).filter(|v|v.is_object()) {
            data["status"]=serde_json::json!("audio_saved");
            data["audio_file"]=serde_json::json!(output.file_name().unwrap_or_default().to_string_lossy());
            if super::recording_safety::atomic_json(&metadata,&data).is_err() {
                let _=super::recording_safety::event(&folder_path,"recovery","metadata_unavailable",0);
            }
        }else{
            // Never erase malformed evidence. The verified recovered file can still be imported.
            let _=super::recording_safety::event(&folder_path,"recovery","metadata_unreadable",0);
        }
    }
    Ok(AudioRecoveryStatus {status:"success".into(),chunk_count,estimated_duration_seconds:estimated_duration,
        audio_file_path:Some(output.to_string_lossy().into()),message:"原音已復原並驗證，分段與原有音檔均保留。請匯入復原檔或重試轉錄。".into()})
}

/// Clean up checkpoint files after successful recording or recovery
/// This command is called by the frontend after successful save to clean up checkpoint files
#[tauri::command]
pub async fn cleanup_checkpoints(meeting_folder: String) -> Result<(), String> {
    if super::recording_commands::is_recording().await {return Err("正在錄音或保存，不可清除分段".into());}
    info!("Cleaning up checkpoints for folder: {}", meeting_folder);

    let folder_path = super::recording_safety::checked_recording_folder(&meeting_folder)?;
    let checkpoints_dir = folder_path.join(".checkpoints");

    let metadata:serde_json::Value=serde_json::from_slice(&std::fs::read(folder_path.join("metadata.json")).map_err(|_|"找不到已提交的保存狀態，保留分段")?).map_err(|_|"保存狀態無法讀取，保留分段")?;
    if !matches!(metadata["status"].as_str(), Some("audio_saved"|"completed")) { return Err("保存尚未完成，不可清除分段".into()); }
    let audio=metadata["audio_file"].as_str().ok_or("找不到音檔")?;
    if std::path::Path::new(audio).components().count()!=1 {return Err("音檔名稱不正確".into());}
    super::recording_safety::validate_audio(&folder_path.join(audio),&folder_path).await.map_err(|e|e.to_string())?;
    if checkpoints_dir.exists() {
        std::fs::remove_dir_all(&checkpoints_dir)
            .map_err(|e| format!("Failed to remove checkpoints directory: {}", e))?;
        info!("Successfully cleaned up checkpoints directory");
    } else {
        info!("No checkpoints directory to clean up");
    }

    Ok(())
}

/// Check if a meeting folder has audio checkpoint files
/// Returns true if .checkpoints/ directory exists and contains .mp4 files
#[tauri::command]
pub async fn has_audio_checkpoints(meeting_folder: String) -> Result<bool, String> {
    let folder_path = PathBuf::from(&meeting_folder);
    let checkpoints_dir = folder_path.join(".checkpoints");

    // Check if checkpoints directory exists
    if !checkpoints_dir.exists() {
        return Ok(false);
    }

    // Scan for .mp4 checkpoint files
    let has_mp4_files = std::fs::read_dir(&checkpoints_dir)
        .map_err(|e| format!("Failed to read checkpoints directory: {}", e))?
        .filter_map(|entry| entry.ok())
        .any(|entry| {
            entry.file_name().to_string_lossy().starts_with("audio_chunk_") && entry.path().extension().and_then(|s| s.to_str()) == Some("mp4")
        });

    Ok(has_mp4_files)
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::tempdir;
    use super::super::recording_state::DeviceType;

    #[tokio::test]
    async fn short_recording_is_saved_before_transcription_and_survives_failure() {
        let dir = tempdir().unwrap();
        let folder = dir.path().join("原音 ' short");
        std::fs::create_dir_all(folder.join(".checkpoints")).unwrap();
        let mut saver = IncrementalAudioSaver::new(folder.clone(), 48000).unwrap();
        let samples: Vec<f32> = (0..(48000 * 15 + 123)).map(|i| {
            ((i as f32 * 440.0 * std::f32::consts::TAU / 48000.0).sin()) * 0.2
        }).collect();
        for (i, part) in samples.chunks(28800).enumerate() {
            saver.add_chunk(AudioChunk { data: part.to_vec(), sample_rate: 48000,
                timestamp: i as f64 * 0.6, chunk_id: i as u64, device_type: DeviceType::Microphone }).unwrap();
        }
        let started = std::time::Instant::now();
        let audio = saver.finalize().await.unwrap();
        let saved = std::fs::read(&audio).unwrap();
        assert!(saved.len() > 1000);
        // Decode the actual produced file; AAC padding may add at most one frame.
        let out = std::process::Command::new(find_ffmpeg_path().unwrap())
            .args(["-v", "error", "-i"]).arg(&audio)
            .args(["-f", "f32le", "-ac", "1", "-ar", "48000", "pipe:1"])
            .output().unwrap();
        assert!(out.status.success());
        let decoded = out.stdout.len() / 4;
        assert!(decoded >= samples.len() && decoded <= samples.len() + 2048, "decoded={decoded}");
        let transcription: Result<()> = Err(anyhow!("模擬模型不可用"));
        assert!(transcription.is_err());
        assert_eq!(std::fs::read(audio).unwrap(), saved);
        eprintln!("15-second original save+decode verification: {:?}", started.elapsed());
    }

    #[tokio::test]
    async fn failed_destination_keeps_checkpoints_and_reports_error() {
        let dir = tempdir().unwrap();
        std::fs::create_dir_all(dir.path().join(".checkpoints")).unwrap();
        let mut saver = IncrementalAudioSaver::new(dir.path().to_path_buf(), 48000).unwrap();
        saver.add_chunk(AudioChunk { data: vec![0.0; 48000], sample_rate: 48000,
            timestamp: 0.0, chunk_id: 0, device_type: DeviceType::Microphone }).unwrap();
        std::fs::create_dir(dir.path().join("audio.mp4")).unwrap();
        let recovered=saver.finalize().await.unwrap();
        assert!(recovered.file_name().unwrap().to_string_lossy().starts_with("audio-recovered-"));
        assert!(dir.path().join("audio.mp4").is_dir());
        assert!(dir.path().join(".checkpoints/audio_chunk_000.mp4").is_file());
    }

    #[tokio::test]
    async fn test_checkpoint_creation() {
        // Create temp meeting folder
        let temp_dir = tempdir().unwrap();
        let meeting_folder = temp_dir.path().join("Test_Meeting");
        std::fs::create_dir_all(&meeting_folder).unwrap();
        std::fs::create_dir_all(meeting_folder.join(".checkpoints")).unwrap();

        let mut saver = IncrementalAudioSaver::new(
            meeting_folder.clone(),
            48000
        ).unwrap();

        // Add 60 seconds worth of audio (should create 2 checkpoints)
        for i in 0..120 {  // 120 chunks of 0.5s each
            let chunk = AudioChunk {
                data: vec![0.5f32; 24000],  // 0.5s at 48kHz
                sample_rate: 48000,
                timestamp: i as f64 * 0.5,  // timestamp in seconds
                chunk_id: i as u64,
                device_type: DeviceType::Microphone,
            };
            saver.add_chunk(chunk).unwrap();
        }

        // Verify 2 checkpoints created
        assert_eq!(saver.checkpoint_count, 2);

        // Finalize and verify merge
        let final_path = saver.finalize().await.unwrap();
        assert!(final_path.exists());

        // Verify checkpoints directory deleted
        assert!(meeting_folder.join(".checkpoints").exists());
    }

    #[tokio::test]
    async fn test_empty_recording() {
        let temp_dir = tempdir().unwrap();
        let meeting_folder = temp_dir.path().join("Empty_Test");
        std::fs::create_dir_all(&meeting_folder).unwrap();
        std::fs::create_dir_all(meeting_folder.join(".checkpoints")).unwrap();

        let mut saver = IncrementalAudioSaver::new(
            meeting_folder.clone(),
            48000
        ).unwrap();

        // Try to finalize without adding any chunks
        let result = saver.finalize().await;
        assert!(result.is_err());
        assert!(result.unwrap_err().to_string().contains("No audio checkpoints"));
    }
    #[tokio::test]
    async fn failed_diagnostics_never_blocks_audio_save(){
        let d=tempdir().unwrap();std::fs::create_dir(d.path().join(".checkpoints")).unwrap();
        std::fs::create_dir(d.path().join("recording-diagnostics.jsonl")).unwrap();
        let mut saver=IncrementalAudioSaver::new(d.path().to_path_buf(),48000).unwrap();
        saver.add_chunk(AudioChunk{data:vec![0.1;48000],sample_rate:48000,timestamp:0.0,chunk_id:0,device_type:DeviceType::Microphone}).unwrap();
        assert!(saver.finalize().await.unwrap().is_file());
        assert!(d.path().join(".checkpoints/audio_chunk_000.mp4").is_file());
    }
}
