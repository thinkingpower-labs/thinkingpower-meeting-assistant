//! Disk-backed file inference with bounded windows near quiet boundaries.
use super::vad::SpeechSegment;
use anyhow::{anyhow, Result};
use std::{
    fs::File,
    io::{Read, Seek, SeekFrom},
    path::Path,
    time::Duration,
};

const CHUNK_SAMPLES: u64 = 25 * 16000;
const WINDOW_SAMPLES: u64 = 30 * 16000;

pub(crate) struct FileAudio {
    pcm: File,
    samples: u64,
    ranges: Vec<(u64, u64)>,
    _temporary: tempfile::TempDir,
}

#[cfg(test)]
mod tests {
    use super::*;
    #[cfg(feature = "local-asr-acceptance")]
    #[tokio::test]
    #[ignore = "requires local model and explicitly selected non-private speech fixture"]
    async fn disk_pipeline_and_native_whisper_recognize_speech() {
        let source = std::path::PathBuf::from(std::env::var("TEST_AUDIO_PATH").unwrap());
        let models = std::path::PathBuf::from(std::env::var("TEST_MODELS_DIR").unwrap());
        let output = std::path::PathBuf::from(std::env::var("TEST_OUTPUT_DIR").unwrap());
        std::fs::create_dir_all(&output).unwrap();
        let mut audio = FileAudio::open(&source, &output).await.unwrap();
        let engine =
            crate::whisper_engine::WhisperEngine::new_with_models_dir(Some(models)).unwrap();
        engine.discover_models().await.unwrap();
        engine.load_model("small").await.unwrap();
        let mut text = String::new();
        for i in 0..audio.len() {
            let chunk = audio.segment(i).unwrap();
            let (recognized, _, _) = engine
                .transcribe_file_audio_with_confidence(chunk.samples, Some("en".into()))
                .await
                .unwrap();
            text.push_str(&recognized);
            text.push(' ');
        }
        engine.unload_model().await;
        std::fs::write(output.join("synthetic-transcript.txt"), &text).unwrap();
        assert!(
            text.to_lowercase().contains("meeting assistant"),
            "Synthetic fixture speech was not recognized"
        );
    }
    fn silent_pcm(folder: &Path, samples: u64) -> tempfile::TempDir {
        let temporary = tempfile::Builder::new()
            .prefix(".decode-test-")
            .tempdir_in(folder)
            .unwrap();
        File::create(temporary.path().join("audio.f32"))
            .unwrap()
            .set_len(samples * 4)
            .unwrap();
        temporary
    }
    #[test]
    fn two_hour_file_is_indexed_with_bounded_chunks_and_exact_tail() {
        for samples in [1, 1599, 400000, 120 * 60 * 16000 + 37] {
            let folder = tempfile::tempdir().unwrap();
            let mut audio =
                FileAudio::index(silent_pcm(folder.path(), samples), folder.path()).unwrap();
            assert_eq!(audio.ranges.first().unwrap().0, 0);
            assert_eq!(audio.ranges.last().unwrap().1, samples);
            for pair in audio.ranges.windows(2) {
                assert_eq!(pair[0].1, pair[1].0);
            }
            assert!(audio
                .ranges
                .iter()
                .all(|&(start, end)| end > start && end - start <= WINDOW_SAMPLES));
            let last = audio.segment(audio.len() - 1).unwrap();
            assert_eq!(last.end_timestamp_ms, samples as f64 / 16.0);
            assert!(last.samples.len() >= 1600 && last.samples.len() <= WINDOW_SAMPLES as usize);
            assert!(audio.segment(audio.len()).is_err());
            println!(
                "indexed {} seconds in {} bounded chunks",
                audio.duration(),
                audio.len()
            );
        }
    }
    #[test]
    fn changed_plan_is_rejected_without_overwriting_saved_boundaries() {
        let folder = tempfile::tempdir().unwrap();
        let first = FileAudio::index(silent_pcm(folder.path(), 16000), folder.path()).unwrap();
        drop(first);
        let plan = folder.path().join("transcription-plan.json");
        let before = std::fs::read(&plan).unwrap();
        assert!(FileAudio::index(silent_pcm(folder.path(), 32000), folder.path()).is_err());
        assert_eq!(std::fs::read(plan).unwrap(), before);
        assert!(FileAudio::index(silent_pcm(folder.path(), 0), folder.path()).is_err());
    }
    #[test]
    fn legacy_plan_keeps_original_boundaries_and_rejects_gaps() {
        let folder = tempfile::tempdir().unwrap();
        let plan = folder.path().join("transcription-plan.json");
        let value = serde_json::json!({"strategy":"full_file_adaptive_gain_quiet_boundaries","chunks":[
            {"start_seconds":0.0,"end_seconds":0.75},{"start_seconds":0.75,"end_seconds":1.0}
        ]});
        std::fs::write(&plan, serde_json::to_vec(&value).unwrap()).unwrap();
        let before = std::fs::read(&plan).unwrap();
        let mut audio = FileAudio::index(silent_pcm(folder.path(), 16000), folder.path()).unwrap();
        assert_eq!(audio.len(), 2);
        assert_eq!(audio.segment(0).unwrap().end_timestamp_ms, 750.0);
        assert_eq!(audio.segment(1).unwrap().start_timestamp_ms, 750.0);
        assert_eq!(std::fs::read(&plan).unwrap(), before);
        let gap = serde_json::json!({"strategy":"full_file_adaptive_gain_quiet_boundaries","chunks":[
            {"start_seconds":0.0,"end_seconds":0.5},{"start_seconds":0.75,"end_seconds":1.0}
        ]});
        assert!(FileAudio::saved_ranges(&gap, 16000).is_err());
        assert!(FileAudio::saved_ranges(&value, 16001).is_err());
    }
}

impl FileAudio {
    pub(crate) async fn open(source: &Path, folder: &Path) -> Result<Self> {
        let temporary = tempfile::Builder::new()
            .prefix(".decode-")
            .tempdir_in(folder)?;
        let output = temporary.path().join("audio.f32");
        super::recording_safety::ffmpeg(
            &[
                "-hide_banner".into(),
                "-nostdin".into(),
                "-v".into(),
                "error".into(),
                "-xerror".into(),
                "-i".into(),
                source.as_os_str().to_owned(),
                "-map".into(),
                "0:a:0".into(),
                "-ac".into(),
                "1".into(),
                "-ar".into(),
                "16000".into(),
                "-f".into(),
                "f32le".into(),
                output.as_os_str().to_owned(),
            ],
            Duration::from_secs(1800),
            folder,
            "decode_file",
        )
        .await?;
        let folder = folder.to_path_buf();
        tokio::task::spawn_blocking(move || Self::index(temporary, &folder))
            .await
            .map_err(|_| anyhow!("音訊分段工作中斷；原音仍保留。"))?
    }
    fn index(temporary: tempfile::TempDir, folder: &Path) -> Result<Self> {
        let mut pcm = File::open(temporary.path().join("audio.f32"))?;
        let bytes = pcm.metadata()?.len();
        if bytes == 0 || bytes % 4 != 0 {
            return Err(anyhow!("解碼後沒有完整音訊，原音仍保留。"));
        }
        let samples = bytes / 4;
        let plan = folder.join("transcription-plan.json");
        if plan.exists() {
            let saved: serde_json::Value = serde_json::from_slice(&std::fs::read(&plan)?)?;
            let ranges = Self::saved_ranges(&saved, samples)?;
            return Ok(Self {
                pcm,
                samples,
                ranges,
                _temporary: temporary,
            });
        }
        let mut ranges = Vec::new();
        let mut start = 0;
        while start < samples {
            let end = (start + WINDOW_SAMPLES).min(samples);
            let segment = SpeechSegment {
                samples: Self::read_samples(&mut pcm, start, end)?,
                start_timestamp_ms: start as f64 / 16.0,
                end_timestamp_ms: end as f64 / 16.0,
                confidence: 0.0,
            };
            let candidates =
                super::common::split_segment_at_silence(&segment, CHUNK_SAMPLES as usize);
            let length = candidates
                .first()
                .ok_or_else(|| anyhow!("無法建立音訊分段"))?
                .samples
                .len() as u64;
            if length == 0 || length > WINDOW_SAMPLES {
                return Err(anyhow!("音訊分段範圍無效"));
            }
            ranges.push((start, start + length));
            start += length;
        }
        let chunks = ranges
            .iter()
            .map(|&(start, end)| {
                serde_json::json!({
                    "start_seconds": start as f64 / 16000.0, "end_seconds": end as f64 / 16000.0,
                })
            })
            .collect::<Vec<_>>();
        let report = serde_json::json!({"strategy":"disk_pcm_quiet_25s_v1","source_modified":false,"chunks":chunks});
        super::recording_safety::atomic_json(&plan, &report)?;
        Ok(Self {
            _temporary: temporary,
            pcm,
            samples,
            ranges,
        })
    }
    fn saved_ranges(plan: &serde_json::Value, samples: u64) -> Result<Vec<(u64, u64)>> {
        if !matches!(
            plan["strategy"].as_str(),
            Some("disk_pcm_quiet_25s_v1" | "full_file_adaptive_gain_quiet_boundaries")
        ) {
            return Err(anyhow!(
                "此舊工作分段版本無法安全接續，請確認後開始新的轉錄嘗試。"
            ));
        }
        let chunks = plan["chunks"]
            .as_array()
            .ok_or_else(|| anyhow!("舊分段計畫無法讀取"))?;
        let mut ranges = Vec::with_capacity(chunks.len());
        let mut previous = 0;
        for chunk in chunks {
            let start = chunk["start_seconds"].as_f64().unwrap_or(f64::NAN) * 16000.0;
            let end = chunk["end_seconds"].as_f64().unwrap_or(f64::NAN) * 16000.0;
            if !start.is_finite()
                || !end.is_finite()
                || start < 0.0
                || end <= start
                || (start - start.round()).abs() > 0.01
                || (end - end.round()).abs() > 0.01
                || end.round() > samples as f64
                || end.round() - start.round() > WINDOW_SAMPLES as f64
                || start.round() as u64 != previous
            {
                return Err(anyhow!(
                    "舊分段與原音範圍不一致，已保留進度並停止。請確認後開始新的轉錄嘗試。"
                ));
            }
            previous = end.round() as u64;
            ranges.push((start.round() as u64, previous));
        }
        if ranges.is_empty() || previous != samples {
            return Err(anyhow!(
                "新解碼音訊長度與舊分段不同，已停止以免混用結果。請確認後開始新的轉錄嘗試。"
            ));
        }
        Ok(ranges)
    }
    pub(crate) fn len(&self) -> usize {
        self.ranges.len()
    }
    pub(crate) fn duration(&self) -> f64 {
        self.samples as f64 / 16000.0
    }
    pub(crate) fn segment(&mut self, index: usize) -> Result<SpeechSegment> {
        let &(start, end) = self
            .ranges
            .get(index)
            .ok_or_else(|| anyhow!("音訊索引超出範圍"))?;
        let mut samples = Self::read_samples(&mut self.pcm, start, end)?;
        super::full_file::prepare_chunk(&mut samples);
        Ok(SpeechSegment {
            samples,
            start_timestamp_ms: start as f64 / 16.0,
            end_timestamp_ms: end as f64 / 16.0,
            confidence: 0.0,
        })
    }
    fn read_samples(pcm: &mut File, start: u64, end: u64) -> Result<Vec<f32>> {
        pcm.seek(SeekFrom::Start(start * 4))?;
        let mut bytes = vec![0u8; ((end - start) * 4) as usize];
        pcm.read_exact(&mut bytes)?;
        Ok(bytes
            .chunks_exact(4)
            .map(|b| f32::from_le_bytes([b[0], b[1], b[2], b[3]]).clamp(-1.0, 1.0))
            .collect())
    }
}
