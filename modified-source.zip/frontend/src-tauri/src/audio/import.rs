// Audio file import module - allows importing external audio files as new meetings

use crate::api::TranscriptSegment;
use crate::audio::decoder::decode_audio_file;

use crate::config::{DEFAULT_WHISPER_MODEL, DEFAULT_PARAKEET_MODEL};
use crate::parakeet_engine::ParakeetEngine;
use crate::state::AppState;
use crate::whisper_engine::WhisperEngine;
use anyhow::{anyhow, Result};
use log::{debug, error, info, warn};
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use super::transcription_tasks::{Task, is_cloud};
use std::sync::Arc;
use tauri::{AppHandle, Emitter, Manager, Runtime};
use tauri_plugin_dialog::DialogExt;
use uuid::Uuid;

use super::audio_processing::create_meeting_folder;
use super::common::{create_transcript_segments, write_transcripts_json};
use super::constants::AUDIO_EXTENSIONS;
use super::recording_preferences::get_default_recordings_folder;

/// VAD redemption time in milliseconds - bridges natural pauses in speech
/// Batch processing needs longer redemption (2000ms) than the live pipeline
/// (500ms) because the entire file is processed at once by VAD with no
/// latency requirement, and short redemption fragments speech at every
/// natural sentence/topic pause (500ms-2s)
#[cfg(test)]
const VAD_REDEMPTION_TIME_MS: u32 = 2000;

/// Maximum file size: 20GB (prevents OOM and excessive processing time)
const MAX_FILE_SIZE_BYTES: u64 = 20 * 1024 * 1024 * 1024; // 20GB

/// Information about a selected audio file
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AudioFileInfo {
    pub path: String,
    pub filename: String,
    pub duration_seconds: f64,
    pub size_bytes: u64,
    pub format: String,
}

/// Progress update emitted during import
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ImportProgress {
    pub job_id: String,
    pub stage: String, // "copying", "decoding", "vad", "transcribing", "saving"
    pub progress_percentage: u32,
    pub message: String,
}

/// Result of import
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ImportResult {
    pub job_id: String,
    pub meeting_id: String,
    pub title: String,
    pub segments_count: usize,
    pub duration_seconds: f64,
}

/// Error during import
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ImportError {
    pub job_id: String,
    pub error: String,
    pub meeting_id: Option<String>,
}

/// Warning emitted during import (non-fatal)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ImportWarning {
    pub job_id: String,
    pub warning: String,
    pub details: Option<String>,
}

/// Response when import is started
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ImportStarted {
    pub job_id: String,
    pub message: String,
}

/// Validate an audio file and return its info using metadata-only approach
/// Falls back to full decode if metadata is unavailable
pub fn validate_audio_file(path: &Path) -> Result<AudioFileInfo> {
    // Check file exists
    if !path.exists() {
        return Err(anyhow!("File does not exist: {}", path.display()));
    }

    // Check extension
    let extension = path
        .extension()
        .and_then(|e| e.to_str())
        .map(|e| e.to_lowercase())
        .unwrap_or_default();

    if !AUDIO_EXTENSIONS.contains(&extension.as_str()) {
        return Err(anyhow!(
            "Unsupported format: .{}. Supported: {}",
            extension,
            AUDIO_EXTENSIONS.join(", ")
        ));
    }

    // Get file size
    let metadata = std::fs::metadata(path)
        .map_err(|e| anyhow!("Cannot read file: {}", e))?;
    let size_bytes = metadata.len();

    // Check file size limit
    if size_bytes > MAX_FILE_SIZE_BYTES {
        return Err(anyhow!(
            "File too large: {:.2}GB. Maximum supported size is {}GB",
            size_bytes as f64 / (1024.0 * 1024.0 * 1024.0),
            MAX_FILE_SIZE_BYTES / (1024 * 1024 * 1024)
        ));
    }

    // Get filename without extension for title
    let filename = path
        .file_stem()
        .and_then(|s| s.to_str())
        .unwrap_or("Imported Audio")
        .to_string();

    // Try fast metadata-only validation first
    let duration_seconds = match extract_duration_from_metadata(path) {
        Ok(duration) => {
            debug!(
                "Got duration from metadata: {:.2}s (fast path)",
                duration
            );
            duration
        }
        Err(e) => {
            // Fallback to full decode if metadata unavailable
            warn!(
                "Metadata extraction failed: {}, falling back to full decode",
                e
            );
            let decoded = decode_audio_file(path)?;
            decoded.duration_seconds
        }
    };

    Ok(AudioFileInfo {
        path: path.to_string_lossy().to_string(),
        filename,
        duration_seconds,
        size_bytes,
        format: extension.to_uppercase(),
    })
}

/// Extract duration from audio file metadata without full decode
/// Returns error if metadata is unavailable, triggering fallback to full decode
fn extract_duration_from_metadata(path: &Path) -> Result<f64> {
    use symphonia::core::formats::FormatOptions;
    use symphonia::core::io::MediaSourceStream;
    use symphonia::core::meta::MetadataOptions;
    use symphonia::core::probe::Hint;

    // Open the file
    let file = std::fs::File::open(path)
        .map_err(|e| anyhow!("Failed to open audio file: {}", e))?;

    let mss = MediaSourceStream::new(Box::new(file), Default::default());

    // Set up format hint based on file extension
    let mut hint = Hint::new();
    if let Some(ext) = path.extension().and_then(|e| e.to_str()) {
        hint.with_extension(ext);
    }

    // Probe the file format (lightweight operation)
    let probed = symphonia::default::get_probe()
        .format(
            &hint,
            mss,
            &FormatOptions::default(),
            &MetadataOptions::default(),
        )
        .map_err(|e| anyhow!("Failed to probe audio format: {}", e))?;

    let format = probed.format;

    // Find the first audio track
    use symphonia::core::codecs::CODEC_TYPE_NULL;
    let track = format
        .tracks()
        .iter()
        .find(|t| t.codec_params.codec != CODEC_TYPE_NULL)
        .ok_or_else(|| anyhow!("No audio track found in file"))?;

    // Extract duration from metadata
    let sample_rate = track
        .codec_params
        .sample_rate
        .ok_or_else(|| anyhow!("Unknown sample rate"))?;

    let n_frames = track
        .codec_params
        .n_frames
        .ok_or_else(|| anyhow!("Frame count not available in metadata"))?;

    let duration_seconds = n_frames as f64 / sample_rate as f64;

    debug!(
        "Extracted metadata: {}Hz, {} frames, {:.2}s",
        sample_rate, n_frames, duration_seconds
    );

    Ok(duration_seconds)
}

/// Start import of an audio file
pub async fn start_import<R: Runtime>(
    app: AppHandle<R>,
    source_path: String,
    title: String,
    language: Option<String>,
    model: Option<String>,
    provider: Option<String>,
) -> Result<ImportResult> {
    let task=Task::register(None,title.clone(),provider.clone().unwrap_or("whisper".into()),model.clone(),None).map_err(anyhow::Error::msg)?;
    if is_cloud(provider.as_deref().unwrap_or("whisper")){
        let state=app.try_state::<AppState>().ok_or_else(||anyhow!("無法讀取服務設定"))?;
        let connection=crate::ai_services::connection(state.db_manager.pool(),provider.as_deref().unwrap()).await.map_err(anyhow::Error::msg)?;
        task.destination(Some(connection.endpoint));
    }
    start_registered_import(app,source_path,title,language,model,provider,task).await
}

async fn start_registered_import<R:Runtime>(app:AppHandle<R>,source_path:String,title:String,language:Option<String>,model:Option<String>,provider:Option<String>,task:Task)->Result<ImportResult>{
    let mut retained_meeting=None;
    let result=async {
        let _slot=task.slot().await.map_err(anyhow::Error::msg)?;
        let result=run_import(app.clone(),source_path,title,language,model,provider.clone(),None,&mut retained_meeting,&task).await;
        if !is_cloud(provider.as_deref().unwrap_or("whisper")){super::common::unload_engine_after_batch(provider.as_deref()==Some("parakeet")).await;}
        result
    }.await;
    task.finish(result.is_ok(),result.as_ref().err().map(|e|e.to_string()).as_deref());
    match &result {
        Ok(res)=>{let _=app.emit("import-complete",res);}
        Err(e)=>{
            if let (Some(id),Some(state))=(&retained_meeting,app.try_state::<AppState>()){
                let _=super::file_job::stage(state.db_manager.pool(),id,if task.cancelled(){"cancelled"}else{"failed"},Some(&e.to_string())).await;
            }
            let _=app.emit("import-error",ImportError{job_id:task.snapshot().job_id,error:e.to_string(),meeting_id:retained_meeting});
        }
    }
    result
}

/// Internal function to run import
async fn run_import<R: Runtime>(
    app: AppHandle<R>,
    source_path: String,
    title: String,
    language: Option<String>,
    model: Option<String>,
    provider: Option<String>,
    resume: Option<super::file_job::FileJob>,
    retained_meeting: &mut Option<String>,
    task: &Task,
) -> Result<ImportResult> {
    let source = PathBuf::from(&source_path);

    // Validate source file
    if !source.exists() {
        return Err(anyhow!("Source file not found: {}", source.display()));
    }
    if let Some(ref job) = resume {
        let source_hash = super::file_job::fingerprint(&source)?;
        if job.source_sha256.as_deref() != Some(source_hash.as_str()) {
            return Err(anyhow!("原始音檔已變動或缺少驗證資訊，已停止接續，避免將不同音檔的文字混在一起。"));
        }
    }

    info!(
        "Starting import for '{}' from {} with language {:?}, model {:?}, provider {:?}",
        title, source_path, language, model, provider
    );

    let selected_provider = provider.as_deref().unwrap_or("whisper");
    let cloud = matches!(selected_provider, "openai" | "gemini" | "groq" | "openrouter" | "custom-openai");
    if !cloud && !matches!(selected_provider, "whisper" | "localWhisper" | "parakeet" | "builtin-ai") {
        return Err(anyhow!("此服務尚未提供已驗證的語音轉錄介面，請改選支援的服務。"));
    }
    // Determine which provider to use (default to whisper)
    let use_parakeet = provider.as_deref() == Some("parakeet");
    let model = if model.is_none() && !cloud {
        Some(get_configured_model(&app, if use_parakeet { "parakeet" } else { "whisper" }).await?)
    } else { model };

    emit_progress(&app, task, "copying", 5, "準備錄音資料夾…");

    // Check for cancellation
    if task.cancelled() {
        return Err(anyhow!("已停止處理，原始音檔及已完成的分段仍保留。"));
    }

    // Create meeting folder
    let base_folder = get_default_recordings_folder();
    let meeting_folder = if resume.is_some() {
        source.parent().ok_or_else(|| anyhow!("找不到原始錄音資料夾"))?.to_path_buf()
    } else { create_meeting_folder(&base_folder, &title, false)? };

    // Copy audio file to meeting folder
    emit_progress(&app, task, "copying", 10, "保留原始音檔…");

    let dest_filename = if resume.is_some() { source.file_name().and_then(|name| name.to_str()).ok_or_else(|| anyhow!("原音檔名無法讀取"))?.to_string() } else { format!(
        "audio.{}",
        source
            .extension()
            .and_then(|e| e.to_str())
            .unwrap_or("mp4")
    ) };
    let dest_path = if resume.is_some() { source.clone() } else { meeting_folder.join(&dest_filename) };

    let src = source.clone();
    let dst = dest_path.clone();
    if resume.is_none() {
    tokio::task::spawn_blocking(move || {
        std::fs::copy(&src, &dst)?;
        if super::file_job::fingerprint(&src)? != super::file_job::fingerprint(&dst)? {
            return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "原始音檔複本比對不一致"));
        }
        std::fs::OpenOptions::new().write(true).open(&dst)?.sync_all()
    })
        .await
        .map_err(|e| anyhow!("Copy task join error: {}", e))?
        .map_err(|e| anyhow!("無法保存原始音檔，已停止處理：{}", e))?;
    }

    let app_state = app.try_state::<AppState>().ok_or_else(|| anyhow!("無法讀取會議資料庫"))?;
    let pool = app_state.db_manager.pool();
    let meeting_id = if let Some(ref job) = resume { job.meeting_id.clone() } else {
        let id = create_meeting_with_transcripts(pool, &title, &[], meeting_folder.to_string_lossy().to_string()).await?;
        *retained_meeting = Some(id.clone());
        super::file_job::create(pool, &id, &dest_path.to_string_lossy(), provider.as_deref().unwrap_or("whisper"), model.as_deref(), language.as_deref()).await?;
        write_import_metadata(&meeting_folder, &id, &title, 0.0, &dest_filename, "import")?;
        id
    };
    let _ = app.emit("meetings-updated", ());
    task.meeting(&meeting_id);
    task.check().map_err(anyhow::Error::msg)?;
    info!("Original audio retained for meeting {}", meeting_id);
    let current_job = super::file_job::get(pool, &meeting_id).await?;
    let artifact_folder = super::file_job::artifacts(&current_job).map_err(anyhow::Error::msg)?;

    let cloud_connection = if cloud {
        let config = crate::ai_services::connection(pool, selected_provider).await.map_err(anyhow::Error::msg)?;
        if task.snapshot().endpoint.as_deref().is_some_and(|endpoint|endpoint!=config.endpoint){return Err(anyhow!("排隊期間服務網址已改變，尚未上傳；請重新確認目的地後重試。"));}
        if resume.as_ref().and_then(|job| job.endpoint.as_deref()).is_some_and(|endpoint| endpoint != config.endpoint) {
            return Err(anyhow!("伺服器網址已變更，已停止接續以避免將錄音送至不同對象。"));
        }
        let selected_model = model.as_deref().ok_or_else(|| anyhow!("請先選擇語音轉錄模型"))?;
        if selected_provider == "custom-openai" {
            if !config.audio_verified || config.audio_model != selected_model { return Err(anyhow!("請先以合成測試音訊驗證自訂伺服器的音訊端點。")); }
        } else if !super::cloud_transcription::models(selected_provider).contains(&selected_model) {
            return Err(anyhow!("此模型未列入已查核的語音轉錄模型。"));
        }
        let key = crate::database::secret::get(pool, selected_provider).await?;
        if selected_provider != "custom-openai" && key.is_none() { return Err(anyhow!("請先儲存此服務的 API Key；原始音檔已保留。")); }
        Some((config, key))
    } else { None };

    if current_job.attempt_id.is_none() && current_job.completed_chunks != "[]" && !artifact_folder.join("transcription-plan.json").exists() {
        return Err(anyhow!("舊工作缺少分段計畫，已保留進度並停止。請確認後開始新的轉錄嘗試。"));
    }
    emit_progress(&app, task, "decoding", 15, "以磁碟暫存轉換音訊，保留原音與既有分段進度…");
    let mut disk_audio = super::file_audio::FileAudio::open(&dest_path, &artifact_folder).await?;
    let duration_seconds = disk_audio.duration();
    let total_segments = disk_audio.len();
    if total_segments == 0 { return Err(anyhow!("音檔沒有可處理的音訊")); }
    info!("Full-file import: {} chunks covering {:.2}s", total_segments, duration_seconds);

    if matches!(model.as_deref(),Some(super::diarization::MODEL | crate::gemini::SPEAKER_MODEL)) {
        let google=model.as_deref()==Some(crate::gemini::SPEAKER_MODEL);
        if selected_provider != if google {"gemini"} else {"openai"} {return Err(anyhow!("說話人模型與服務不相符。"));}
        let (config, key) = cloud_connection.as_ref().ok_or_else(|| anyhow!("缺少 OpenAI 連線"))?;
        let attempt = current_job.attempt_id.as_deref().ok_or_else(|| anyhow!("請開始新的轉錄嘗試以啟用說話人分離。"))?;
        super::file_job::stage(pool, &meeting_id, "transcribing", None).await?;
        emit_progress(&app, task, "transcribing", 30, "準備整場說話人辨識，服務未提供實際完成百分比；可到錄音與轉錄中心追蹤或取消。");
        let diarized = if google {crate::gemini::diarize(&dest_path,&artifact_folder,&config.endpoint,key.as_deref(),duration_seconds,task).await.map_err(anyhow::Error::msg)?}
            else {super::diarization::transcribe(&dest_path, &artifact_folder, &config.endpoint, key.as_deref(), duration_seconds, task).await?};
        task.check().map_err(anyhow::Error::msg)?;
        emit_progress(&app, task, "saving", 85, "儲存說話人與逐字稿…");
        super::diarization::publish(pool, &meeting_id, attempt, &diarized).await?;
        task.chunks(1, 1);
        // Authoritative names are in SQLite; the response cache preserves raw provider labels.
        if let Err(error) = super::recording_safety::atomic_json(&meeting_folder.join("transcripts.json"),
            &serde_json::json!({"version":2,"attempt_id":attempt,"segments":diarized})) { warn!("Could not save speaker transcript backup: {}", error); }
        if let Err(error) = write_import_metadata(&meeting_folder, &meeting_id, &title, duration_seconds, &dest_filename, "import") { warn!("Could not save metadata: {}", error); }
        emit_progress(&app, task, "complete", 100, "說話人逐字稿已儲存，可修改姓名");
        return Ok(ImportResult { job_id:task.snapshot().job_id, meeting_id, title, segments_count:diarized.len(), duration_seconds });
    }
    // Check for cancellation
    if task.cancelled() { return Err(anyhow!("已停止處理，原始音檔及已完成的分段仍保留。")); }
    emit_progress(&app, task, "transcribing", 30, "載入語音轉錄模型…");

    // Initialize the appropriate engine
    let whisper_engine = if !use_parakeet && !cloud && total_segments > 0 {
        Some(get_or_init_whisper(&app, model.as_deref()).await?)
    } else {
        None
    };
    let parakeet_engine = if use_parakeet && total_segments > 0 {
        Some(get_or_init_parakeet(&app, model.as_deref()).await?)
    } else {
        None
    };

    let processable_count = total_segments;
    info!("Processing {} segments (after splitting)", processable_count);

    // Process each speech segment
    let mut all_transcripts: Vec<(String, f64, f64)> = match resume {
        Some(ref job) => serde_json::from_str(&job.completed_chunks).map_err(|_| anyhow!("進度檔無法讀取；原音仍保留，請勿重複建立會議。"))?,
        None => Vec::new(),
    };
    let completed_count = all_transcripts.len();
    task.chunks(completed_count, processable_count);
    if completed_count > processable_count { return Err(anyhow!("已完成分段超出音訊範圍，已停止以保留原進度。")); }
    let mut total_confidence = 0.0f32;

    for i in completed_count..processable_count {
        let segment = disk_audio.segment(i)?;
        if task.cancelled() {
                return Err(anyhow!("已停止處理，原始音檔及已完成的分段仍保留。"));
        }

        let progress = 30 + ((i as f32 / processable_count.max(1) as f32) * 50.0) as u32;
        let segment_duration_sec = (segment.end_timestamp_ms - segment.start_timestamp_ms) / 1000.0;
        emit_progress(
            &app, task,
            "transcribing",
            progress,
            &format!(
                "完整轉錄第 {}／{} 段（{:.1} 秒）…",
                i + 1,
                processable_count,
                segment_duration_sec
            ),
        );

        // Skip very short segments
        if segment.samples.len() < 1600 {
            debug!(
                "Skipping short segment {} with {} samples",
                i,
                segment.samples.len()
            );
            continue;
        }

        super::file_job::stage(pool, &meeting_id, "transcribing", None).await?;
        // Transcribe
        let (text, conf) = if let Some((ref config, ref key)) = cloud_connection {
            let file = artifact_folder.join(format!("cloud-transcript-{:05}.json", i));
            let result = if file.exists() {
                serde_json::from_slice::<super::cloud_transcription::CloudTranscript>(&std::fs::read(&file)?)
                    .map_err(|_| anyhow!("已收到的雲端結果無法讀取，為避免重複付費已停止。"))?
            } else {
            super::file_job::stage(pool, &meeting_id, "uploading", None).await?;
            emit_progress(&app, task, "uploading", progress, &format!("上傳至 {}：第 {}／{} 段…", selected_provider, i + 1, processable_count));
            let previous = all_transcripts.last().map(|(text, _, _)| text.as_str());
            let result = if selected_provider=="gemini" {crate::gemini::transcribe_chunk(&config.endpoint,key.as_deref(),model.as_deref().unwrap(),language.as_deref(),&segment.samples).await}
                else {super::cloud_transcription::transcribe_with_context(&config.endpoint, key.as_deref(), model.as_deref().unwrap(), language.as_deref(), &segment.samples, previous).await};
            let result = match result {
                Ok(value) => value,
                Err(error) => {
                    super::file_job::stage(pool, &meeting_id, "failed", Some(&error)).await?;
                    return Err(anyhow!(error));
                }
            };
            // Keep supplied word/segment timing and usage separately from coarse chunk timing.
            let temporary = file.with_extension("json.tmp");
            std::fs::write(&temporary, serde_json::to_vec_pretty(&result)?)?;
            std::fs::OpenOptions::new().write(true).open(&temporary)?.sync_all()?;
            std::fs::rename(&temporary, &file)?;
            result
            };
            (result.text, 0.0)
        } else if use_parakeet {
            let engine = parakeet_engine.as_ref().unwrap();
            let text = engine
                .transcribe_audio(segment.samples.clone())
                .await
                .map_err(|e| anyhow!("Parakeet transcription failed on segment {}: {}", i, e))?;
            (text, 0.9f32)
        } else {
            let engine = whisper_engine.as_ref().unwrap();
            let (text, conf, _) = engine
                .transcribe_file_audio_with_confidence(segment.samples.clone(), language.clone())
                .await
                .map_err(|e| anyhow!("Whisper transcription failed on segment {}: {}", i, e))?;
            (text, conf)
        };

        let trimmed = text.trim();
        if !trimmed.is_empty() {
            debug!("Segment {}/{}: {:.1}s, conf={:.2}", i + 1, processable_count, segment_duration_sec, conf);
            all_transcripts.push((text, segment.start_timestamp_ms, segment.end_timestamp_ms));
            total_confidence += conf;
        } else {
            debug!("Segment {}/{}: {:.1}s — empty transcription", i + 1, processable_count, segment_duration_sec);
            all_transcripts.push(("［此段未辨識出文字，請對照原音］".into(), segment.start_timestamp_ms, segment.end_timestamp_ms));
        }
        super::file_job::checkpoint(pool, &meeting_id, &all_transcripts).await?;
        task.chunks(i + 1, processable_count);
        let _ = super::recording_safety::event(&artifact_folder, "transcribing", "chunk_saved", (i + 1) as u64);
    }

    let empty_count = all_transcripts.iter().filter(|(text, _, _)| text == "［此段未辨識出文字，請對照原音］").count();
    if empty_count > 0 {
        let _ = app.emit("import-warning", ImportWarning {
            job_id: task.snapshot().job_id,
            warning: "部分音訊未辨識出文字，請對照原音確認".into(),
            details: Some(format!("全部 {} 段均已送入辨識，{} 段沒有文字輸出；原音檔仍保留。", processable_count, empty_count)),
        });
    }
    let transcribed_count = all_transcripts.len();
    let avg_confidence = if transcribed_count > 0 {
        total_confidence / transcribed_count as f32
    } else {
        0.0
    };

    info!(
        "Transcription complete: {} segments transcribed out of {}, avg confidence: {:.2}",
        transcribed_count, processable_count, avg_confidence
    );

    // Check for cancellation
    if task.cancelled() {
        return Err(anyhow!("已停止處理，原始音檔及已完成的分段仍保留。"));
    }

    emit_progress(&app, task, "saving", 85, "儲存逐字稿…");

    // Create transcript segments
    let segments = create_transcript_segments(&all_transcripts);

    save_import_transcripts(pool, &meeting_id, &segments).await?;
    super::file_job::stage(pool, &meeting_id, "transcribed", None).await?;

    // Write transcripts.json and metadata.json to the meeting folder
    emit_progress(&app, task, "saving", 90, "儲存逐字稿備份…");

    if let Err(e) = write_transcripts_json(&meeting_folder, &segments) {
        warn!("Failed to write transcripts.json: {}", e);
    }

    if let Err(e) = write_import_metadata(
        &meeting_folder,
        &meeting_id,
        &title,
        duration_seconds,
        &dest_filename,
        "import",
    ) {
        warn!("Failed to write metadata.json: {}", e);
    }

    emit_progress(&app, task, "complete", 100, "逐字稿已儲存");

    Ok(ImportResult {
        job_id: task.snapshot().job_id,
        meeting_id,
        title,
        segments_count: segments.len(),
        duration_seconds,
    })
}

/// Emit progress event
fn emit_progress<R: Runtime>(app: &AppHandle<R>, task: &Task, stage: &str, progress: u32, message: &str) {
    task.progress(stage, progress, message);
    let _ = app.emit(
        "import-progress",
        ImportProgress {
            job_id: task.snapshot().job_id,
            stage: stage.to_string(),
            progress_percentage: progress,
            message: message.to_string(),
        },
    );
}


async fn save_import_transcripts(pool: &sqlx::SqlitePool, meeting_id: &str, segments: &[TranscriptSegment]) -> Result<()> {
    let mut tx = pool.begin().await?;
    sqlx::query("DELETE FROM transcripts WHERE meeting_id=?").bind(meeting_id).execute(&mut *tx).await?;
    for segment in segments {
        sqlx::query("INSERT INTO transcripts(id,meeting_id,transcript,timestamp,audio_start_time,audio_end_time,duration) VALUES(?,?,?,?,?,?,?)")
            .bind(&segment.id).bind(meeting_id).bind(&segment.text).bind(&segment.timestamp)
            .bind(segment.audio_start_time).bind(segment.audio_end_time).bind(segment.duration)
            .execute(&mut *tx).await?;
    }
    tx.commit().await?;
    Ok(())
}

#[tauri::command]
pub async fn resume_import_audio_command<R: Runtime>(app: AppHandle<R>, meeting_id: String, cloud_authorized: Option<bool>) -> Result<ImportResult, String> {
    let state=app.try_state::<AppState>().ok_or("無法讀取資料庫")?;
    let job=super::file_job::get(state.db_manager.pool(),&meeting_id).await.map_err(|_|"找不到工作")?;
    let title:String=sqlx::query_scalar("SELECT title FROM meetings WHERE id=?").bind(&meeting_id).fetch_one(state.db_manager.pool()).await.map_err(|_|"找不到會議")?;
    let task=Task::register(Some(meeting_id.clone()),title,job.provider,job.model,None)?;
    task.destination(job.endpoint);
    run_saved_import(app, meeting_id, cloud_authorized, &task).await
}

async fn run_saved_import<R: Runtime>(app: AppHandle<R>, meeting_id: String, cloud_authorized: Option<bool>, task: &Task) -> Result<ImportResult, String> {
    let state = app.try_state::<AppState>().ok_or("無法讀取資料庫")?;
    let pool = state.db_manager.pool();
    let job = super::file_job::get(pool, &meeting_id).await.map_err(|_| "找不到可接續的轉錄工作")?;
    if matches!(job.provider.as_str(), "openai" | "gemini" | "groq" | "openrouter" | "custom-openai") && cloud_authorized != Some(true) {
        return Err("雲端重試可能增加費用；請確認本次傳送對象及費用後再重試。".into());
    }
    if matches!(job.stage.as_str(), "transcribed" | "complete" | "summarizing" | "summary_failed") {
        return Err("逐字稿已完成，請直接產生或重試摘要，不必再次轉錄。".into());
    }
    let title: String = sqlx::query_scalar("SELECT title FROM meetings WHERE id=?")
        .bind(&meeting_id).fetch_one(pool).await.map_err(|_| "找不到會議")?;
    let use_parakeet = job.provider == "parakeet";
    let mut retained_meeting = Some(meeting_id.clone());
    let cloud=is_cloud(&job.provider);
    let result=async {
        let _slot=task.slot().await.map_err(anyhow::Error::msg)?;
        let result=run_import(app.clone(),job.source_path.clone(),title,job.language.clone(),job.model.clone(),Some(job.provider.clone()),Some(job),&mut retained_meeting,task).await;
        if !cloud{super::common::unload_engine_after_batch(use_parakeet).await;}
        result
    }.await;
    task.finish(result.is_ok(),result.as_ref().err().map(|e|e.to_string()).as_deref());
    if let Err(ref error) = result {
        let _ = super::file_job::stage(pool, &meeting_id, if task.cancelled(){"cancelled"}else{"failed"}, Some(&error.to_string())).await;
    }
    result.map_err(|error| error.to_string())
}

/// A new provider attempt keeps the meeting and archives the previous job.
#[tauri::command]
pub async fn restart_recording_transcription<R: Runtime>(app: AppHandle<R>, meeting_id: String,
    provider: String, model: String, language: Option<String>, cloud_authorized: bool,
    expected_endpoint: Option<String>) -> Result<ImportResult, String> {

    let cloud = matches!(provider.as_str(), "openai" | "gemini" | "groq" | "openrouter" | "custom-openai");
    if !cloud && !matches!(provider.as_str(), "whisper" | "localWhisper" | "parakeet" | "builtin-ai") {
        return Err("此服務不支援音訊轉錄。".into());
    }
    if model.trim().is_empty() { return Err("請先選擇轉錄模型。".into()); }
    if cloud && !cloud_authorized { return Err("請先確認本次音訊傳送對象與費用。".into()); }
    let state = app.try_state::<AppState>().ok_or("無法讀取資料庫")?;
    let pool = state.db_manager.pool();
    if cloud {
        let connection = crate::ai_services::connection(pool, &provider).await?;
        if expected_endpoint.as_deref() != Some(connection.endpoint.as_str()) {
            return Err("服務網址已改變，尚未建立新工作或上傳音訊；請重新確認目的地。".into());
        }
    }
    let title:String=sqlx::query_scalar("SELECT title FROM meetings WHERE id=?").bind(&meeting_id).fetch_one(pool).await.map_err(|_|"找不到會議")?;
    let task=Task::register(Some(meeting_id.clone()),title,provider.clone(),Some(model.clone()),None)?;
    task.destination(expected_endpoint);
    // Attempt setup is serialized per meeting by the registry, not globally.
    match super::file_job::get(pool, &meeting_id).await {
        Ok(_) => super::file_job::restart(pool, &meeting_id, &provider, Some(&model), language.as_deref()).await?,
        Err(sqlx::Error::RowNotFound) => {
            let folder: Option<String> = sqlx::query_scalar("SELECT folder_path FROM meetings WHERE id=?")
                .bind(&meeting_id).fetch_one(pool).await.map_err(|_| "找不到會議")?;
            let folder = folder.ok_or("找不到原音資料夾")?;
            let audio = super::retranscription::find_audio_file(Path::new(&folder)).map_err(|_| "找不到原音")?;
            super::file_job::create(pool, &meeting_id, &audio.to_string_lossy(), &provider, Some(&model), language.as_deref())
                .await.map_err(|_| "無法建立轉錄工作")?;
            super::file_job::restart(pool, &meeting_id, &provider, Some(&model), language.as_deref()).await?;
        }
        Err(_) => return Err("無法讀取原工作，資料未變更。".into()),
    }
    run_saved_import(app.clone(), meeting_id, Some(cloud_authorized), &task).await
}

#[tauri::command]
pub fn cancel_import_for_meeting_command(meeting_id: String) -> Result<(), String> {
    super::transcription_tasks::cancel_meeting(&meeting_id)
}

/// Create a new meeting with transcripts in the database
async fn create_meeting_with_transcripts(
    pool: &sqlx::SqlitePool,
    title: &str,
    segments: &[TranscriptSegment],
    folder_path: String,
) -> Result<String> {
    let meeting_id = format!("meeting-{}", Uuid::new_v4());
    let now = chrono::Utc::now();

    // Start transaction
    let mut conn = pool.acquire().await.map_err(|e| anyhow!("DB error: {}", e))?;
    let mut tx = sqlx::Connection::begin(&mut *conn)
        .await
        .map_err(|e| anyhow!("Failed to start transaction: {}", e))?;

    // Insert meeting
    sqlx::query(
        "INSERT INTO meetings (id, title, created_at, updated_at, folder_path)
         VALUES (?, ?, ?, ?, ?)",
    )
    .bind(&meeting_id)
    .bind(title)
    .bind(now)
    .bind(now)
    .bind(&folder_path)
    .execute(&mut *tx)
    .await
    .map_err(|e| anyhow!("Failed to create meeting: {}", e))?;

    // Insert transcripts
    for segment in segments {
        sqlx::query(
            "INSERT INTO transcripts (id, meeting_id, transcript, timestamp, audio_start_time, audio_end_time, duration)
             VALUES (?, ?, ?, ?, ?, ?, ?)",
        )
        .bind(&segment.id)
        .bind(&meeting_id)
        .bind(&segment.text)
        .bind(&segment.timestamp)
        .bind(segment.audio_start_time)
        .bind(segment.audio_end_time)
        .bind(segment.duration)
        .execute(&mut *tx)
        .await
        .map_err(|e| anyhow!("Failed to insert transcript: {}", e))?;
    }

    tx.commit()
        .await
        .map_err(|e| anyhow!("Failed to commit transaction: {}", e))?;

    info!(
        "Created meeting '{}' with {} transcripts",
        meeting_id,
        segments.len()
    );

    Ok(meeting_id)
}

/// Get or initialize the Whisper engine
async fn get_or_init_whisper<R: Runtime>(
    app: &AppHandle<R>,
    requested_model: Option<&str>,
) -> Result<Arc<WhisperEngine>> {
    use crate::whisper_engine::commands::WHISPER_ENGINE;

    let engine = {
        let guard = WHISPER_ENGINE.lock().unwrap_or_else(|e| e.into_inner());
        guard.as_ref().cloned()
    };

    match engine {
        Some(e) => {
            let target_model = match requested_model {
                Some(model) => model.to_string(),
                None => get_configured_model(app, "whisper").await?,
            };

            let current_model = e.get_current_model().await;
            let needs_load = match &current_model {
                Some(loaded) => loaded != &target_model,
                None => true,
            };

            if needs_load {
                info!(
                    "Loading Whisper model '{}' (current: {:?})",
                    target_model, current_model
                );

                if let Err(e) = e.discover_models().await {
                    warn!("Model discovery error (continuing): {}", e);
                }

                e.load_model(&target_model)
                    .await
                    .map_err(|e| anyhow!("Failed to load model '{}': {}", target_model, e))?;
            }

            Ok(e)
        }
        None => Err(anyhow!("Whisper engine not initialized")),
    }
}

/// Get or initialize the Parakeet engine
async fn get_or_init_parakeet<R: Runtime>(
    app: &AppHandle<R>,
    requested_model: Option<&str>,
) -> Result<Arc<ParakeetEngine>> {
    use crate::parakeet_engine::commands::PARAKEET_ENGINE;

    let engine = {
        let guard = PARAKEET_ENGINE.lock().unwrap_or_else(|e| e.into_inner());
        guard.as_ref().cloned()
    };

    match engine {
        Some(e) => {
            let target_model = match requested_model {
                Some(model) => model.to_string(),
                None => get_configured_model(app, "parakeet").await?,
            };

            let current_model = e.get_current_model().await;
            let needs_load = match &current_model {
                Some(loaded) => loaded != &target_model,
                None => true,
            };

            if needs_load {
                info!(
                    "Loading Parakeet model '{}' (current: {:?})",
                    target_model, current_model
                );

                if let Err(e) = e.discover_models().await {
                    warn!("Model discovery error (continuing): {}", e);
                }

                e.load_model(&target_model)
                    .await
                    .map_err(|e| anyhow!("Failed to load model '{}': {}", target_model, e))?;
            }

            Ok(e)
        }
        None => Err(anyhow!("Parakeet engine not initialized")),
    }
}

/// Get the configured model from database
async fn get_configured_model<R: Runtime>(app: &AppHandle<R>, provider_type: &str) -> Result<String> {
    let app_state = app
        .try_state::<AppState>()
        .ok_or_else(|| anyhow!("App state not available"))?;

    let result: Option<(String, String)> = sqlx::query_as(
        "SELECT provider, model FROM transcript_settings WHERE id = '1'",
    )
    .fetch_optional(app_state.db_manager.pool())
    .await
    .map_err(|e| anyhow!("Failed to query config: {}", e))?;

    match result {
        Some((provider, model)) => {
            if (provider_type == "whisper" && (provider == "localWhisper" || provider == "whisper"))
                || (provider_type == "parakeet" && provider == "parakeet")
            {
                Ok(model)
            } else {
                // Return default model for the requested type
                Ok(if provider_type == "parakeet" {
                    DEFAULT_PARAKEET_MODEL.to_string()
                } else {
                    DEFAULT_WHISPER_MODEL.to_string()
                })
            }
        }
        None => Ok(if provider_type == "parakeet" {
            DEFAULT_PARAKEET_MODEL.to_string()
        } else {
            DEFAULT_WHISPER_MODEL.to_string()
        }),
    }
}

/// Write metadata.json to a meeting folder (atomic write with temp file)
fn write_import_metadata(
    folder: &Path,
    meeting_id: &str,
    title: &str,
    duration_seconds: f64,
    audio_filename: &str,
    source: &str,
) -> Result<()> {
    let metadata_path = folder.join("metadata.json");
    let temp_path = folder.join(".metadata.json.tmp");
    let now = chrono::Utc::now().to_rfc3339();

    let updates = serde_json::json!({
        "version": "1.0",
        "meeting_id": meeting_id,
        "meeting_name": title,
        "created_at": now,
        "completed_at": now,
        "duration_seconds": duration_seconds,
        "audio_file": audio_filename,
        "transcript_file": "transcripts.json",
        "status": "completed",
        "source": source
    });

    // Preserve capture metadata such as video, devices and original creation time.
    let mut json: serde_json::Value = if metadata_path.exists() {
        serde_json::from_slice(&std::fs::read(&metadata_path)?)?
    } else { serde_json::json!({}) };
    let original_created = json.get("created_at").cloned();
    let original_source = json.get("source").cloned();
    for (key, value) in updates.as_object().unwrap() { json[key] = value.clone(); }
    if let Some(created) = original_created { json["created_at"] = created; }
    if let Some(source) = original_source { json["source"] = source; }
    let json_string = serde_json::to_string_pretty(&json)?;
    std::fs::write(&temp_path, &json_string)?;
    std::fs::rename(&temp_path, &metadata_path)?;

    info!("Wrote metadata.json to {}", metadata_path.display());
    Ok(())
}

// ============================================================================
// Tauri Commands
// ============================================================================

/// Select an audio file and validate it
#[tauri::command]
pub async fn select_and_validate_audio_command<R: Runtime>(
    app: AppHandle<R>,
) -> Result<Option<AudioFileInfo>, String> {
    info!("Opening file dialog for audio import");

    // Use spawn_blocking to avoid blocking async runtime
    let app_clone = app.clone();
    let file_path = tokio::task::spawn_blocking(move || {
        app_clone
            .dialog()
            .file()
            .add_filter("Audio Files", &AUDIO_EXTENSIONS.iter().map(|s| *s).collect::<Vec<_>>())
            .blocking_pick_file()
    })
    .await
    .map_err(|e| format!("File dialog task failed: {}", e))?;

    match file_path {
        Some(path) => {
            let path_str = path.to_string();
            info!("User selected: {}", path_str);

            match validate_audio_file(Path::new(&path_str)) {
                Ok(info) => Ok(Some(info)),
                Err(e) => {
                    error!("Validation failed: {}", e);
                    Err(e.to_string())
                }
            }
        }
        None => {
            info!("User cancelled file selection");
            Ok(None)
        }
    }
}

/// Validate an audio file from a given path (for drag-drop)
#[tauri::command]
pub async fn validate_audio_file_command(path: String) -> Result<AudioFileInfo, String> {
    info!("Validating audio file: {}", path);
    validate_audio_file(Path::new(&path)).map_err(|e| e.to_string())
}

/// Start importing an audio file (Beta gated using configContext.betaFeatures)
#[tauri::command]
pub async fn start_import_audio_command<R: Runtime>(
    app: AppHandle<R>,
    source_path: String,
    title: String,
    language: Option<String>,
    model: Option<String>,
    provider: Option<String>,
    cloud_authorized: Option<bool>,
    request_id: Option<String>,
) -> Result<ImportStarted, String> {
    if matches!(provider.as_deref(), Some("openai" | "gemini" | "groq" | "openrouter" | "custom-openai")) && cloud_authorized != Some(true) {
        return Err("請先確認本次音訊的傳送對象及費用，再開始處理。".into());
    }
    let task=Task::register(None,title.clone(),provider.clone().unwrap_or("whisper".into()),model.clone(),request_id)?;
    if is_cloud(provider.as_deref().unwrap_or("whisper")){
        let state=app.try_state::<AppState>().ok_or("無法讀取服務設定")?;
        let connection=crate::ai_services::connection(state.db_manager.pool(),provider.as_deref().unwrap()).await?;
        task.destination(Some(connection.endpoint));
    }
    let job_id=task.snapshot().job_id;
    tauri::async_runtime::spawn(async move {
        if let Err(e)=start_registered_import(app,source_path,title,language,model,provider,task).await{error!("Import failed: {}",e);}
    });
    Ok(ImportStarted{job_id,message:"已加入轉錄工作清單".into()})
}

#[tauri::command]
pub async fn cancel_import_command() -> Result<(),String> {
    Err("請從錄音與轉錄中心選擇指定工作取消，避免取消其他會議".into())
}
#[tauri::command]
pub async fn is_import_in_progress_command()->bool {
    super::transcription_tasks::list_transcription_tasks().iter().any(|r|matches!(r.status.as_str(),"queued"|"running"|"cancelling"))
}

#[cfg(test)]
mod tests {
    use crate::audio::common::split_segment_at_silence;
    use super::*;
    #[test]
    fn retranscription_preserves_capture_metadata() {
        let folder = tempfile::tempdir().unwrap();
        std::fs::write(folder.path().join("metadata.json"), r#"{"created_at":"original-date","video_file":"screen.mp4","source":"recording","devices":{"mic":"test"}}"#).unwrap();
        write_import_metadata(folder.path(), "same-meeting", "測試", 31.0, "audio.wav", "import").unwrap();
        let value: serde_json::Value = serde_json::from_slice(&std::fs::read(folder.path().join("metadata.json")).unwrap()).unwrap();
        assert_eq!(value["video_file"], "screen.mp4");
        assert_eq!(value["created_at"], "original-date");
        assert_eq!(value["source"], "recording");
        assert_eq!(value["devices"]["mic"], "test");
        assert_eq!(value["duration_seconds"], 31.0);
    }

    #[test]
    fn test_audio_extensions() {
        assert!(AUDIO_EXTENSIONS.contains(&"mp4"));
        assert!(AUDIO_EXTENSIONS.contains(&"wav"));
        assert!(AUDIO_EXTENSIONS.contains(&"mp3"));
        assert!(!AUDIO_EXTENSIONS.contains(&"txt"));
    }

    #[test]
    fn test_create_transcript_segments_empty() {
        let transcripts: Vec<(String, f64, f64)> = vec![];
        let segments = create_transcript_segments(&transcripts);
        assert!(segments.is_empty());
    }

    #[test]
    fn test_create_transcript_segments_single() {
        let transcripts = vec![("Hello world".to_string(), 0.0, 1500.0)];
        let segments = create_transcript_segments(&transcripts);

        assert_eq!(segments.len(), 1);
        assert_eq!(segments[0].text, "Hello world");
        assert_eq!(segments[0].audio_start_time, Some(0.0));
        assert_eq!(segments[0].audio_end_time, Some(1.5));
    }

    #[test]
    fn test_extract_duration_from_metadata_wav() {
        // Test with sample WAV file if available
        let test_path = Path::new("../../backend/whisper.cpp/samples/jfk.wav");
        if test_path.exists() {
            let result = extract_duration_from_metadata(test_path);
            // Should succeed and return a reasonable duration
            assert!(result.is_ok());
            let duration = result.unwrap();
            assert!(duration > 0.0 && duration < 60.0, "Duration {} seems unreasonable", duration);
        }
    }

    #[test]
    fn test_extract_duration_from_metadata_mp3() {
        // Test with sample MP3 file if available
        let test_path = Path::new("../../backend/whisper.cpp/samples/jfk.mp3");
        if test_path.exists() {
            let result = extract_duration_from_metadata(test_path);
            // MP3 files may not have n_frames metadata, so fallback is expected
            // We just verify it doesn't panic
            let _ = result;
        }
    }

    #[test]
    fn test_validate_audio_file_with_metadata() {
        // Test validation with actual audio file
        let test_path = Path::new("../../backend/whisper.cpp/samples/jfk.wav");
        if test_path.exists() {
            let result = validate_audio_file(test_path);
            assert!(result.is_ok());
            let info = result.unwrap();
            assert_eq!(info.format, "WAV");
            assert!(info.duration_seconds > 0.0);
            assert!(info.size_bytes > 0);
        }
    }

    #[test]
    fn test_validate_audio_file_nonexistent() {
        let result = validate_audio_file(Path::new("/nonexistent/file.mp4"));
        assert!(result.is_err());
        assert!(result.unwrap_err().to_string().contains("does not exist"));
    }

    #[test]
    fn test_validate_audio_file_wrong_extension() {
        // Create a temporary file with wrong extension
        let temp_dir = std::env::temp_dir();
        let temp_file = temp_dir.join("test_audio.txt");
        let _ = std::fs::write(&temp_file, b"dummy content");

        let result = validate_audio_file(&temp_file);
        assert!(result.is_err());
        assert!(result.unwrap_err().to_string().contains("Unsupported format"));

        // Cleanup
        let _ = std::fs::remove_file(temp_file);
    }

    #[test]
    fn test_split_segment_at_silence_short_segment() {
        // Segment shorter than max — returned as-is
        let segment = crate::audio::vad::SpeechSegment {
            samples: vec![0.1; 16000], // 1 second
            start_timestamp_ms: 0.0,
            end_timestamp_ms: 1000.0,
            confidence: 0.9,
        };
        let result = split_segment_at_silence(&segment, 25 * 16000);
        assert_eq!(result.len(), 1);
        assert_eq!(result[0].samples.len(), 16000);
    }

    #[test]
    fn test_split_segment_at_silence_splits_long_segment() {
        // 60-second segment of low-level noise with a silent gap at ~25s
        let mut samples = vec![0.01f32; 60 * 16000];
        // Insert silence at 25 seconds (sample 400000)
        for i in (25 * 16000)..(25 * 16000 + 3200) {
            samples[i] = 0.0;
        }
        let segment = crate::audio::vad::SpeechSegment {
            samples,
            start_timestamp_ms: 0.0,
            end_timestamp_ms: 60_000.0,
            confidence: 0.9,
        };

        let result = split_segment_at_silence(&segment, 25 * 16000);
        assert!(result.len() >= 2, "Should split into at least 2 segments, got {}", result.len());

        // All sub-segments should have samples
        for (i, seg) in result.iter().enumerate() {
            assert!(!seg.samples.is_empty(), "Segment {} is empty", i);
            assert!(
                seg.start_timestamp_ms < seg.end_timestamp_ms,
                "Segment {} has invalid timestamps: {} >= {}",
                i, seg.start_timestamp_ms, seg.end_timestamp_ms
            );
        }
    }

    #[test]
    fn test_split_segment_at_silence_no_silence_uses_overlap() {
        // Continuous speech (constant energy) — should still split with overlap
        let segment = crate::audio::vad::SpeechSegment {
            samples: vec![0.5f32; 60 * 16000], // 60 seconds of "speech"
            start_timestamp_ms: 0.0,
            end_timestamp_ms: 60_000.0,
            confidence: 0.9,
        };

        let result = split_segment_at_silence(&segment, 25 * 16000);
        assert!(result.len() >= 2);

        // Total samples should exceed input due to overlap
        let total_samples: usize = result.iter().map(|s| s.samples.len()).sum();
        assert!(total_samples >= 60 * 16000, "Overlap should not lose samples");
    }

    #[test]
    fn test_write_transcripts_json() {
        let dir = tempfile::tempdir().unwrap();
        let segments = vec![
            TranscriptSegment {
                id: "t-1".to_string(),
                text: "Hello world".to_string(),
                timestamp: "2024-01-01T00:00:00Z".to_string(),
                audio_start_time: Some(0.0),
                audio_end_time: Some(1.5),
                duration: Some(1.5),
            },
            TranscriptSegment {
                id: "t-2".to_string(),
                text: "Second segment".to_string(),
                timestamp: "2024-01-01T00:00:01Z".to_string(),
                audio_start_time: Some(2.0),
                audio_end_time: Some(3.5),
                duration: Some(1.5),
            },
        ];

        let result = write_transcripts_json(dir.path(), &segments);
        assert!(result.is_ok(), "write_transcripts_json failed: {:?}", result);

        // Verify file exists and is valid JSON
        let path = dir.path().join("transcripts.json");
        assert!(path.exists());

        let content = std::fs::read_to_string(&path).unwrap();
        let parsed: serde_json::Value = serde_json::from_str(&content).unwrap();
        assert_eq!(parsed["total_segments"], 2);
        assert_eq!(parsed["version"], "1.0");
        assert_eq!(parsed["segments"][0]["text"], "Hello world");
        assert_eq!(parsed["segments"][1]["text"], "Second segment");
        assert_eq!(parsed["segments"][0]["sequence_id"], 0);
        assert_eq!(parsed["segments"][1]["sequence_id"], 1);

        // Verify temp file was cleaned up
        assert!(!dir.path().join(".transcripts.json.tmp").exists());
    }

    #[test]
    fn test_write_import_metadata() {
        let dir = tempfile::tempdir().unwrap();

        let result = write_import_metadata(
            dir.path(),
            "meeting-123",
            "Test Meeting",
            1800.0,
            "audio.mp4",
            "import",
        );
        assert!(result.is_ok(), "write_import_metadata failed: {:?}", result);

        let path = dir.path().join("metadata.json");
        assert!(path.exists());

        let content = std::fs::read_to_string(&path).unwrap();
        let parsed: serde_json::Value = serde_json::from_str(&content).unwrap();
        assert_eq!(parsed["version"], "1.0");
        assert_eq!(parsed["meeting_id"], "meeting-123");
        assert_eq!(parsed["meeting_name"], "Test Meeting");
        assert_eq!(parsed["duration_seconds"], 1800.0);
        assert_eq!(parsed["audio_file"], "audio.mp4");
        assert_eq!(parsed["status"], "completed");
        assert_eq!(parsed["source"], "import");
    }

    /// Integration test that decodes a real audio file and runs VAD.
    /// Run with: TEST_AUDIO_PATH=/path/to/audio.mp4 cargo test -- --ignored --nocapture
    #[test]
    #[ignore]
    fn test_import_pipeline_decode_vad() {
        let audio_path = std::env::var("TEST_AUDIO_PATH")
            .expect("Set TEST_AUDIO_PATH to run this integration test");

        let path = Path::new(&audio_path);
        assert!(path.exists(), "Audio file not found: {}", audio_path);

        // Step 1: Decode
        println!("Decoding {}...", audio_path);
        let decoded = crate::audio::decoder::decode_audio_file(path)
            .expect("Failed to decode audio file");
        println!(
            "Decoded: {:.2}s, {}Hz, {} channels, {} samples",
            decoded.duration_seconds,
            decoded.sample_rate,
            decoded.channels,
            decoded.samples.len()
        );

        // Step 2: Resample to 16kHz mono
        println!("Resampling to 16kHz mono...");
        let samples = decoded.to_whisper_format();
        println!("Resampled: {} samples ({:.2}s at 16kHz)", samples.len(), samples.len() as f64 / 16000.0);

        // Step 3: Run VAD with both redemption times and compare
        for redemption_ms in [400u32, 2000] {
            println!("\n--- VAD with redemption_time={}ms ---", redemption_ms);
            let segments = crate::audio::vad::get_speech_chunks_with_progress(
                &samples,
                redemption_ms,
                |progress, count| {
                    if progress % 20 == 0 {
                        println!("  VAD progress: {}% ({} segments)", progress, count);
                    }
                    true
                },
            ).expect("VAD failed");

            let total_segments = segments.len();
            println!("Found {} segments", total_segments);

            if !segments.is_empty() {
                let durations: Vec<f64> = segments.iter()
                    .map(|s| s.end_timestamp_ms - s.start_timestamp_ms)
                    .collect();
                let total_speech: f64 = durations.iter().sum();
                let avg = total_speech / durations.len() as f64;
                let min = durations.iter().cloned().fold(f64::INFINITY, f64::min);
                let max = durations.iter().cloned().fold(f64::NEG_INFINITY, f64::max);

                println!(
                    "Stats: avg={:.0}ms, min={:.0}ms, max={:.0}ms, total_speech={:.1}s/{:.1}s ({:.0}%)",
                    avg, min, max,
                    total_speech / 1000.0,
                    decoded.duration_seconds,
                    (total_speech / 1000.0 / decoded.duration_seconds) * 100.0
                );

                // Segments over 25s that would be split
                let oversized = durations.iter().filter(|d| **d > 25_000.0).count();
                println!("Segments >25s (would be split): {}", oversized);

                // Basic sanity checks
                assert!(total_speech > 0.0, "No speech detected");
                for (i, seg) in segments.iter().enumerate() {
                    assert!(!seg.samples.is_empty(), "Segment {} has no samples", i);
                    assert!(
                        seg.end_timestamp_ms > seg.start_timestamp_ms,
                        "Segment {} has invalid timestamps",
                        i
                    );
                }
            }
        }
    }
}
