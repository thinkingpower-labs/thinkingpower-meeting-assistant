use std::sync::atomic::{AtomicBool, Ordering};

// All file transcription entry points share native model instances. Keep this
// lease until model cleanup finishes, including failure and cancellation.
static BATCH_ACTIVE: AtomicBool = AtomicBool::new(false);
pub(crate) struct BatchLease;
impl BatchLease {
    pub(crate) fn acquire() -> Result<Self, String> {
        BATCH_ACTIVE
            .compare_exchange(false, true, Ordering::SeqCst, Ordering::SeqCst)
            .map(|_| Self)
            .map_err(|_| {
                "另一筆音檔正在轉錄，請等待完成或取消該工作後再接續；原音與進度仍保留。".into()
            })
    }
}
impl Drop for BatchLease {
    fn drop(&mut self) {
        BATCH_ACTIVE.store(false, Ordering::SeqCst);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn excludes_competitors_and_releases_after_error_or_unwind() {
        let first = BatchLease::acquire().unwrap();
        assert!(BatchLease::acquire().is_err());
        drop(first);
        let _ = std::panic::catch_unwind(|| {
            let _lease = BatchLease::acquire().unwrap();
            panic!("synthetic inference failure");
        });
        assert!(BatchLease::acquire().is_ok());
        let concurrent = std::sync::Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let workers = (0..8)
            .map(|_| {
                let concurrent = concurrent.clone();
                std::thread::spawn(move || {
                    for _ in 0..500 {
                        if let Ok(_lease) = BatchLease::acquire() {
                            assert_eq!(concurrent.fetch_add(1, Ordering::SeqCst), 0);
                            std::thread::yield_now();
                            assert_eq!(concurrent.fetch_sub(1, Ordering::SeqCst), 1);
                        }
                    }
                })
            })
            .collect::<Vec<_>>();
        for worker in workers {
            worker.join().unwrap();
        }
        assert!(BatchLease::acquire().is_ok());
    }
}
