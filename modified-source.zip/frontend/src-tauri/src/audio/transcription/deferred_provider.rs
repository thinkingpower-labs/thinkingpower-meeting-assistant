//! Cloud mode captures audio locally; network processing begins only after stop.
use super::provider::{TranscriptionProvider, TranscriptResult, TranscriptionError};
pub struct DeferredProvider;
#[async_trait::async_trait]
impl TranscriptionProvider for DeferredProvider {
    async fn transcribe(&self, _: Vec<f32>, _: Option<String>) -> Result<TranscriptResult, TranscriptionError> {
        Ok(TranscriptResult { text: String::new(), confidence: None, is_partial: false })
    }
    async fn is_model_loaded(&self) -> bool { true }
    async fn get_current_model(&self) -> Option<String> { Some("錄音結束後轉錄".into()) }
    fn provider_name(&self) -> &'static str { "deferred-file-transcription" }
}
