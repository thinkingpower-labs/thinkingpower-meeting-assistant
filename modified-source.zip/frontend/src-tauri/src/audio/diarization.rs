//! Whole-recording speaker labels: identities are never merged across API requests.
use anyhow::{anyhow, Result};
use serde::{Deserialize, Serialize};
use sqlx::SqlitePool;
use std::{collections::BTreeMap, path::Path, time::Duration};
use super::transcription_tasks::Task;

pub const MODEL: &str = "gpt-4o-transcribe-diarize";
const MAX_UPLOAD: u64 = 24_000_000;
const MAX_RESPONSE: usize = 16_000_000;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Segment {
    pub start: f64,
    pub end: f64,
    pub text: String,
    pub speaker: Option<String>,
}
#[derive(Deserialize)]
struct Response { segments: Vec<Segment> }

pub fn parse(bytes: &[u8], duration: f64) -> Result<Vec<Segment>> {
    let response: Response = serde_json::from_slice(bytes).map_err(|_| anyhow!("說話人結果格式無法讀取；已保留收到的結果，未自動重送。"))?;
    let mut previous = 0.0;
    if response.segments.is_empty() { return Err(anyhow!("服務未回傳說話人分段，既有逐字稿仍保留。")); }
    for segment in &response.segments {
        if !segment.start.is_finite() || !segment.end.is_finite() || segment.start < previous
            || segment.end <= segment.start || segment.end > duration + 2.0 || segment.text.trim().is_empty()
            || segment.speaker.as_ref().is_some_and(|s| s.is_empty() || s.len() > 128 || s.chars().any(char::is_control)) {
            return Err(anyhow!("說話人分段時間或內容不完整，既有逐字稿仍保留。"));
        }
        previous = segment.start;
    }
    Ok(response.segments)
}

async fn request(base: &str, key: Option<&str>, audio: Vec<u8>) -> Result<Vec<u8>> {
    let client = reqwest::Client::builder().connect_timeout(Duration::from_secs(15))
        .timeout(Duration::from_secs(1800)).redirect(reqwest::redirect::Policy::none()).build()?;
    let form = reqwest::multipart::Form::new().text("model", MODEL)
        .text("response_format", "diarized_json").text("chunking_strategy", "auto")
        .part("file", reqwest::multipart::Part::bytes(audio).file_name("meeting.mp3").mime_str("audio/mpeg")?);
    let mut req = client.post(format!("{}/audio/transcriptions", base.trim_end_matches('/'))).multipart(form);
    if let Some(key) = key { req = req.bearer_auth(key); }
    let mut response = req.send().await.map_err(|e| anyhow!(super::cloud_transcription::network_error(e)))?;
    if !response.status().is_success() { return Err(anyhow!(super::cloud_transcription::status_error(response.status().as_u16()))); }
    let mut bytes = Vec::new();
    while let Some(chunk) = response.chunk().await.map_err(|e| anyhow!(super::cloud_transcription::network_error(e)))? {
        if bytes.len() + chunk.len() > MAX_RESPONSE { return Err(anyhow!("說話人結果超過大小上限，未重送。")); }
        bytes.extend_from_slice(&chunk);
    }
    Ok(bytes)
}

/// Cache before publishing, so a database failure can resume without another paid call.
pub(crate) async fn transcribe(source: &Path, folder: &Path, base: &str, key: Option<&str>, duration: f64, task: &Task) -> Result<Vec<Segment>> {
    let cache = folder.join("diarized-response.json");
    if cache.exists() {
        if std::fs::metadata(&cache)?.len() > MAX_RESPONSE as u64 { return Err(anyhow!("已保存的結果超過大小上限。")); }
        return parse(&std::fs::read(cache)?, duration);
    }
    if chrono::Utc::now().date_naive() >= chrono::NaiveDate::from_ymd_opt(2027, 2, 26).unwrap() {
        return Err(anyhow!("此 OpenAI 說話人模型已到公告停用日，請更新程式後再使用。原音保留。"));
    }
    // A single request keeps A/B identities consistent throughout the recording.
    // Reject oversized recordings instead of joining unrelated A/B labels.
    if duration > 7800.0 { return Err(anyhow!("此版說話人分離支援最長 130 分鐘；原音保留，請先剪輯成獨立會議。")); }
    task.check().map_err(anyhow::Error::msg)?;
    task.progress("decoding", 25, "準備整段錄音的說話人辨識音訊…");
    let compressed = folder.join("diarization-upload.mp3");
    let args = ["-hide_banner", "-nostdin", "-loglevel", "error", "-y", "-i"].iter().map(std::ffi::OsString::from)
        .chain(std::iter::once(source.as_os_str().to_owned()))
        .chain(["-vn", "-ac", "1", "-ar", "16000", "-c:a", "libmp3lame", "-b:a", "24k"].iter().map(std::ffi::OsString::from))
        .chain(std::iter::once(compressed.as_os_str().to_owned())).collect::<Vec<_>>();
    let cancel = task.cancellation_token();
    tokio::select! {
        biased;
        _ = cancel.cancelled() => return Err(anyhow!("已取消，尚未上傳音訊。")),
        result = super::recording_safety::ffmpeg(&args, Duration::from_secs(1200), folder, "diarization_encode") => result?,
    }
    let size = std::fs::metadata(&compressed)?.len();
    if size == 0 || size > MAX_UPLOAD { return Err(anyhow!("壓縮後音訊超過 24 MB 上限，尚未上傳；原音保留。")); }
    task.check().map_err(anyhow::Error::msg)?;
    let audio = std::fs::read(&compressed)?;
    task.chunks(0, 1);
    task.progress("uploading", 40, "OpenAI 正在分離說話人；服務未提供完成百分比。取消後仍可能計費。");
    let bytes = tokio::select! {
        biased;
        _ = cancel.cancelled() => return Err(anyhow!("已取消等待，原音與舊逐字稿保留；已送出的請求仍可能計費，未自動重送。")),
        result = request(base, key, audio) => result?,
    };
    super::recording_safety::atomic_json(&cache, &serde_json::from_slice::<serde_json::Value>(&bytes)
        .map_err(|_| anyhow!("服務回傳無效 JSON，未自動重送。"))?).map_err(anyhow::Error::msg)?;
    let _ = std::fs::remove_file(&compressed);
    task.check().map_err(anyhow::Error::msg)?;
    parse(&bytes, duration)
}

pub(crate) async fn publish(pool: &SqlitePool, meeting: &str, attempt: &str, segments: &[Segment]) -> Result<()> {
    if segments.is_empty() { return Err(anyhow!("沒有可發布的分段；舊稿保留。")); }
    let mut tx = pool.begin().await?;
    sqlx::query("DELETE FROM transcripts WHERE meeting_id=?").bind(meeting).execute(&mut *tx).await?;
    let mut names = BTreeMap::new();
    for segment in segments {
        let speaker = segment.speaker.as_ref().map(|id| format!("diarized:{attempt}:{id}"));
        if let Some(ref id) = speaker {
            let next = names.len() + 1;
            names.entry(id.clone()).or_insert_with(|| format!("說話人 {next}"));
        }
        sqlx::query("INSERT INTO transcripts(id,meeting_id,transcript,timestamp,audio_start_time,audio_end_time,duration,speaker) VALUES(?,?,?,?,?,?,?,?)")
            .bind(uuid::Uuid::new_v4().to_string()).bind(meeting).bind(&segment.text).bind(chrono::Utc::now().to_rfc3339())
            .bind(segment.start).bind(segment.end).bind(segment.end-segment.start).bind(speaker).execute(&mut *tx).await?;
    }
    for (id, name) in names {
        // Resuming an already received attempt must preserve user-edited names.
        sqlx::query("INSERT OR IGNORE INTO meeting_speakers(meeting_id,speaker_id,display_name) VALUES(?,?,?)")
            .bind(meeting).bind(id).bind(name).execute(&mut *tx).await?;
    }
    let completed = segments.iter().map(|s| (&s.text, s.start * 1000.0, s.end * 1000.0)).collect::<Vec<_>>();
    sqlx::query("UPDATE audio_jobs SET stage='transcribed',error=NULL,completed_chunks=? WHERE meeting_id=?")
        .bind(serde_json::to_string(&completed)?).bind(meeting).execute(&mut *tx).await?;
    tx.commit().await?;
    Ok(())
}

#[derive(Serialize, sqlx::FromRow)]
pub struct Speaker { pub speaker_id: String, pub display_name: String }

pub(crate) async fn speakers(pool: &SqlitePool, meeting: &str) -> Result<Vec<Speaker>, sqlx::Error> {
    sqlx::query_as("SELECT s.speaker_id,s.display_name FROM meeting_speakers s WHERE s.meeting_id=? AND EXISTS(SELECT 1 FROM transcripts t WHERE t.meeting_id=s.meeting_id AND t.speaker=s.speaker_id) ORDER BY s.rowid")
        .bind(meeting).fetch_all(pool).await
}

pub(crate) async fn rename(pool: &SqlitePool, meeting: &str, speaker: &str, name: &str) -> Result<(), String> {
    let name = name.trim();
    if name.is_empty() || name.chars().count() > 80 || name.chars().any(char::is_control) {
        return Err("姓名請填入 1–80 字，不能包含換行或控制字元。".into());
    }
    let result = sqlx::query("UPDATE meeting_speakers SET display_name=? WHERE meeting_id=? AND speaker_id=? AND EXISTS(SELECT 1 FROM transcripts WHERE meeting_id=? AND speaker=?)")
        .bind(name).bind(meeting).bind(speaker).bind(meeting).bind(speaker).execute(pool).await.map_err(|_| "無法儲存姓名")?;
    if result.rows_affected() != 1 { return Err("這位說話人已不屬於目前逐字稿，請重新整理。".into()); }
    Ok(())
}

#[tauri::command]
pub async fn list_meeting_speakers<R: tauri::Runtime>(app: tauri::AppHandle<R>, meeting_id: String) -> Result<Vec<Speaker>, String> {
    use tauri::Manager;
    let state = app.state::<crate::state::AppState>();
    speakers(state.db_manager.pool(), &meeting_id).await.map_err(|_| "無法讀取說話人".into())
}

#[tauri::command]
pub async fn rename_meeting_speaker<R: tauri::Runtime>(app: tauri::AppHandle<R>, meeting_id: String, speaker_id: String, display_name: String) -> Result<(), String> {
    use tauri::Manager;
    let state = app.state::<crate::state::AppState>();
    rename(state.db_manager.pool(), &meeting_id, &speaker_id, &display_name).await
}

#[cfg(test)]
mod tests {
    use super::*;
    use sqlx::Row;
    #[test]
    fn validates_timeline_and_preserves_overlap_and_identity() {
        let value = br#"{"segments":[{"start":0,"end":3,"speaker":"A","text":"one"},{"start":2,"end":4,"speaker":"B","text":"two"},{"start":4,"end":6,"speaker":"A","text":"three"}]}"#;
        let segments = parse(value, 6.0).unwrap();
        assert_eq!(segments[0].speaker, segments[2].speaker);
        assert_ne!(segments[0].speaker, segments[1].speaker);
        assert!(parse(value, 2.0).is_err());
        assert!(parse(br#"{"segments":[]}"#, 6.0).is_err());
        assert!(parse(br#"{"segments":[{"start":-1,"end":1,"text":"x"}]}"#, 6.0).is_err());
    }

    #[tokio::test]
    async fn names_are_scoped_persisted_and_preserved_on_resume() {
        let pool = SqlitePool::connect("sqlite::memory:").await.unwrap();
        sqlx::query("CREATE TABLE meetings(id TEXT PRIMARY KEY)").execute(&pool).await.unwrap();
        sqlx::query("CREATE TABLE transcripts(id TEXT,meeting_id TEXT,transcript TEXT,timestamp TEXT,audio_start_time REAL,audio_end_time REAL,duration REAL,speaker TEXT)").execute(&pool).await.unwrap();
        sqlx::query("CREATE TABLE audio_jobs(meeting_id TEXT,stage TEXT,error TEXT,completed_chunks TEXT)").execute(&pool).await.unwrap();
        sqlx::raw_sql(include_str!("../../migrations/20261021000000_meeting_speakers.sql")).execute(&pool).await.unwrap();
        sqlx::query("INSERT INTO meetings VALUES('one'),('two')").execute(&pool).await.unwrap();
        let segments = parse(br#"{"segments":[{"start":0,"end":2,"speaker":"A","text":"original"}]}"#, 2.0).unwrap();
        publish(&pool,"one","attempt1",&segments).await.unwrap();
        publish(&pool,"two","attempt1",&segments).await.unwrap();
        rename(&pool,"one","diarized:attempt1:A","飛鳥").await.unwrap();
        publish(&pool,"one","attempt1",&segments).await.unwrap();
        assert_eq!(speakers(&pool,"one").await.unwrap()[0].display_name,"飛鳥");
        assert_eq!(speakers(&pool,"two").await.unwrap()[0].display_name,"說話人 1");
        assert!(rename(&pool,"one","missing","x").await.is_err());
        assert!(rename(&pool,"one","diarized:attempt1:A","a\nb").await.is_err());
        publish(&pool,"one","attempt2",&segments).await.unwrap();
        assert_eq!(speakers(&pool,"one").await.unwrap()[0].display_name,"說話人 1");
        let text: String = sqlx::query("SELECT transcript FROM transcripts WHERE meeting_id='one'").fetch_one(&pool).await.unwrap().get(0);
        assert_eq!(text,"original");
    }

    #[tokio::test]
    async fn persisted_names_reopen_paginate_and_export() {
        let dir = tempfile::tempdir().unwrap();
        let options = sqlx::sqlite::SqliteConnectOptions::new().filename(dir.path().join("speaker.sqlite")).create_if_missing(true);
        let pool = sqlx::sqlite::SqlitePoolOptions::new().max_connections(1).connect_with(options.clone()).await.unwrap();
        sqlx::migrate!("./migrations").run(&pool).await.unwrap();
        sqlx::query("INSERT INTO meetings(id,title,created_at,updated_at) VALUES('meeting','fixture',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)").execute(&pool).await.unwrap();
        let segments = parse(br#"{"segments":[{"start":0,"end":2,"speaker":"A","text":"hello"},{"start":2,"end":4,"speaker":"B","text":"world"},{"start":4,"end":6,"speaker":"A","text":"again"}]}"#,6.0).unwrap();
        publish(&pool,"meeting","attempt",&segments).await.unwrap();
        rename(&pool,"meeting","diarized:attempt:A","飛鳥").await.unwrap();
        pool.close().await;
        let pool = SqlitePool::connect_with(options).await.unwrap();
        let (rows,total) = crate::database::repositories::meeting::MeetingsRepository::get_meeting_transcripts_paginated(&pool,"meeting",1,2).await.unwrap();
        assert_eq!(total,3); assert_eq!(rows[0].speaker_name.as_deref(),Some("飛鳥"));
        assert_eq!(rows[0].transcript,"again");
        let exported = crate::flybird::export_content(&pool,"meeting","txt").await.unwrap();
        assert!(exported.contains("飛鳥：hello") && exported.contains("飛鳥：again") && exported.contains("說話人 2：world"));
    }

    #[tokio::test]
    async fn whole_recording_transport_and_cache_do_not_repeat_paid_request() {
        use tokio::{net::TcpListener,io::{AsyncReadExt,AsyncWriteExt}};
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let address = listener.local_addr().unwrap();
        let server = tokio::spawn(async move {
            let (mut stream,_) = listener.accept().await.unwrap();
            let mut bytes = Vec::new(); let mut buffer = [0u8;8192];
            loop {
                let n = stream.read(&mut buffer).await.unwrap(); if n==0 {break;} bytes.extend_from_slice(&buffer[..n]);
                if let Some(end) = bytes.windows(4).position(|s|s==b"\r\n\r\n") {
                    let header = String::from_utf8_lossy(&bytes[..end]).to_lowercase();
                    let length: usize = header.lines().find_map(|s|s.strip_prefix("content-length:")).unwrap().trim().parse().unwrap();
                    if bytes.len() >= end+4+length {break;}
                }
            }
            let request = String::from_utf8_lossy(&bytes);
            assert!(request.contains("gpt-4o-transcribe-diarize") && request.contains("diarized_json") && request.contains("chunking_strategy") && request.contains("auto"));
            assert!(request.contains("meeting.mp3") && !request.contains("name=\"prompt\""));
            let body = r#"{"segments":[{"start":0,"end":1,"speaker":"A","text":"first"},{"start":1,"end":2,"speaker":"B","text":"second"}]}"#;
            stream.write_all(format!("HTTP/1.1 200 OK\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",body.len(),body).as_bytes()).await.unwrap();
        });
        let dir = tempfile::tempdir().unwrap();
        let source = dir.path().join("source.wav");
        std::fs::write(&source,super::super::cloud_transcription::wav(&vec![0.1;48000])).unwrap();
        let task = Task::register(None,"synthetic".into(),"openai".into(),Some(MODEL.into()),None).unwrap();
        let base = format!("http://{address}");
        let segments = transcribe(&source,dir.path(),&base,Some("fake-test-key"),3.0,&task).await.unwrap();
        server.await.unwrap();
        assert_eq!(segments.len(),2);
        let cached = transcribe(&source,dir.path(),"http://127.0.0.1:1",None,3.0,&task).await.unwrap();
        assert_eq!(cached[1].speaker.as_deref(),Some("B"));
        assert!(parse(&std::fs::read(dir.path().join("diarized-response.json")).unwrap(),3.0).is_ok());
        assert!(!dir.path().join("diarization-upload.mp3").exists());
        task.finish(true,None);
        let cancelled = Task::register(None,"cancel fixture".into(),"openai".into(),Some(MODEL.into()),None).unwrap();
        super::super::transcription_tasks::cancel_transcription_task(cancelled.snapshot().job_id).unwrap();
        let empty = dir.path().join("cancelled");std::fs::create_dir(&empty).unwrap();
        assert!(transcribe(&source,&empty,"http://127.0.0.1:1",None,3.0,&cancelled).await.unwrap_err().to_string().contains("取消"));
        assert!(!empty.join("diarization-upload.mp3").exists());
    }
}
