//! Independent job ownership, bounded cloud concurrency and serialized native models.
use serde::Serialize;
use std::sync::{Arc, Mutex};
use once_cell::sync::Lazy;
use std::collections::BTreeMap;
use tokio::sync::{Semaphore, OwnedSemaphorePermit};
use tokio_util::sync::CancellationToken;

static JOBS: Lazy<Mutex<BTreeMap<String, Arc<Entry>>>> = Lazy::new(|| Mutex::new(BTreeMap::new()));
static CLOUD: Lazy<Arc<Semaphore>> = Lazy::new(|| Arc::new(Semaphore::new(3)));
static LOCAL: Lazy<Arc<Semaphore>> = Lazy::new(|| Arc::new(Semaphore::new(1)));
pub(crate) fn is_cloud(provider: &str) -> bool { matches!(provider,"openai"|"gemini"|"groq"|"openrouter"|"custom-openai") }
#[derive(Clone, Serialize)]
pub struct Snapshot {
    pub job_id: String, pub meeting_id: Option<String>, pub title: String,
    pub provider: String, pub model: Option<String>, pub endpoint: Option<String>, pub status: String, pub stage: String,
    pub progress_percentage: u32, pub completed: usize, pub total: usize, pub message: String,
    pub created_at: i64,
}
fn active(s: &str) -> bool { matches!(s,"queued"|"running"|"cancelling") }
struct Entry { row: Mutex<Snapshot>, cancel: CancellationToken }
pub(crate) struct Task { entry: Arc<Entry> }
pub(crate) struct Slot { _permit: OwnedSemaphorePermit, _lease: Option<super::batch_lease::BatchLease> }
impl Task {
    pub(crate) fn register(meeting: Option<String>, title: String, provider: String, model: Option<String>, request: Option<String>) -> Result<Self,String> {
        let id=request.unwrap_or_else(||uuid::Uuid::new_v4().to_string());
        if uuid::Uuid::parse_str(&id).is_err(){return Err("工作識別碼無效".into());}
        let mut jobs=JOBS.lock().unwrap_or_else(|e|e.into_inner());
        if jobs.contains_key(&id){return Err("此工作已提交，請勿重複開始".into());}
        let busy=jobs.values().filter(|e|active(&e.row.lock().unwrap_or_else(|e|e.into_inner()).status)).count();
        if busy>=20{return Err("已有 20 筆處理中工作，請完成或取消部分工作".into());}
        if meeting.is_some() && jobs.values().any(|e|{let r=e.row.lock().unwrap_or_else(|e|e.into_inner());r.meeting_id==meeting&&active(&r.status)}) {
            return Err("這筆會議已在工作清單中，請查看進度或取消後再重試".into());
        }
        // Retain recent terminal results; durable meeting progress remains in SQLite.
        if jobs.len()>=60 {
            let remove=jobs.iter().filter_map(|(id,e)|{let r=e.row.lock().unwrap_or_else(|e|e.into_inner());(!active(&r.status)).then_some((r.created_at,id.clone()))}).min().map(|(_,id)|id);
            if let Some(id)=remove{jobs.remove(&id);}
        }
        let entry=Arc::new(Entry{row:Mutex::new(Snapshot{job_id:id.clone(),meeting_id:meeting,title,provider,model,endpoint:None,status:"queued".into(),stage:"queued".into(),progress_percentage:0,completed:0,total:0,message:"等待可用轉錄工作槽…".into(),created_at:chrono::Utc::now().timestamp_millis()}),cancel:CancellationToken::new()});
        jobs.insert(id,entry.clone()); Ok(Self{entry})
    }
    pub(crate) fn snapshot(&self)->Snapshot{self.entry.row.lock().unwrap_or_else(|e|e.into_inner()).clone()}
    pub(crate) fn meeting(&self,id:&str){self.entry.row.lock().unwrap_or_else(|e|e.into_inner()).meeting_id=Some(id.into());}
    pub(crate) fn destination(&self,endpoint:Option<String>){self.entry.row.lock().unwrap_or_else(|e|e.into_inner()).endpoint=endpoint;}
    pub(crate) fn cancellation_token(&self)->CancellationToken{self.entry.cancel.clone()}
    pub(crate) fn cancelled(&self)->bool{self.entry.cancel.is_cancelled()}
    pub(crate) fn check(&self)->Result<(),String>{if self.cancelled(){Err("已取消；原音及已保存分段仍保留".into())}else{Ok(())}}
    pub(crate) fn progress(&self,stage:&str,percent:u32,message:&str){let mut r=self.entry.row.lock().unwrap_or_else(|e|e.into_inner());r.stage=stage.into();r.progress_percentage=percent.min(100);if !self.cancelled(){r.message=message.into();}}
    pub(crate) fn chunks(&self,completed:usize,total:usize){let mut r=self.entry.row.lock().unwrap_or_else(|e|e.into_inner());r.completed=completed;r.total=total;}
    pub(crate) async fn slot(&self)->Result<Slot,String>{
        let cloud=is_cloud(&self.snapshot().provider);
        let semaphore=if cloud{CLOUD.clone()}else{LOCAL.clone()};
        let permit=tokio::select!{ biased; _=self.entry.cancel.cancelled()=>return Err("已取消排隊，尚未開始轉錄".into()), p=semaphore.acquire_owned()=>p.map_err(|_|"工作排程已關閉")?};
        let lease=if cloud{None}else{loop{
            self.check()?;
            if let Ok(lease)=super::batch_lease::BatchLease::acquire(){break Some(lease)}
            tokio::select!{_=self.entry.cancel.cancelled()=>return Err("已取消排隊".into()),_=tokio::time::sleep(std::time::Duration::from_millis(100))=>{}}
        }};
        self.check()?;
        self.entry.row.lock().unwrap_or_else(|e|e.into_inner()).status="running".into();
        Ok(Slot{_permit:permit,_lease:lease})
    }
    pub(crate) fn finish(&self,success:bool,error:Option<&str>){
        let mut r=self.entry.row.lock().unwrap_or_else(|e|e.into_inner());
        r.status=if success{"complete"}else if self.cancelled(){"cancelled"}else{"failed"}.into();
        r.message=if success{"逐字稿已儲存".into()}else{error.unwrap_or("工作中斷").into()};
        if success{r.progress_percentage=100;}
    }
}
impl Drop for Task {fn drop(&mut self){let mut r=self.entry.row.lock().unwrap_or_else(|e|e.into_inner());if active(&r.status){r.status=if self.cancelled(){"cancelled"}else{"failed"}.into();r.message="工作已結束；原音與已保存進度保留，可從會議接續".into();}}}
#[tauri::command]
pub fn list_transcription_tasks()->Vec<Snapshot>{let mut rows=JOBS.lock().unwrap_or_else(|e|e.into_inner()).values().map(|e|e.row.lock().unwrap_or_else(|e|e.into_inner()).clone()).collect::<Vec<_>>();rows.sort_by_key(|r|std::cmp::Reverse(r.created_at));rows}
#[tauri::command]
pub fn cancel_transcription_task(job_id:String)->Result<(),String>{
    let jobs=JOBS.lock().unwrap_or_else(|e|e.into_inner());let e=jobs.get(&job_id).ok_or("找不到此工作")?;
    let mut r=e.row.lock().unwrap_or_else(|e|e.into_inner());if !active(&r.status){return Err("工作已結束".into());}
    e.cancel.cancel();r.status="cancelling".into();r.message="取消中：保留目前分段回應與進度，不再送出下一段".into();Ok(())
}
pub(crate) fn cancel_meeting(id:&str)->Result<(),String>{let task=list_transcription_tasks().into_iter().find(|r|r.meeting_id.as_deref()==Some(id)&&active(&r.status)).ok_or("此會議沒有處理中的工作")?;cancel_transcription_task(task.job_id)}

#[derive(Serialize,sqlx::FromRow)]
pub struct LibraryRecording {
    meeting_id:String,title:String,created_at:String,folder_path:Option<String>,
    stage:Option<String>,provider:Option<String>,model:Option<String>,completed_count:i64,error:Option<String>,
}
#[tauri::command]
pub async fn list_recording_library(state:tauri::State<'_,crate::state::AppState>)->Result<Vec<LibraryRecording>,String>{
    library_rows(state.db_manager.pool()).await
}
async fn library_rows(pool:&sqlx::SqlitePool)->Result<Vec<LibraryRecording>,String>{
    sqlx::query_as::<_,LibraryRecording>("SELECT m.id AS meeting_id,m.title,m.created_at,m.folder_path,j.stage,j.provider,j.model,CASE WHEN json_valid(j.completed_chunks) THEN json_array_length(j.completed_chunks) ELSE 0 END AS completed_count,j.error FROM meetings m LEFT JOIN audio_jobs j ON j.meeting_id=m.id ORDER BY m.created_at DESC")
        .fetch_all(pool).await.map_err(|_|"無法讀取錄音清單，請重新整理；原音未變更".into())
}

#[cfg(test)] mod tests {
    use super::*;
    #[tokio::test] async fn library_includes_old_recordings_and_handles_invalid_progress(){
        let pool=sqlx::sqlite::SqlitePoolOptions::new().max_connections(1).connect("sqlite::memory:").await.unwrap();
        sqlx::query("CREATE TABLE meetings(id TEXT PRIMARY KEY,title TEXT,created_at TEXT,folder_path TEXT)").execute(&pool).await.unwrap();
        sqlx::query("CREATE TABLE audio_jobs(meeting_id TEXT,stage TEXT,provider TEXT,model TEXT,completed_chunks TEXT,error TEXT)").execute(&pool).await.unwrap();
        sqlx::query("INSERT INTO meetings VALUES('old','舊錄音','2026-10-01','fixture'),('cancel','取消','2026-10-02','fixture'),('bad','損壞進度','2026-10-03','fixture')").execute(&pool).await.unwrap();
        sqlx::query("INSERT INTO audio_jobs VALUES('cancel','cancelled','openai','mini','[[\"saved\",0,100]]',NULL),('bad','failed','whisper','small','invalid',NULL)").execute(&pool).await.unwrap();
        let rows=library_rows(&pool).await.unwrap();assert_eq!(rows.len(),3);assert_eq!(rows[0].completed_count,0);assert_eq!(rows[1].completed_count,1);assert_eq!(rows[1].stage.as_deref(),Some("cancelled"));assert_eq!(rows[2].stage,None);
    }
    #[tokio::test] async fn concurrent_cloud_queue_cancel_and_meeting_ownership(){
        let meeting=uuid::Uuid::new_v4().to_string();
        let a=Task::register(Some(meeting.clone()),"a".into(),"openai".into(),None,None).unwrap();
        assert!(Task::register(Some(meeting),"duplicate".into(),"whisper".into(),None,None).is_err());
        let b=Task::register(None,"b".into(),"openai".into(),None,None).unwrap();
        let c=Task::register(None,"c".into(),"openai".into(),None,None).unwrap();
        let d=Task::register(None,"d".into(),"gemini".into(),None,None).unwrap();
        let sa=a.slot().await.unwrap();let sb=b.slot().await.unwrap();let sc=c.slot().await.unwrap();
        assert!(tokio::time::timeout(std::time::Duration::from_millis(30),d.slot()).await.is_err());
        cancel_transcription_task(d.snapshot().job_id).unwrap();assert!(d.slot().await.is_err());
        assert!(!a.cancelled()&&!b.cancelled()&&!c.cancelled());
        let l=Task::register(None,"local".into(),"whisper".into(),None,None).unwrap();let sl=l.slot().await.unwrap();
        let l2=Task::register(None,"local2".into(),"parakeet".into(),None,None).unwrap();
        assert!(tokio::time::timeout(std::time::Duration::from_millis(30),l2.slot()).await.is_err());
        drop(sl);assert!(l2.slot().await.is_ok());
        a.chunks(2,9);a.progress("uploading",40,"a only");assert_eq!(a.snapshot().completed,2);assert_eq!(b.snapshot().completed,0);
        a.finish(true,None);assert_eq!(a.snapshot().status,"complete");
        drop((sa,sb,sc));
    }
}
