//! Durable, content-free recording diagnostics and non-destructive finalization.
use anyhow::{anyhow, Context, Result};
use serde_json::json;
use std::{fs::{self, OpenOptions}, io::Write, path::{Path, PathBuf}, process::Stdio, time::Duration};
use tokio::io::AsyncReadExt;

pub fn atomic_json(path: &Path, value: &serde_json::Value) -> Result<()> {
    let folder=path.parent().ok_or_else(||anyhow!("找不到保存資料夾"))?;
    let mut tmp=tempfile::Builder::new().prefix(".state-").tempfile_in(folder)?;
    serde_json::to_writer_pretty(&mut tmp,value)?;
    tmp.as_file().sync_all()?;
    tmp.persist(path).map_err(|_|anyhow!("無法提交狀態檔，先前檔案保持不變"))?;
    Ok(())
}

pub fn checked_recording_folder(folder:&str)->Result<PathBuf,String>{
    let root=super::recording_preferences::get_default_recordings_folder().canonicalize().map_err(|_|"找不到錄音資料夾")?;
    let path=PathBuf::from(folder).canonicalize().map_err(|_|"找不到此場錄音資料夾")?;
    if path==root || !path.starts_with(root) {return Err("只能處理錄音存放位置內的會議資料夾".into());}
    Ok(path)
}

// FFmpeg's concat demuxer treats a Windows verbatim prefix (\\?\) as a URL
// base and resolves relative chunk names incorrectly. Keep canonical paths for
// containment checks; adapt only the argument passed to the external tool.
fn concat_list_argument(path: &Path) -> std::ffi::OsString {
    #[cfg(windows)]
    {
        let text=path.to_string_lossy();
        if let Some(unc)=text.strip_prefix(r"\\?\UNC\") {
            return format!("//{}",unc.replace('\\',"/")).into();
        }
        return text.strip_prefix(r"\\?\").unwrap_or(&text).replace('\\',"/").into();
    }
    #[cfg(not(windows))]
    path.as_os_str().to_owned()
}

pub fn event(folder: &Path, stage: &str, code: &str, count: u64) -> Result<()> {
    // Callers pass fixed identifiers only; never serialize errors, paths, audio or transcripts.
    let record = json!({"at":chrono::Utc::now().to_rfc3339(),"version":env!("CARGO_PKG_VERSION"),
        "pid":std::process::id(),"stage":stage,"code":code,"count":count});
    let path=folder.join("recording-diagnostics.jsonl");
    if fs::metadata(&path).map(|m|m.len()>4*1024*1024).unwrap_or(false) {
        let previous=folder.join("recording-diagnostics.previous.jsonl");
        if previous.exists(){fs::remove_file(&previous)?;}
        fs::rename(&path,previous)?;
    }
    let mut f = OpenOptions::new().create(true).append(true).open(path)?;
    writeln!(f, "{}", record)?;
    f.sync_data()?;
    Ok(())
}

pub fn install_panic_diagnostics() {
    std::panic::set_hook(Box::new(|info| {
        let folder = diagnostics_folder();
        if fs::create_dir_all(&folder).is_ok() {
            // Panic payload/backtrace may contain secrets. Record only the source line.
            let _ = event(&folder, "panic", "rust_panic", info.location().map(|p|p.line() as u64).unwrap_or(0));
        }
        // Do not forward to the default hook: panic payloads/backtraces can
        // contain credentials or transcript text, even when our JSON is safe.
        eprintln!("程式工作發生錯誤，內容已隱藏；請查看本機診斷紀錄。");
    }));
    let folder = diagnostics_folder();
    if fs::create_dir_all(&folder).is_ok() { let _ = event(&folder,"startup","application_started",0); }
}

fn diagnostics_folder() -> PathBuf {
    // Keep application diagnostics beside the recording collection so the
    // same user-visible location is used for backup and incident recovery.
    super::recording_preferences::get_default_recordings_folder().join(".diagnostics")
}

pub async fn ffmpeg(args: &[std::ffi::OsString], limit: Duration, folder: &Path, stage: &str) -> Result<()> {
    let exe = super::ffmpeg::find_ffmpeg_path().ok_or_else(||anyhow!("找不到 FFmpeg；原始分段已保留"))?;
    run_process(&exe, args, limit, folder, stage).await
}

async fn run_process(exe: &Path, args: &[std::ffi::OsString], limit: Duration, folder: &Path, stage: &str) -> Result<()> {
    let _=event(folder,stage,"started",0);
    let mut cmd = tokio::process::Command::new(exe);
    cmd.args(args).stdin(Stdio::null()).stdout(Stdio::null()).stderr(Stdio::piped()).kill_on_drop(true);
    #[cfg(windows)] cmd.creation_flags(0x08000000);
    let mut child = cmd.spawn().context("無法啟動音訊處理；原始分段已保留")?;
    let mut stderr = child.stderr.take().ok_or_else(||anyhow!("無法讀取處理狀態"))?;
    // Drain continuously, in bounded memory. Do not persist stderr containing private paths.
    let drain = tokio::spawn(async move {
        let mut bytes = [0u8;4096]; let mut count=0u64;let mut warnings=0u64;let mut pending=Vec::new();
        loop {
            let n=stderr.read(&mut bytes).await?; if n==0 {break;} count+=n as u64;
            pending.extend_from_slice(&bytes[..n]);
            while let Some(end)=pending.iter().position(|b|*b==b'\n') {
                if pending[..end].windows(b"Non-monotonic DTS".len()).any(|w|w==b"Non-monotonic DTS"){warnings+=1;}
                pending.drain(..=end);
            }
            if pending.len()>8192 {pending.drain(..pending.len()-512);}
        }
        Ok::<(u64,u64),std::io::Error>((count,warnings))
    });
    let result = tokio::time::timeout(limit,child.wait()).await;
    match result {
        Err(_) => {
            let _=child.kill().await; let _=child.wait().await;
            drain.abort();
            let _=event(folder,stage,"timeout",0);
            Err(anyhow!("音訊處理逾時；原始分段已保留，可稍後復原"))
        }
        Ok(status) => {
            let status=status?;
            let (stderr_bytes,warnings)=tokio::time::timeout(Duration::from_secs(5),drain).await
                .ok().and_then(|r|r.ok()).and_then(|r|r.ok()).unwrap_or((0,0));
            if warnings>0 {let _=event(folder,stage,"timestamp_warnings",warnings);}
            let _=event(folder,stage,if status.success(){"succeeded"}else{"failed"},stderr_bytes);
            if status.success(){Ok(())}else{Err(anyhow!("音訊處理失敗（退出碼 {:?}）；原始音檔與分段已保留",status.code()))}
        }
    }
}

pub async fn validate_audio(path: &Path, folder: &Path) -> Result<()> {
    let args: Vec<std::ffi::OsString> = ["-hide_banner","-loglevel","error","-nostdin","-xerror","-i"].iter().map(|s|std::ffi::OsString::from(*s))
        .chain(std::iter::once(path.as_os_str().to_owned()))
        .chain(["-map","0:a:0","-f","null","-"].iter().map(|s|std::ffi::OsString::from(*s))).collect();
    if fs::metadata(path)?.len()==0 {return Err(anyhow!("音檔為空；請保留分段復原"));}
    ffmpeg(&args,Duration::from_secs(1200),folder,"validate_audio").await
}

/// Build and verify a candidate, then publish without overwriting any existing original.
pub async fn merge(folder: &Path, checkpoints: &[PathBuf]) -> Result<PathBuf> {
    if checkpoints.is_empty(){return Err(anyhow!("No audio checkpoints to merge"));}
    let dir=folder.join(".checkpoints");
    let list=tempfile::Builder::new().prefix("concat-").suffix(".txt").tempfile_in(&dir)?;
    let mut text=String::new();
    for (i,path) in checkpoints.iter().enumerate(){
        let expected=format!("audio_chunk_{:03}.mp4",i);
        if path.file_name().and_then(|s|s.to_str())!=Some(expected.as_str()) || fs::metadata(path)?.len()==0 {
            return Err(anyhow!("錄音分段缺漏或損壞；未改動原音"));
        }
        text.push_str(&format!("file '{}'\n",expected));
    }
    fs::write(list.path(),text)?;
    let candidate=tempfile::Builder::new().prefix(".audio-").suffix(".mp4").tempfile_in(folder)?;
    let args: Vec<std::ffi::OsString>=["-hide_banner","-loglevel","warning","-nostdin","-f","concat","-safe","0","-i"].iter().map(|s|std::ffi::OsString::from(*s))
        .chain(std::iter::once(concat_list_argument(list.path())))
        .chain(["-c","copy","-y"].iter().map(|s|std::ffi::OsString::from(*s)))
        .chain(std::iter::once(candidate.path().as_os_str().to_owned())).collect();
    ffmpeg(&args,Duration::from_secs(900),folder,"merge_checkpoints").await?;
    validate_audio(candidate.path(),folder).await?;
    candidate.as_file().sync_all()?;
    let output=if folder.join("audio.mp4").exists(){folder.join(format!("audio-recovered-{}.mp4",uuid::Uuid::new_v4()))}else{folder.join("audio.mp4")};
    candidate.persist_noclobber(&output).map_err(|_|anyhow!("無法提交音檔；原音與分段已保留，請檢查空間及權限"))?;
    let _=event(folder,"audio_saved","verified_and_published",checkpoints.len() as u64);
    // Deliberately retain checkpoints. Cleanup must never be on the critical stop path.
    Ok(output)
}

#[derive(serde::Serialize)]
pub struct InterruptedRecording { folder:String, name:String, status:String, chunks:usize }

#[tauri::command]
pub async fn list_interrupted_recordings() -> Result<Vec<InterruptedRecording>,String> {
    if super::recording_commands::is_recording().await {return Ok(vec![]);}
    let base=super::recording_preferences::get_default_recordings_folder();
    if !base.exists(){return Ok(vec![]);}
    let mut rows=Vec::new();
    for entry in fs::read_dir(base).map_err(|_|"無法檢查錄音資料夾")? {
        let entry=match entry{Ok(e)=>e,Err(_)=>continue};
        if !entry.file_type().map(|t|t.is_dir()&&!t.is_symlink()).unwrap_or(false){continue;}
        let folder=entry.path();
        let data=fs::read(folder.join("metadata.json")).ok().and_then(|b|serde_json::from_slice::<serde_json::Value>(&b).ok());
        let chunks=fs::read_dir(folder.join(".checkpoints")).map(|r|r.filter_map(|e|e.ok()).filter(|e|e.file_name().to_string_lossy().starts_with("audio_chunk_")).count()).unwrap_or(0);
        if let Some(data)=data {
            let status=data["status"].as_str().unwrap_or("");
            if matches!(status,"recording"|"finalizing"|"save_failed"|"audio_saved") && data["meeting_id"].as_str().is_none() {
                rows.push(InterruptedRecording{folder:folder.to_string_lossy().into(),name:data["meeting_name"].as_str().unwrap_or("未命名錄音").into(),status:status.into(),chunks});
            }
        } else if chunks>0 || folder.join("audio.mp4").is_file() {
            rows.push(InterruptedRecording{folder:folder.to_string_lossy().into(),name:"保留錄音（狀態檔無法讀取）".into(),status:"unknown".into(),chunks});
        }
    }
    Ok(rows)
}

#[tauri::command]
pub async fn register_recording_folder(folder:String, meeting_id:String)->Result<(),String>{
    let path=checked_recording_folder(&folder)?.join("metadata.json");
    let mut data:serde_json::Value=serde_json::from_slice(&fs::read(&path).map_err(|_|"無法讀取錄音狀態")?).map_err(|_|"錄音狀態格式錯誤")?;
    if !data.is_object() || meeting_id.trim().is_empty(){return Err("錄音狀態或會議識別碼不正確，未修改原檔".into());}
    if let Some(existing)=data["meeting_id"].as_str(){if existing!=meeting_id{return Err("錄音已連結其他會議，未覆寫".into());}}
    data["meeting_id"]=json!(meeting_id);
    atomic_json(&path,&data).map_err(|_|"會議已保存，但錄音連結狀態未寫入".into())
}

#[tauri::command]
pub async fn open_recording_diagnostics()->Result<(),String>{
    let folder=diagnostics_folder();
    fs::create_dir_all(&folder).map_err(|_|"無法建立診斷資料夾")?;
    #[cfg(windows)] let mut command=std::process::Command::new("explorer.exe");
    #[cfg(target_os="macos")] let mut command=std::process::Command::new("open");
    #[cfg(all(not(windows),not(target_os="macos")))] let mut command=std::process::Command::new("xdg-open");
    command.arg(folder).spawn().map_err(|_|"無法開啟診斷資料夾")?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[cfg(windows)]
    #[tokio::test] async fn canonical_windows_folder_recovers_relative_chunks() {
        let temp=tempfile::tempdir().unwrap();
        let folder=temp.path().canonicalize().unwrap().join("中文復原");
        fs::create_dir_all(folder.join(".checkpoints")).unwrap();
        let checkpoint=folder.join(".checkpoints/audio_chunk_000.mp4");
        let args:Vec<std::ffi::OsString>=["-hide_banner","-loglevel","error","-f","lavfi","-i","sine=frequency=440:duration=1","-c:a","aac","-y"]
            .iter().map(|s|(*s).into()).chain(std::iter::once(checkpoint.as_os_str().to_owned())).collect();
        ffmpeg(&args,Duration::from_secs(30),&folder,"fixture").await.unwrap();
        let original=fs::read(&checkpoint).unwrap();
        let recovered=merge(&folder,&[checkpoint.clone()]).await.unwrap();
        assert!(recovered.is_file());
        assert_eq!(fs::read(checkpoint).unwrap(),original);
    }
    #[cfg(windows)]
    #[test] fn concat_windows_path_formats() {
        assert_eq!(concat_list_argument(Path::new(r"\\?\C:\錄音\list.txt")),std::ffi::OsString::from("C:/錄音/list.txt"));
        assert_eq!(concat_list_argument(Path::new(r"\\?\UNC\server\share\list.txt")),std::ffi::OsString::from("//server/share/list.txt"));
    }
    #[test] fn diagnostics_contains_no_content(){
        let d=tempfile::tempdir().unwrap();event(d.path(),"save","io_error",12).unwrap();
        let text=fs::read_to_string(d.path().join("recording-diagnostics.jsonl")).unwrap();
        let value:serde_json::Value=serde_json::from_str(text.trim()).unwrap();
        assert_eq!(value.as_object().unwrap().len(),6);
        assert_eq!(value["code"],"io_error");
    }
    #[tokio::test] async fn missing_chunk_preserves_existing_audio(){
        let d=tempfile::tempdir().unwrap();fs::create_dir(d.path().join(".checkpoints")).unwrap();
        fs::write(d.path().join("audio.mp4"),b"original").unwrap();
        assert!(merge(d.path(),&[d.path().join(".checkpoints/audio_chunk_001.mp4")]).await.is_err());
        assert_eq!(fs::read(d.path().join("audio.mp4")).unwrap(),b"original");
    }
    #[tokio::test] async fn corrupt_checkpoint_is_reported_without_overwriting_original(){
        let d=tempfile::tempdir().unwrap();fs::create_dir(d.path().join(".checkpoints")).unwrap();
        let checkpoint=d.path().join(".checkpoints/audio_chunk_000.mp4");
        fs::write(&checkpoint,b"incomplete AAC").unwrap();fs::write(d.path().join("audio.mp4"),b"original").unwrap();
        assert!(merge(d.path(),&[checkpoint.clone()]).await.is_err());
        assert_eq!(fs::read(d.path().join("audio.mp4")).unwrap(),b"original");
        assert_eq!(fs::read(checkpoint).unwrap(),b"incomplete AAC");
    }
    #[cfg(windows)]
    #[tokio::test] async fn timeout_terminates_child(){
        let d=tempfile::tempdir().unwrap();
        let args=["-NoProfile","-NonInteractive","-Command","Start-Sleep -Seconds 60"].map(Into::into);
        let result=run_process(Path::new("C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe"),&args,Duration::from_millis(100),d.path(),"timeout_test").await;
        assert!(result.unwrap_err().to_string().contains("逾時"));
    }
}
