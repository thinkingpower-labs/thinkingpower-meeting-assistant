use std::sync::{Arc, Mutex};
use tokio::sync::Mutex as AsyncMutex;
use anyhow::Result;
use log::{info, warn, error};
use tauri::{AppHandle, Runtime, Emitter};
use tokio::sync::mpsc;
use serde::{Serialize, Deserialize};
use std::path::PathBuf;

use super::recording_state::AudioChunk;
use super::audio_processing::create_meeting_folder;
use super::incremental_saver::IncrementalAudioSaver;

/// Structured transcript segment for JSON export
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TranscriptSegment {
    pub id: String,
    pub text: String,
    pub audio_start_time: f64, // Seconds from recording start
    pub audio_end_time: f64,   // Seconds from recording start
    pub duration: f64,          // Segment duration in seconds
    pub display_time: String,   // Formatted time for display like "[02:15]"
    pub confidence: f32,
    pub sequence_id: u64,
}

/// Meeting metadata structure
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MeetingMetadata {
    pub version: String,
    pub meeting_id: Option<String>,
    pub meeting_name: Option<String>,
    pub created_at: String,
    pub completed_at: Option<String>,
    pub duration_seconds: Option<f64>,
    pub devices: DeviceInfo,
    pub audio_file: String,
    pub transcript_file: String,
    pub sample_rate: u32,
    pub status: String,  // "recording", "completed", "error"
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DeviceInfo {
    pub microphone: Option<String>,
    pub system_audio: Option<String>,
}

/// New recording saver using incremental saving strategy
pub struct RecordingSaver {
    incremental_saver: Option<Arc<AsyncMutex<IncrementalAudioSaver>>>,
    meeting_folder: Option<PathBuf>,
    meeting_name: Option<String>,
    metadata: Option<MeetingMetadata>,
    transcript_segments: Arc<Mutex<Vec<TranscriptSegment>>>,
    is_saving: Arc<Mutex<bool>>,
    accumulation_task: Option<tokio::task::JoinHandle<Result<()>>>,
}

impl RecordingSaver {
    pub fn new() -> Self {
        Self {
            incremental_saver: None,
            meeting_folder: None,
            meeting_name: None,
            metadata: None,
            transcript_segments: Arc::new(Mutex::new(Vec::new())),
            is_saving: Arc::new(Mutex::new(false)),
            accumulation_task: None,
        }
    }

    /// Set the meeting name for this recording session
    pub fn set_meeting_name(&mut self, name: Option<String>) {
        self.meeting_name = name;
    }

    /// Set device information in metadata
    pub fn set_device_info(&mut self, mic_name: Option<String>, sys_name: Option<String>) {
        if let Some(ref mut metadata) = self.metadata {
            metadata.devices.microphone = mic_name;
            metadata.devices.system_audio = sys_name;

            // Write updated metadata to disk if folder exists
            if let Some(folder) = &self.meeting_folder {
                let metadata_clone = metadata.clone();
                if let Err(e) = self.write_metadata(folder, &metadata_clone) {
                    warn!("Failed to update metadata with device info: {}", e);
                }
            }
        }
    }

    /// Add or update a structured transcript segment (upserts based on sequence_id)
    /// Also saves incrementally to disk
    pub fn add_transcript_segment(&self, segment: TranscriptSegment) {
        if let Ok(mut segments) = self.transcript_segments.lock() {
            // Check if segment with same sequence_id exists (update it)
            if let Some(existing) = segments.iter_mut().find(|s| s.sequence_id == segment.sequence_id) {
                *existing = segment.clone();
                info!("Updated transcript segment {} (seq: {}) - total segments: {}",
                      segment.id, segment.sequence_id, segments.len());
            } else {
                // New segment, add it
                segments.push(segment.clone());
                info!("Added new transcript segment {} (seq: {}) - total segments: {}",
                      segment.id, segment.sequence_id, segments.len());
            }
        } else {
            error!("Failed to lock transcript segments for adding segment {}", segment.id);
        }

        // NEW: Save incrementally to disk
        if let Some(folder) = &self.meeting_folder {
            if let Err(e) = self.write_transcripts_json(folder) {
                warn!("Failed to write incremental transcript update: {}", e);
            }
        }
    }

    /// Legacy method for backward compatibility - converts text to basic segment
    pub fn add_transcript_chunk(&self, text: String) {
        let segment = TranscriptSegment {
            id: format!("seg_{}", chrono::Utc::now().timestamp_millis()),
            text,
            audio_start_time: 0.0,
            audio_end_time: 0.0,
            duration: 0.0,
            display_time: "[00:00]".to_string(),
            confidence: 1.0,
            sequence_id: 0,
        };
        self.add_transcript_segment(segment);
    }

    /// Start accumulation with optional incremental saving
    ///
    /// # Arguments
    /// * `auto_save` - If true, creates checkpoints and enables saving. If false, audio chunks are discarded.
    pub fn start_accumulation(
        &mut self,
        auto_save: bool,
        receiver: mpsc::UnboundedReceiver<AudioChunk>,
    ) -> Result<()> {
        if !auto_save { anyhow::bail!("完整轉錄需要先保存原音"); }
        let name = self.meeting_name.clone().ok_or_else(|| anyhow::anyhow!("尚未建立錄音名稱"))?;
        self.initialize_meeting_folder(&name, true)?;

        self.start_accumulation_worker(auto_save, receiver)
    }

    fn start_accumulation_worker(&mut self, auto_save:bool, mut receiver:mpsc::UnboundedReceiver<AudioChunk>) -> Result<()> {
        // Start accumulation task

        let incremental_saver_arc = self.incremental_saver.clone();
        let save_audio = auto_save;

        self.accumulation_task = Some(tokio::spawn(async move {
            info!("Recording saver accumulation task started (save_audio: {})", save_audio);

            while let Some(chunk) = receiver.recv().await {
                // Only process audio chunks if auto_save is enabled
                if save_audio {
                    // Add chunk to incremental saver
                    if let Some(saver_arc) = &incremental_saver_arc {
                        let saver=saver_arc.clone();
                        tokio::task::spawn_blocking(move || saver.blocking_lock().add_chunk(chunk)).await??;
                    } else {
                        error!("Incremental saver not available while accumulating");
                    }
                } else {
                    // auto_save is false: discard audio chunk (no-op)
                    // Transcription already happened in the pipeline before this point
                }
            }

            info!("Recording saver accumulation task ended");
            Ok(())
        }));

        // Set saving flag
        if let Ok(mut is_saving) = self.is_saving.lock() {
            *is_saving = true;
        }
        Ok(())
    }

    /// Initialize meeting folder structure and metadata
    ///
    /// # Arguments
    /// * `meeting_name` - Name of the meeting
    /// * `create_checkpoints` - Whether to create .checkpoints/ directory and IncrementalAudioSaver
    fn initialize_meeting_folder(&mut self, meeting_name: &str, create_checkpoints: bool) -> Result<()> {
        // Load preferences to get base recordings folder
        let base_folder = super::recording_preferences::get_default_recordings_folder();

        // Create meeting folder structure (with or without .checkpoints/ subdirectory)
        let meeting_folder = create_meeting_folder(&base_folder, meeting_name, create_checkpoints)?;

        // Only initialize incremental saver if checkpoints are needed (auto_save is true)
        if create_checkpoints {
            let incremental_saver = IncrementalAudioSaver::new(meeting_folder.clone(), 48000)?;
            self.incremental_saver = Some(Arc::new(AsyncMutex::new(incremental_saver)));
            info!("✅ Incremental audio saver initialized for meeting: {}", meeting_name);
        } else {
            info!("⚠️  Skipped incremental audio saver (auto-save disabled)");
        }

        // Create initial metadata
        let metadata = MeetingMetadata {
            version: "1.0".to_string(),
            meeting_id: None,  // Will be set by backend
            meeting_name: Some(meeting_name.to_string()),
            created_at: chrono::Utc::now().to_rfc3339(),
            completed_at: None,
            duration_seconds: None,
            devices: DeviceInfo {
                microphone: None,  // Could be enhanced to store actual device names
                system_audio: None,
            },
            audio_file: if create_checkpoints { "audio.mp4".to_string() } else { "".to_string() },
            transcript_file: "transcripts.json".to_string(),
            sample_rate: 48000,
            status: "recording".to_string(),
        };

        // Write initial metadata.json
        self.write_metadata(&meeting_folder, &metadata)?;

        self.meeting_folder = Some(meeting_folder);
        self.metadata = Some(metadata);

        Ok(())
    }

    /// Write metadata.json to disk (atomic write with temp file)
    fn write_metadata(&self, folder: &PathBuf, metadata: &MeetingMetadata) -> Result<()> {
        let metadata_path = folder.join("metadata.json");

        let json_string = serde_json::to_string_pretty(metadata)?;
        super::recording_safety::atomic_json(&metadata_path, &serde_json::from_str::<serde_json::Value>(&json_string)?)?;

        Ok(())
    }

    /// Write transcripts.json to disk (atomic write with temp file and validation)
    fn write_transcripts_json(&self, folder: &PathBuf) -> Result<()> {
        // Clone segments to avoid holding lock during I/O
        let segments_clone = if let Ok(segments) = self.transcript_segments.lock() {
            segments.clone()
        } else {
            error!("Failed to lock transcript segments for writing");
            return Err(anyhow::anyhow!("Failed to lock transcript segments"));
        };

        info!("Writing {} transcript segments to JSON", segments_clone.len());

        let transcript_path = folder.join("transcripts.json");
        let temp_path = folder.join(".transcripts.json.tmp");

        // Create JSON structure
        let json = serde_json::json!({
            "version": "1.0",
            "segments": segments_clone,
            "last_updated": chrono::Utc::now().to_rfc3339(),
            "total_segments": segments_clone.len()
        });

        // Serialize to pretty JSON string
        let json_string = serde_json::to_string_pretty(&json)
            .map_err(|e| {
                error!("Failed to serialize transcripts to JSON: {}", e);
                anyhow::anyhow!("JSON serialization failed: {}", e)
            })?;

        // Write to temp file with error handling
        std::fs::write(&temp_path, &json_string)
            .map_err(|e| {
                error!("Failed to write transcript temp file to {}: {}", temp_path.display(), e);
                anyhow::anyhow!("Failed to write temp file: {}", e)
            })?;

        // Verify temp file was written correctly
        if !temp_path.exists() {
            error!("Temp transcript file does not exist after write: {}", temp_path.display());
            return Err(anyhow::anyhow!("Temp file verification failed"));
        }

        // Atomic rename
        std::fs::rename(&temp_path, &transcript_path)
            .map_err(|e| {
                error!("Failed to rename transcript file from {} to {}: {}",
                       temp_path.display(), transcript_path.display(), e);
                anyhow::anyhow!("Failed to rename transcript file: {}", e)
            })?;

        info!("✅ Successfully wrote transcripts.json with {} segments", segments_clone.len());
        Ok(())
    }

    // in frontend/src-tauri/src/audio/recording_saver.rs
    pub fn get_stats(&self) -> (usize, u32) {
        if let Some(ref saver) = self.incremental_saver {
            if let Ok(guard) = saver.try_lock() {
                (guard.get_checkpoint_count() as usize, 48000)
            } else {
                (0, 48000)
            }
        } else {
            (0, 48000)
        }
    }

    /// Stop and save using incremental saving approach
    ///
    /// # Arguments
    /// * `app` - Tauri app handle for emitting events
    /// * `recording_duration` - Actual recording duration in seconds (from RecordingState)
    pub async fn stop_and_save<R: Runtime>(
        &mut self,
        app: &AppHandle<R>,
        recording_duration: Option<f64>
    ) -> Result<Option<String>, String> {
        let result=self.stop_and_save_files(recording_duration).await?;
        if let Some(audio)=&result {
            let save_event=serde_json::json!({"audio_file":audio,"meeting_name":self.meeting_name,
                "meeting_folder":self.meeting_folder.as_ref().map(|p|p.to_string_lossy().to_string()),
                "transcript_file":self.meeting_folder.as_ref().map(|p|p.join("transcripts.json").to_string_lossy().to_string())});
            if app.emit("recording-saved",save_event).is_err(){
                if let Some(folder)=&self.meeting_folder {let _=super::recording_safety::event(folder,"notification","event_delivery_failed",0);}
            }
        }
        Ok(result)
    }

    async fn stop_and_save_files(&mut self, recording_duration:Option<f64>)->Result<Option<String>,String>{
        info!("Stopping recording saver");

        // The pipeline sender is closed first. Join the consumer so every queued
        // audio chunk is written; a timer or flag can silently discard the tail.
        if let Some(task) = self.accumulation_task.take() {
            task.await.map_err(|e| format!("錄音儲存工作中斷：{}", e))?
                .map_err(|e| format!("錄音寫入失敗：{}", e))?;
        }
        if let Ok(mut flag) = self.is_saving.lock() { *flag = false; }

        // Check if incremental saver exists (indicates auto_save was enabled)
        let should_save_audio = self.incremental_saver.is_some();

        if !should_save_audio {
            info!("⚠️  No audio saver initialized (auto-save was disabled) - skipping audio finalization");
            info!("✅ Transcripts and metadata already saved incrementally");
            return Ok(None);
        }

        if let (Some(folder),Some(mut metadata))=(&self.meeting_folder,self.metadata.clone()) {
            metadata.status="finalizing".into();
            metadata.duration_seconds=recording_duration;
            // Metadata or diagnostics must not prevent flushing the captured tail to audio.
            let _=self.write_metadata(folder,&metadata);
            let _=super::recording_safety::event(folder,"finalizing","started",0);
        }
        // Finalize incremental saver (merge checkpoints into final audio.mp4)
        let final_audio_path = if let Some(saver_arc) = &self.incremental_saver {
            let mut saver = saver_arc.lock().await;
            match saver.finalize().await {
                Ok(path) => {
                    info!("✅ Successfully finalized audio: {}", path.display());
                    path
                }
                Err(e) => {
                    if let (Some(folder),Some(mut metadata))=(&self.meeting_folder,self.metadata.clone()) {
                        metadata.status="save_failed".into(); metadata.duration_seconds=recording_duration;
                        let _=self.write_metadata(folder,&metadata);
                        let _=super::recording_safety::event(folder,"save_failed","finalize_failed",0);
                    }
                    return Err(format!("原音尚未完成保存；分段已保留，可重新啟動後復原：{}",e));
                }
            }
        } else {
            error!("No incremental saver initialized - cannot save recording");
            return Err("No incremental saver initialized".to_string());
        };

        // Commit verified original audio BEFORE optional transcript serialization.
        if let (Some(folder),Some(mut metadata))=(&self.meeting_folder,self.metadata.clone()) {
            metadata.status="audio_saved".into();
            metadata.audio_file=final_audio_path.file_name().unwrap_or_default().to_string_lossy().into();
            metadata.duration_seconds=recording_duration;
            metadata.completed_at=Some(chrono::Utc::now().to_rfc3339());
            self.write_metadata(folder,&metadata).map_err(|_|"音檔已保存，但狀態寫入失敗；請保留資料夾重新開啟")?;
            let _=super::recording_safety::event(folder,"audio_saved","metadata_committed",0);
        }
        // Save final transcripts.json with validation
        if let Some(folder) = &self.meeting_folder {
            if let Err(e) = self.write_transcripts_json(folder) {
                error!("❌ Failed to write final transcripts: {}", e);
                return Err(format!("Failed to save transcripts: {}", e));
            }

            // Verify transcripts were written correctly
            let transcript_path = folder.join("transcripts.json");
            if !transcript_path.exists() {
                error!("❌ Transcript file was not created at: {}", transcript_path.display());
                return Err("Transcript file verification failed".to_string());
            }
            info!("✅ Transcripts saved and verified at: {}", transcript_path.display());
        }

        // Update metadata to completed status with actual recording duration
        if let (Some(folder), Some(mut metadata)) = (&self.meeting_folder, self.metadata.clone()) {
            metadata.status = "audio_saved".to_string();
            metadata.audio_file=final_audio_path.file_name().unwrap_or_default().to_string_lossy().into();
            metadata.completed_at = Some(chrono::Utc::now().to_rfc3339());

            // Use actual recording duration from RecordingState (more accurate than transcript segments)
            // Falls back to last transcript segment if duration not provided
            metadata.duration_seconds = recording_duration.or_else(|| {
                if let Ok(segments) = self.transcript_segments.lock() {
                    segments.last().map(|seg| seg.audio_end_time)
                } else {
                    None
                }
            });

            if let Err(e) = self.write_metadata(folder, &metadata) {
                error!("❌ Failed to update metadata to completed: {}", e);
                return Err(format!("Failed to update metadata: {}", e));
            }

            info!("✅ Metadata updated with duration: {:?}s", metadata.duration_seconds);
        }

        // Clean up transcript segments
        if let Ok(mut segments) = self.transcript_segments.lock() {
            segments.clear();
        }

        Ok(Some(final_audio_path.to_string_lossy().to_string()))
    }

    /// Get the meeting folder path (for passing to backend)
    pub fn get_meeting_folder(&self) -> Option<&PathBuf> {
        self.meeting_folder.as_ref()
    }

    /// Get accumulated transcript segments (for reload sync)
    pub fn get_transcript_segments(&self) -> Vec<TranscriptSegment> {
        if let Ok(segments) = self.transcript_segments.lock() {
            segments.clone()
        } else {
            Vec::new()
        }
    }

    /// Get meeting name (for reload sync)
    pub fn get_meeting_name(&self) -> Option<String> {
        self.meeting_name.clone()
    }
}

impl Default for RecordingSaver {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod preservation_tests {
    use super::*;
    use super::super::recording_state::DeviceType;
    fn fixture(folder:&std::path::Path)->RecordingSaver{
        std::fs::create_dir_all(folder.join(".checkpoints")).unwrap();
        let mut saver=RecordingSaver::new();
        saver.meeting_folder=Some(folder.to_path_buf());saver.meeting_name=Some("合成錄音保存驗收".into());
        saver.incremental_saver=Some(Arc::new(AsyncMutex::new(IncrementalAudioSaver::new(folder.to_path_buf(),48000).unwrap())));
        saver.metadata=Some(MeetingMetadata{version:"1.0".into(),meeting_id:None,meeting_name:saver.meeting_name.clone(),
            created_at:chrono::Utc::now().to_rfc3339(),completed_at:None,duration_seconds:None,
            devices:DeviceInfo{microphone:None,system_audio:None},audio_file:"audio.mp4".into(),transcript_file:"transcripts.json".into(),sample_rate:48000,status:"recording".into()});
        saver.write_metadata(&folder.to_path_buf(),saver.metadata.as_ref().unwrap()).unwrap();saver
    }
    #[tokio::test]
    #[ignore="Requires an explicitly authorized local incident audio copy"]
    async fn incident_audio_stop_save(){
        use tokio::io::AsyncReadExt;
        use sha2::{Digest,Sha256};
        let input=PathBuf::from(std::env::var("MEETILY_INCIDENT_AUDIO").expect("authorized audio path"));
        let folder=PathBuf::from(std::env::var("MEETILY_TEST_FOLDER").expect("dedicated test folder"));
        assert!(!folder.exists(),"Never overwrite a previous recording");
        let original=Sha256::digest(std::fs::read(&input).unwrap());
        let mut saver=fixture(&folder);let(tx,rx)=mpsc::unbounded_channel();saver.start_accumulation_worker(true,rx).unwrap();
        let mut command=tokio::process::Command::new(super::super::ffmpeg::find_ffmpeg_path().unwrap());
        command.args(["-v","error","-nostdin","-i"]).arg(&input).args(["-f","f32le","-ac","1","-ar","48000","pipe:1"])
            .stdin(std::process::Stdio::null()).stdout(std::process::Stdio::piped()).stderr(std::process::Stdio::null()).kill_on_drop(true);
        #[cfg(windows)] command.creation_flags(0x08000000);
        let mut decoder=command.spawn().unwrap();let mut reader=decoder.stdout.take().unwrap();
        let started=std::time::Instant::now();let mut frames=0u64;let mut index=0u64;
        loop{
            let mut raw=vec![0u8;96000];let mut filled=0;
            while filled<raw.len(){let n=tokio::time::timeout(std::time::Duration::from_secs(60),reader.read(&mut raw[filled..])).await.unwrap().unwrap();if n==0{break;}filled+=n;}
            if filled==0{break;}assert_eq!(filled%4,0);
            let data:Vec<f32>=raw[..filled].chunks_exact(4).map(|c|f32::from_le_bytes(c.try_into().unwrap())).collect();
            let timestamp=frames as f64/48000.0;frames+=data.len() as u64;
            tx.send(AudioChunk{data,sample_rate:48000,timestamp,chunk_id:index,device_type:DeviceType::Microphone}).unwrap();index+=1;
            if index%60==0 {while saver.incremental_saver.as_ref().unwrap().lock().await.get_checkpoint_count() < (index/60) as u32 {
                assert!(!saver.accumulation_task.as_ref().unwrap().is_finished(),"Saver failed while decoding source");
                tokio::time::sleep(std::time::Duration::from_millis(5)).await;
            }}
        }
        assert!(decoder.wait().await.unwrap().success());drop(tx);
        let seconds=frames as f64/48000.0;let stop_at=std::time::Instant::now();
        let audio=PathBuf::from(saver.stop_and_save_files(Some(seconds)).await.unwrap().unwrap());
        let metadata:serde_json::Value=serde_json::from_slice(&std::fs::read(folder.join("metadata.json")).unwrap()).unwrap();
        assert_eq!(metadata["status"],"audio_saved");assert_eq!(metadata["duration_seconds"],seconds);
        let checkpoints:Vec<_>=(0..(frames+1_439_999)/1_440_000).map(|i|folder.join(format!(".checkpoints/audio_chunk_{i:03}.mp4"))).collect();
        assert_eq!(checkpoints.len(),136);assert!(checkpoints.iter().all(|p|p.is_file()));
        let saved=Sha256::digest(std::fs::read(&audio).unwrap());
        let stop_seconds=stop_at.elapsed().as_secs_f64();drop(saver);
        let recovered=super::super::recording_safety::merge(&folder,&checkpoints).await.unwrap();
        assert_ne!(audio,recovered);assert_eq!(saved,Sha256::digest(std::fs::read(&audio).unwrap()));
        assert_eq!(saved,Sha256::digest(std::fs::read(&recovered).unwrap()));
        assert_eq!(original,Sha256::digest(std::fs::read(input).unwrap()));
        std::fs::write(folder.join("test-result.json"),serde_json::to_vec_pretty(&serde_json::json!({"source_seconds":seconds,"samples":frames,"checkpoints":checkpoints.len(),"wall_seconds":started.elapsed().as_secs_f64(),"stop_seconds":stop_seconds,"full_decode_validation":true,"metadata_committed":true,"restart_recovery_identical":true,"original_source_unchanged":true})).unwrap()).unwrap();
        eprintln!("Incident audio passed: {seconds:.3}s, {} checkpoints, {stop_seconds:.2}s stop, source unchanged",checkpoints.len());
    }
    #[tokio::test]
    async fn transcript_commit_failure_keeps_verified_audio_and_state(){
        let d=tempfile::tempdir().unwrap();let mut saver=fixture(d.path());
        saver.incremental_saver.as_ref().unwrap().lock().await.add_chunk(AudioChunk{data:vec![0.1;48000],sample_rate:48000,timestamp:0.0,chunk_id:0,device_type:DeviceType::Microphone}).unwrap();
        std::fs::create_dir(d.path().join("transcripts.json")).unwrap();
        assert!(saver.stop_and_save_files(Some(1.0)).await.is_err());
        assert!(d.path().join("audio.mp4").is_file());
        assert!(d.path().join(".checkpoints/audio_chunk_000.mp4").is_file());
        let data:serde_json::Value=serde_json::from_slice(&std::fs::read(d.path().join("metadata.json")).unwrap()).unwrap();
        assert_eq!(data["status"],"audio_saved");
    }
    #[tokio::test]
    async fn metadata_failure_does_not_discard_unflushed_audio(){
        let d=tempfile::tempdir().unwrap();let mut saver=fixture(d.path());
        saver.incremental_saver.as_ref().unwrap().lock().await.add_chunk(AudioChunk{data:vec![0.1;48000],sample_rate:48000,timestamp:0.0,chunk_id:0,device_type:DeviceType::Microphone}).unwrap();
        std::fs::remove_file(d.path().join("metadata.json")).unwrap();
        std::fs::create_dir(d.path().join("metadata.json")).unwrap();
        assert!(saver.stop_and_save_files(Some(1.0)).await.is_err());
        assert!(d.path().join("audio.mp4").is_file());
        assert!(d.path().join(".checkpoints/audio_chunk_000.mp4").is_file());
    }
    #[tokio::test]
    #[ignore="Explicit process-termination recovery test; takes at least 60 seconds"]
    async fn forced_process_exit_preserves_published_checkpoints(){
        use sha2::{Digest,Sha256};
        let folder=PathBuf::from(std::env::var("MEETILY_TEST_FOLDER").expect("dedicated test folder"));
        assert!(!folder.exists(),"Never overwrite a previous recording");
        let mut child=std::process::Command::new(std::env::current_exe().unwrap())
            .args(["audio::recording_saver::preservation_tests::long_recording_save_and_recover","--exact","--ignored","--nocapture"])
            .env("MEETILY_TEST_FOLDER",&folder).env("MEETILY_TEST_SECONDS","3600").env("MEETILY_TEST_REALTIME","1")
            .stdout(std::process::Stdio::null()).stderr(std::process::Stdio::null()).spawn().unwrap();
        let deadline=std::time::Instant::now()+std::time::Duration::from_secs(100);
        while !folder.join(".checkpoints/audio_chunk_001.mp4").is_file(){
            if child.try_wait().unwrap().is_some(){panic!("Recording worker exited before checkpoint commit");}
            if std::time::Instant::now()>deadline{let _=child.kill();let _=child.wait();panic!("Checkpoint commit timed out");}
            tokio::time::sleep(std::time::Duration::from_millis(100)).await;
        }
        // Kill only our isolated worker, after two durable checkpoints. The
        // uncommitted tail is intentionally outside the recovery guarantee.
        child.kill().unwrap();let status=child.wait().unwrap();assert!(!status.success());
        assert!(!folder.join("audio.mp4").exists());
        let checkpoints:Vec<_>=(0..2).map(|i|folder.join(format!(".checkpoints/audio_chunk_{i:03}.mp4"))).collect();
        let before:Vec<_>=checkpoints.iter().map(|p|Sha256::digest(std::fs::read(p).unwrap())).collect();
        let recovered=super::super::recording_safety::merge(&folder,&checkpoints).await.unwrap();
        assert!(recovered.is_file());
        for (path,hash) in checkpoints.iter().zip(before){assert_eq!(hash,Sha256::digest(std::fs::read(path).unwrap()));}
        std::fs::write(folder.join("forced-exit-result.json"),serde_json::to_vec_pretty(&serde_json::json!({"worker_force_terminated":true,"published_checkpoints":2,"checkpoints_unchanged":true,"recovered_full_decode":true,"unflushed_tail_not_guaranteed":true})).unwrap()).unwrap();
    }
    #[tokio::test]
    #[ignore="Explicit long recording fixture; consumes encoder/IO time"]
    async fn long_recording_save_and_recover(){
        let seconds=std::env::var("MEETILY_TEST_SECONDS").ok().and_then(|s|s.parse::<usize>().ok()).unwrap_or(4200);
        let folder=PathBuf::from(std::env::var("MEETILY_TEST_FOLDER").expect("dedicated test folder required"));
        assert!(!folder.exists(),"Test must never overwrite any prior recording");
        let real_time=std::env::var("MEETILY_TEST_REALTIME").as_deref()==Ok("1");
        let mut saver=fixture(&folder);let(tx,rx)=mpsc::unbounded_channel();saver.start_accumulation_worker(true,rx).unwrap();
        let start=std::time::Instant::now();
        for i in 0..seconds*2 {
            // A five-second tone at every checkpoint seam, separated by silence.
            let samples=(0..24000).map(|j|if (i/2)%30<5 {((j as f32*440.0*std::f32::consts::TAU/48000.0).sin())*0.2}else{0.0}).collect();
            tx.send(AudioChunk{data:samples,sample_rate:48000,timestamp:i as f64*0.5,chunk_id:i as u64,device_type:DeviceType::Microphone}).unwrap();
            if (i+1)%60==0 {while saver.incremental_saver.as_ref().unwrap().lock().await.get_checkpoint_count() < ((i+1)/60) as u32 {tokio::time::sleep(std::time::Duration::from_millis(5)).await;}}
            if real_time {tokio::time::sleep_until(tokio::time::Instant::from_std(start+std::time::Duration::from_millis((i as u64+1)*500))).await;}
            if i%600==0{eprintln!("recorded {} audio seconds; wall {:?}",i/2,start.elapsed());}
        }
        drop(tx);
        let stopped=std::time::Instant::now();
        let audio=PathBuf::from(saver.stop_and_save_files(Some(seconds as f64)).await.unwrap().unwrap());
        let meta:serde_json::Value=serde_json::from_slice(&std::fs::read(folder.join("metadata.json")).unwrap()).unwrap();
        assert_eq!(meta["status"],"audio_saved");assert_eq!(meta["duration_seconds"],seconds as f64);
        let cp:Vec<_>=(0..(seconds+29)/30).map(|i|folder.join(format!(".checkpoints/audio_chunk_{i:03}.mp4"))).collect();
        assert!(cp.iter().all(|p|p.is_file()));
        use sha2::{Sha256,Digest};
        let before=Sha256::digest(std::fs::read(&audio).unwrap());
        let result=std::process::Command::new(super::super::ffmpeg::find_ffmpeg_path().unwrap()).args(["-hide_banner","-nostdin","-i"]).arg(&audio)
            .args(["-af","silencedetect=noise=-30dB:d=1","-f","null","-","-progress","pipe:1","-nostats"]).output().unwrap();
        assert!(result.status.success());
        let progress=String::from_utf8_lossy(&result.stdout);
        let duration=progress.lines().filter_map(|line|line.strip_prefix("out_time_us=").and_then(|s|s.parse::<f64>().ok())).last().unwrap()/1_000_000.0;
        assert!((duration-seconds as f64).abs()<cp.len() as f64*0.05+0.1,"decoded {duration}, expected {seconds}");
        let seam_count=String::from_utf8_lossy(&result.stderr).matches("silence_start:").count();
        assert_eq!(seam_count,cp.len(),"Every checkpoint tone must survive concatenation");
        let save_seconds=stopped.elapsed().as_secs_f64();
        drop(saver); // Recovery after all in-memory saver state has gone away.
        let recovered=super::super::recording_safety::merge(&folder,&cp).await.unwrap();
        assert_ne!(audio,recovered);assert_eq!(before,Sha256::digest(std::fs::read(&audio).unwrap()));
        assert_eq!(before,Sha256::digest(std::fs::read(&recovered).unwrap()));
        std::fs::write(folder.join("test-result.json"),serde_json::to_vec_pretty(&serde_json::json!({"audio_seconds":seconds,"real_time":real_time,"wall_seconds":start.elapsed().as_secs_f64(),"save_and_decode_seconds":save_seconds,"decoded_seconds":duration,"checkpoints":cp.len(),"seam_markers":seam_count,"recovery_identical":true,"original_preserved":true})).unwrap()).unwrap();
        eprintln!("Long recording passed: {seconds}s audio, {} checkpoints, {seam_count} seam markers, {save_seconds:.2}s save/decode",cp.len());
    }
}
