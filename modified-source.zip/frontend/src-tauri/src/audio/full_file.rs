//! File imports must never discard audio based on a speech detector.
use super::{common::split_segment_at_silence, vad::SpeechSegment};

pub(crate) fn write_plan(folder: &std::path::Path, chunks: &[SpeechSegment]) -> anyhow::Result<()> {
    let report = serde_json::json!({
        "strategy": "full_file_adaptive_gain_quiet_boundaries",
        "source_modified": false,
        "note": "完整涵蓋送入辨識不代表逐字正確；無文字段落仍需對照原音。",
        "chunks": chunks.iter().map(|c| serde_json::json!({
            "start_seconds": c.start_timestamp_ms / 1000.0,
            "end_seconds": c.end_timestamp_ms / 1000.0
        })).collect::<Vec<_>>()
    });
    let path = folder.join("transcription-plan.json");
    if path.exists() {
        let prior: serde_json::Value = serde_json::from_slice(&std::fs::read(&path)?)?;
        anyhow::ensure!(prior["chunks"] == report["chunks"],
            "這筆工作的舊版音訊分段與新版不同，已停止以避免混用結果或重複計費。原音與舊結果仍保留，請另行確認重新轉錄。 ");
    }
    std::fs::write(path, serde_json::to_vec_pretty(&report)?)?;
    Ok(())
}

/// Keep the entire timeline; choose quiet boundaries near 25 seconds. Gain is
/// applied only to in-memory inference copies, never the user's source file.
pub(crate) fn prepare(samples: Vec<f32>) -> Vec<SpeechSegment> {
    if samples.is_empty() { return Vec::new(); }
    let end_timestamp_ms = samples.len() as f64 / 16.0;
    let whole = SpeechSegment { samples, start_timestamp_ms: 0.0,
        end_timestamp_ms, confidence: 0.0 };
    let mut chunks = split_segment_at_silence(&whole, 25 * 16000);
    for chunk in &mut chunks { prepare_chunk(&mut chunk.samples); }
    chunks
}

pub(crate) fn prepare_chunk(samples: &mut Vec<f32>) {
        let chunk = samples;
        let peak = chunk.iter().map(|x| x.abs()).fold(0.0_f32, f32::max);
        let rms = (chunk.iter().map(|x| (*x as f64).powi(2)).sum::<f64>()
            / chunk.len().max(1) as f64).sqrt() as f32;
        // Bounded amplification for quiet recordings. Do not amplify digital
        // silence or attenuate already loud audio; leave headroom for peaks.
        let gain = if rms > 0.0001 && peak > 0.0 {
            (0.06 / rms).min(10.0).min(0.95 / peak).max(1.0)
        } else { 1.0 };
        for sample in chunk.iter_mut() { *sample *= gain; }
        // Whisper requires a minimum frame size. Padding is not source time.
        if chunk.len() < 1600 { chunk.resize(1600, 0.0); }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    #[ignore = "requires an explicitly supplied local audio fixture"]
    fn export_audio_fidelity_fixture() {
        let input = std::path::PathBuf::from(std::env::var("TEST_AUDIO_PATH").unwrap());
        let output = std::path::PathBuf::from(std::env::var("TEST_OUTPUT_DIR").unwrap());
        std::fs::create_dir_all(&output).unwrap();
        let decoded = super::super::decoder::decode_audio_file(&input).unwrap();
        let samples = decoded.to_whisper_format();
        let write = |name: &str, data: &[f32]| {
            let bytes: Vec<u8> = data.iter().flat_map(|v| v.to_le_bytes()).collect();
            std::fs::write(output.join(name), bytes).unwrap();
        };
        write("decoded.f32", &decoded.samples);
        write("resampled.f32", &samples);
        std::fs::write(output.join("decode-info.json"), serde_json::to_vec_pretty(&serde_json::json!({
            "sample_rate": decoded.sample_rate, "channels": decoded.channels,
            "duration": decoded.duration_seconds, "resampled_samples": samples.len()
        })).unwrap()).unwrap();
        let chunks = prepare(samples);
        write_plan(&output, &chunks).unwrap();
        for (i, chunk) in chunks.iter().enumerate() {
            write(&format!("chunk-{i:05}.f32"), &chunk.samples);
            std::fs::write(output.join(format!("request-{i:05}.wav")),
                super::super::cloud_transcription::wav(&chunk.samples)).unwrap();
        }
    }
    #[test]
    fn full_file_keeps_quiet_audio_silence_and_short_tail() {
        for count in [1, 1599, 400000, 810 * 16000 + 37] {
            let chunks = prepare(vec![0.001; count]);
            assert_eq!(chunks.first().unwrap().start_timestamp_ms, 0.0);
            assert_eq!(chunks.last().unwrap().end_timestamp_ms, count as f64 / 16.0);
            for pair in chunks.windows(2) {
                assert_eq!(pair[0].end_timestamp_ms, pair[1].start_timestamp_ms);
            }
            assert!(chunks.iter().all(|c| c.samples.len() >= 1600 && c.samples.len() <= 30 * 16000));
        }
        assert!(prepare(vec![0.0; 16000])[0].samples.iter().all(|x| *x == 0.0));
        assert!(prepare(Vec::new()).is_empty());
    }
    #[tokio::test]
    #[ignore = "local model and user-authorized audio required"]
    async fn full_file_acceptance_transcription() {
        let input = std::path::PathBuf::from(std::env::var("TEST_AUDIO_PATH").unwrap());
        let output = std::path::PathBuf::from(std::env::var("TEST_OUTPUT_DIR").unwrap());
        std::fs::create_dir_all(&output).unwrap();
        let models = std::path::PathBuf::from(std::env::var("TEST_MODELS_DIR").unwrap());
        let engine = crate::whisper_engine::WhisperEngine::new_with_models_dir(Some(models)).unwrap();
        engine.discover_models().await.unwrap();
        let model = std::env::var("TEST_MODEL_NAME").unwrap_or_else(|_| "small".into());
        engine.load_model(&model).await.unwrap();
        let decoded = crate::audio::decoder::decode_audio_file(&input).unwrap();
        let chunks = prepare(decoded.to_whisper_format());
        write_plan(&output, &chunks).unwrap();
        let mut rows = Vec::new();
        for (i, chunk) in chunks.iter().enumerate() {
            let (text, _, _) = engine.transcribe_file_audio_with_confidence(chunk.samples.clone(), Some("zh".into())).await.unwrap();
            println!("Chunk {}/{} {:.2}-{:.2}s: {}", i + 1, chunks.len(), chunk.start_timestamp_ms / 1000.0, chunk.end_timestamp_ms / 1000.0, text);
            rows.push((text, chunk.start_timestamp_ms, chunk.end_timestamp_ms));
            // Checkpoint each chunk for diagnosis without writing the user's DB.
            super::super::common::write_transcripts_json(&output, &super::super::common::create_transcript_segments(&rows)).unwrap();
        }
        assert_eq!(rows.len(), chunks.len());
    }
}
