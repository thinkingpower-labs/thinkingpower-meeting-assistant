//! Localize known structural labels without rewriting facts or quotations.
use super::templates::Template;
use once_cell::sync::Lazy;
use std::collections::HashMap;

static LABELS: Lazy<HashMap<String, HashMap<String, String>>> = Lazy::new(|| {
    serde_json::from_str(include_str!("template_labels.json")).expect("valid bundled label translations")
});

fn labels(language: Option<&str>) -> Option<&'static HashMap<String, String>> {
    let code = language?.to_ascii_lowercase().replace('_', "-");
    LABELS.get(&code).or_else(|| LABELS.get(code.split('-').next()?))
}

pub(crate) fn localized_template(template: &Template, language: Option<&str>) -> Template {
    let mut result = template.clone();
    if let Some(map) = labels(language) {
        for section in &mut result.sections {
            section.title = map.get(&section.title).cloned().unwrap_or_else(|| section.title.clone());
            for format in [&mut section.item_format, &mut section.example_item_format].into_iter().flatten() {
                *format = localize_markdown(format, language);
            }
        }
    }
    result
}

/// Localize structural labels and reserved whole-cell missing-data notices.
/// Never translate factual task wording, quotations, names or numeric values.
pub(crate) fn localize_markdown(markdown: &str, language: Option<&str>) -> String {
    let Some(map) = labels(language) else { return markdown.to_string(); };
    let lines: Vec<_> = markdown.lines().collect();
    lines.iter().enumerate().map(|(index, line)| {
        let trimmed = line.trim();
        let heading = trimmed.trim_matches(|c: char| c == '#' || c == '*' || c == ':' || c.is_whitespace());
        if let Some(value) = map.get(heading) {
            return line.replacen(heading, value, 1);
        }
        let is_header = trimmed.starts_with('|') && lines.get(index + 1).is_some_and(|next| {
            let next = next.trim();
            next.contains('-') && next.chars().all(|c| "|:- \t".contains(c))
        });
        if trimmed.starts_with('|') {
            return line.split('|').map(|cell| {
                let key = cell.trim().trim_matches('*').trim();
                let reserved_notice = matches!(key, "To be confirmed" | "Not discussed" | "Not specified");
                map.get(key).filter(|_| is_header || reserved_notice).map(|value| cell.replacen(key, value, 1)).unwrap_or_else(|| cell.to_string())
            }).collect::<Vec<_>>().join("|");
        }
        line.to_string()
    }).collect::<Vec<_>>().join("\n")
}

/// Move explicitly undecided bullet items out of a decision section, retaining
/// the original text. This is category repair, never a generated factual rewrite.
pub(crate) fn separate_open_decisions(markdown: &str, template: &Template) -> String {
    let heading = |line: &str| line.trim().trim_matches(|c: char| "#*:".contains(c) || c.is_whitespace()).to_string();
    let titles: Vec<_> = template.sections.iter().map(|section| section.title.as_str()).collect();
    let decision = |name: &str| matches!(name, "決議事項" | "已確認的改善決議" | "決議與雙方承諾" | "Confirmed Decisions" | "Confirmed Improvement Decisions" | "Confirmed Decisions and Commitments");
    let open = |name: &str| matches!(name, "待確認事項" | "待確認與後續追蹤" | "疑慮與待確認事項" | "Items to Confirm" | "Open Questions and Follow-up" | "Concerns and Items to Confirm");
    let uncertain = regex::Regex::new(r"(?i)本次不決定|先不決定|尚未決定|未做決定|未決定|不做決定|延後.{0,12}(?:會議|討論)|留待.{0,12}討論|no decision|not decided|deferred for discussion").unwrap();
    let mut in_decisions = false;
    let mut moved = Vec::new();
    let mut kept = Vec::new();
    for line in markdown.lines() {
        let name = heading(line);
        if titles.contains(&name.as_str()) { in_decisions = decision(&name); }
        let bullet = line.trim_start().starts_with(['-', '*']) || line.trim_start().chars().next().is_some_and(|c| c.is_ascii_digit());
        if in_decisions && bullet && uncertain.is_match(line) { moved.push(line.to_string()); }
        else { kept.push(line.to_string()); }
    }
    if moved.is_empty() { return markdown.to_string(); }
    if let Some(index) = kept.iter().position(|line| open(&heading(line))) {
        kept.splice(index + 1..index + 1, std::iter::once(String::new()).chain(moved));
    } else {
        // A custom template with no open-question section retains its text.
        return markdown.to_string();
    }
    kept.join("\n")
}

/// A model may put every section at H1. Section labels are not meeting titles:
/// normalize them to H2 so the existing name extractor never renames a meeting
/// to "Meeting Overview" or removes that section as if it were the document title.
pub(crate) fn normalize_section_levels(markdown: &str, template: &Template) -> String {
    markdown.lines().map(|line| {
        let name = line.trim().trim_matches(|c: char| "#*:".contains(c) || c.is_whitespace());
        if template.sections.iter().any(|section| section.title == name) { format!("## {name}") }
        else { line.to_string() }
    }).collect::<Vec<_>>().join("\n")
}

/// Refuse the observed unsupported inference instead of calling it completed.
/// This is deliberately narrow; it is not a general factual-accuracy guarantee.
pub(crate) fn validate_local_conditions(markdown: &str, source: &str) -> Result<(), String> {
    let condition = regex::Regex::new(r"(?i)核准後.{0,8}(?:執行|開始|進行)|批准後.{0,8}(?:執行|開始|進行)|(?:cannot|must not).{0,30}(?:until approval|until approved)").unwrap();
    if condition.is_match(markdown) && !condition.is_match(source) {
        return Err("本機模型加入原文沒有的核准／執行條件，未將此稿標示為完成。原音與逐字稿保留，請更換模型或重新產生摘要並核對。".to_string());
    }
    Ok(())
}

pub(crate) fn validate_local_sections(markdown: &str, template: &Template, language: Option<&str>) -> Result<(), String> {
    // Known translated labels and English labels can be checked without an
    // additional model call. Other output languages remain model-generated.
    let known = labels(language).is_some() || language.is_some_and(|code| code.to_ascii_lowercase().starts_with("en"));
    if known && template.sections.iter().any(|section| !markdown.contains(&section.title)) {
        return Err("本機摘要缺少必要章節，可能未完整產生，未標示為完成。原音與逐字稿保留，請更換模型或重新產生摘要。".to_string());
    }
    Ok(())
}

pub(crate) fn finish_local_report(markdown: &str, template: &Template, language: Option<&str>, source: &str) -> Result<String, String> {
    let normalized = normalize_section_levels(markdown, template);
    let normalized = ground_unstated_labels(&normalized, source)?;
    let repaired = separate_open_decisions(&normalized, template);
    let repaired = retain_explicit_requests(&repaired, template, source);
    validate_local_conditions(&repaired, source)?;
    validate_local_sections(&repaired, template, language)?;
    Ok(repaired)
}

/// Two observed inference errors: inventing a business form from "I worked
/// alone", and assigning positive/negative standard status to a speaker's
/// method. Replace an unsupported narrative with a related EXACT source excerpt,
/// not another generated assertion. This is a narrow guard, not entailment QA.
fn ground_unstated_labels(markdown: &str, source: &str) -> Result<String, String> {
    let groups = [vec!["獨資", "合夥企業", "sole proprietorship"], vec!["標準", "規範", "established standard", "universal standard"]];
    let tokens = |text: &str| {
        let chars: Vec<_> = text.to_lowercase().chars().filter(|c| c.is_alphanumeric()).collect();
        chars.windows(2).map(|pair| pair.iter().collect::<String>()).collect::<std::collections::HashSet<_>>()
    };
    let candidates: Vec<_> = source.split_inclusive(['\n', '。', '！', '？']).map(str::trim).filter(|part| part.chars().count() >= 6 && part.chars().count() <= 500).collect();
    let mut output = Vec::new();
    for line in markdown.lines() {
        let unsupported = !line.trim_start().starts_with('#') && !line.trim_start().starts_with('|') && groups.iter().any(|group| {
            group.iter().any(|term| line.to_lowercase().contains(term)) && !group.iter().any(|term| source.to_lowercase().contains(term))
        });
        if !unsupported { output.push(line.to_string()); continue; }
        let wanted = tokens(line);
        let best = candidates.iter().map(|candidate| (*candidate, tokens(candidate).intersection(&wanted).count())).max_by_key(|(_, score)| *score);
        let Some((quote, score)) = best else { return Err("本機摘要含原文未交代的推論，請核對逐字稿或更換模型。".into()); };
        if score == 0 { return Err("本機摘要含無法由原文核對的推論，未標示為完成。".into()); }
        output.push(format!("> {quote}"));
    }
    Ok(output.join("\n"))
}

/// Recover omitted, explicitly spoken Chinese work requests as source excerpts.
/// No inference: do not assign the speaker as owner, invent a deadline or create
/// work from a suggestion/question. Other languages continue through the model.
fn retain_explicit_requests(markdown: &str, template: &Template, source: &str) -> String {
    let Some(task_section) = template.sections.iter().find(|section| matches!(section.title.as_str(), "分配的任務及負責人" | "改善任務及負責人")) else { return markdown.to_string(); };
    let mut lines: Vec<String> = markdown.lines().map(String::from).collect();
    let Some(start) = lines.iter().position(|line| line == &format!("## {}", task_section.title)) else { return markdown.to_string(); };
    let mut end = (start + 1..lines.len()).find(|index| lines[*index].starts_with("## ")).unwrap_or(lines.len());
    let mut existing = lines[start + 1..end].join("\n");
    let requests = regex::Regex::new(r"請(?:幫忙|協助)?((?:檢查|測試|整理|提供|提交|完成|製作|處理)[^。！？\n；，,]{1,40})").unwrap();
    let commitments = regex::Regex::new(r"(?:我(?:會|將)|我們(?:會|將)|我負責)([^。！？\n；，,]{2,200})").unwrap();
    let uncertain = regex::Regex::new(r"^(?:先|再|稍後)?(?:考慮|建議|希望|想|不|沒|暫不|未)").unwrap();
    let verbs = regex::Regex::new(r"^(?:檢查|測試|整理|提供|提交|完成|製作|處理)").unwrap();
    let time = regex::Regex::new(r"\[\d{1,2}:\d{2}(?::\d{2})?\]").unwrap();
    let mut rows = Vec::new();
    for source_line in source.lines() {
        let mut work_items = Vec::new();
        for capture in requests.captures_iter(source_line) {
            work_items.push((capture[1].trim().to_string(), capture[1].trim().to_string(), "原文工作要求"));
        }
        if !source_line.trim_end().ends_with(['?', '？']) {
            for capture in commitments.captures_iter(source_line) {
                let prefix = &source_line[..capture.get(0).unwrap().start()];
                if ["如果", "假如", "要是", "假設"].iter().any(|word| prefix.contains(word)) || uncertain.is_match(capture[1].trim()) { continue; }
                work_items.push((capture[0].trim().to_string(), capture[1].trim().to_string(), "原文工作承諾"));
            }
        }
        for (work, object_text, label) in work_items {
            let object = verbs.replace(&object_text, "");
            let characters: std::collections::HashSet<char> = object.chars().filter(|c| c.is_alphanumeric()).collect();
            if characters.len() < 2 { continue; }
            let covered = existing.lines().filter(|line| line.starts_with('|')).any(|line| {
                let task = line.split('|').nth(1).unwrap_or("");
                let matches = characters.iter().filter(|c| task.contains(**c)).count();
                matches * 4 >= characters.len() * 3
            });
            if covered { continue; }
            let stamp = time.find(source_line).map(|m| m.as_str()).unwrap_or("");
            let row = format!("| {} {}（{}） | 待確認 | 待確認 | 待確認 |", work.replace('|', "\\|"), stamp, label);
            existing.push('\n');
            existing.push_str(&row);
            existing.push('\n');
            rows.push(row);
        }
    }
    if rows.is_empty() { return markdown.to_string(); }
    // A completely unknown placeholder row is not an actual task. Once the
    // source supplies work, replace that row rather than keeping an empty task.
    for index in (start + 1..end).rev() {
        let cells: Vec<_> = lines[index].split('|').map(str::trim).filter(|cell| !cell.is_empty()).collect();
        if lines[index].trim_start().starts_with('|') && cells.len() == 4 && cells.iter().all(|cell| matches!(*cell, "待確認" | "待定" | "未指定" | "未提及")) {
            lines.remove(index); end -= 1;
        }
    }
    let mut insert = Vec::new();
    if !lines[start + 1..end].iter().any(|line| line.trim().starts_with('|')) {
        insert.push(String::new());
        if let Some(format) = &task_section.item_format { insert.extend(format.lines().map(String::from)); }
    }
    // Keep recovered rows adjacent to the Markdown table. A blank line here
    // would render a source request as literal pipes outside the table.
    let insertion = (start + 1..end).rev().find(|index| lines[*index].trim_start().starts_with('|')).map(|index| index + 1).unwrap_or(end);
    insert.extend(rows);
    lines.splice(insertion..insertion, insert);
    lines.join("\n")
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    #[ignore = "reads fresh synthetic local-model results from MEETILY_LOCAL_QUALITY_RESULTS"]
    fn generated_local_results_are_grounded() {
        let path = std::env::var("MEETILY_LOCAL_QUALITY_RESULTS").expect("synthetic capture file");
        let cases: Vec<serde_json::Value> = serde_json::from_str(&std::fs::read_to_string(path).unwrap()).unwrap();
        assert_eq!(cases.len(), 4);
        for case in cases {
            let id = case["id"].as_str().unwrap();
            let template = localized_template(&super::super::templates::get_template(case["template"].as_str().unwrap()).unwrap(), Some("zh-TW"));
            let raw = localize_markdown(case["response"]["text"].as_str().unwrap(), Some("zh-TW"));
            let result = finish_local_report(&raw, &template, Some("zh-TW"), case["source"].as_str().unwrap()).unwrap();
            assert!(!result.contains("Meeting Overview"));
            assert!(!result.contains("Tasks and Owners"));
            match id {
                "original-regression" => {
                    let decisions = result.split("## 決議事項").nth(1).unwrap().split("## 分配的任務及負責人").next().unwrap();
                    assert!(!decisions.contains("會員登入"));
                    let tasks = result.split("## 分配的任務及負責人").nth(1).unwrap().split("## 重要時間與預算數字").next().unwrap();
                    let animation = tasks.lines().find(|line| line.contains("小林")).unwrap();
                    assert!(animation.contains("下週五"));
                    let mobile = tasks.lines().find(|line| line.contains("手機")).unwrap();
                    assert!(mobile.matches("待確認").count() >= 2 || mobile.matches("待定").count() >= 2);
                    assert!(!tasks.contains("會員登入"));
                    assert!(!tasks.contains("測試報告"));
                    assert!(result.contains("三萬元"));
                    assert!(result.contains("尚未核准"));
                },
                "heldout-constraints" => {
                    assert!(result.contains("阿芳")); assert!(result.contains("週三"));
                    assert!(result.contains("八萬元") || result.contains("80,000") || result.contains("80000"));
                    let tasks = result.split("## 分配的任務及負責人").nth(1).unwrap().split("## 重要時間與預算數字").next().unwrap();
                    assert!(tasks.contains("匯出")); assert!(!tasks.contains("APP"));
                },
                "interview-no-assignments" => {
                    assert!(result.contains("小何")); assert!(result.contains("五萬元"));
                    assert!(!result.contains("## 分配的任務及負責人"));
                    assert!(!result.contains("未先行購置"));
                    assert!(!result.contains("僅適用"));
                    assert!(!result.contains("獨資"));
                },
                "lecture-no-homework" => {
                    assert!(result.contains("三步檢查法"));
                    assert!(result.contains("沒有作業") || result.contains("未指定作業") || result.contains("無作業"));
                    assert!(!result.contains("標準流程"));
                    assert!(!result.contains("標準"));
                },
                other => panic!("unexpected fixture {other}"),
            }
            println!("verified synthetic local-model output: {id}");
        }
    }
    #[test]
    fn labels_change_but_quotes_names_and_task_values_do_not() {
        let input = "**Meeting Overview**\nQuote: Meeting Overview, OpenAI costs USD 30.\n| Task | Owner | Deadline |\n| --- | --- | --- |\n| Owner | Lin | next Friday |";
        let output = localize_markdown(input, Some("zh-TW"));
        assert!(output.starts_with("**會議摘要**"));
        assert!(output.contains("Quote: Meeting Overview, OpenAI costs USD 30."));
        assert!(output.contains("| 任務 | 負責人 | 完成期限 |"));
        assert!(output.contains("| Owner | Lin | next Friday |"));
        assert_eq!(localize_markdown(input, Some("en")), input);
    }
    #[test]
    fn five_templates_have_translated_headings_and_table_hints() {
        for id in super::super::templates::list_template_ids() {
            let template = super::super::templates::get_template(&id).unwrap();
            let localized = localized_template(&template, Some("zh-TW"));
            for (original, translated) in template.sections.iter().zip(&localized.sections) {
                assert_ne!(original.title, translated.title, "missing title: {}", original.title);
            }
            assert!(!localized.to_section_instructions().contains("| Owner |"));
        }
    }
    #[test]
    fn undecided_proposal_is_relocated_without_turning_into_an_assigned_task() {
        let template = localized_template(&super::super::templates::get_template("standard_meeting").unwrap(), Some("zh-TW"));
        let input = "**決議事項**\n- 小林負責動畫，下週五交付。\n- 會員登入本次不決定，延後討論。\n**分配的任務及負責人**\n動畫：小林。\n**待確認事項**\n- 手機測試期限。";
        let repaired = separate_open_decisions(input, &template);
        let decisions = repaired.split("**分配的任務及負責人**").next().unwrap();
        assert!(decisions.contains("小林負責動畫"));
        assert!(!decisions.contains("會員登入"));
        assert!(repaired.split("**待確認事項**").nth(1).unwrap().contains("會員登入本次不決定"));
        assert!(validate_local_conditions("需等主管核准後才能執行", "預算尚未核准").is_err());
        assert!(validate_local_conditions("預算尚未核准", "預算尚未核准").is_ok());
        assert!(validate_local_sections("**會議摘要**\n內容", &template, Some("zh-TW")).is_err());
        let normalized = normalize_section_levels("# 會議摘要\n網站更新\n# 決議事項\n下週交付", &template);
        assert!(normalized.starts_with("## 會議摘要"));
        assert!(super::super::processor::extract_meeting_name_from_markdown(&normalized).is_none());
    }
    #[test]
    fn omitted_source_request_is_retained_without_assigning_speaker_or_inventing_details() {
        let template = localized_template(&super::super::templates::get_template("standard_meeting").unwrap(), Some("zh-TW"));
        let draft = "## 分配的任務及負責人\n| 任務 | 負責人 | 完成期限 | 交付成果 |\n| --- | --- | --- | --- |\n| 製作報表 | 小王 | 週三 | 報表 |\n## 待確認事項\n負責人未指定";
        let source = "[00:49] 主持人：請檢查匯出功能，但負責人與期限未指定。請問 APP 要開發嗎？只是建議，未決定。";
        let repaired = retain_explicit_requests(draft, &template, source);
        let request = repaired.lines().find(|line| line.contains("檢查匯出功能")).unwrap();
        assert!(request.contains("[00:49]"));
        assert_eq!(request.matches("待確認").count(), 3);
        assert!(!request.contains("主持人"));
        assert!(!request.contains("APP"));
        assert_eq!(retain_explicit_requests(&repaired, &template, source), repaired);
    }
    #[test]
    fn unstated_status_is_grounded_in_original_words_instead_of_reversed_claims() {
        let source = "[00:30] 小何：這只是我的經驗。當時只有我一個人，沒有員工。\n[00:10] 講師：我稱它為三步檢查法，先確認日期再核對欄位。";
        let draft = "小何當時是一人獨資，沒有員工。\n講師的三步檢查法不是通用標準或既定規範。";
        let grounded = ground_unstated_labels(draft, source).unwrap();
        assert!(!grounded.contains("獨資")); assert!(!grounded.contains("標準"));
        for line in grounded.lines() { assert!(source.contains(line.trim_start_matches("> "))); }
    }
    #[test]
    fn explicit_commitment_replaces_empty_task_row_but_hypotheticals_do_not() {
        let template = localized_template(&super::super::templates::get_template("standard_meeting").unwrap(), Some("zh-TW"));
        let draft = "## 分配的任務及負責人\n| 任務 | 負責人 | 完成期限 | 成果 |\n| --- | --- | --- | --- |\n| 待確認 | 待確認 | 待確認 | 待確認 |\n## 待確認事項\n尚無期限。";
        let source = "[00:00] 我會先修正摘要狀態再補選單。\n[00:10] 如果有預算，我會開發 APP。\n[00:20] 我會考慮建立網站。";
        let repaired = retain_explicit_requests(draft, &template, source);
        assert!(repaired.contains("我會先修正摘要狀態再補選單"));
        assert!(!repaired.contains("|\n\n| 我會"));
        let localized = localize_markdown("| To be confirmed | Not specified | \"To be confirmed\" |", Some("zh-TW"));
        assert_eq!(localized, "| 待確認 | 未指定 | \"To be confirmed\" |");
        assert!(repaired.contains("原文工作承諾"));
        assert!(!repaired.contains("| 待確認 | 待確認 | 待確認 | 待確認 |"));
        assert!(!repaired.contains("開發 APP")); assert!(!repaired.contains("建立網站"));
    }
}

