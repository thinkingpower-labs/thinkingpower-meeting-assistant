/// Embedded default templates using compile-time inclusion
///
/// These templates are bundled into the binary and serve as fallbacks
/// when custom templates are not available.

// All five templates are embedded so portable builds have identical fallback content.
pub const STANDARD_MEETING: &str = include_str!("../../../templates/standard_meeting.json");
pub const RETROSPECTIVE: &str = include_str!("../../../templates/retrospective.json");
pub const SALES_MARKETING_CLIENT_CALL: &str = include_str!("../../../templates/sales_marketing_client_call.json");
pub const INTERVIEW: &str = include_str!("../../../templates/interview.json");
pub const LECTURE_NOTES: &str = include_str!("../../../templates/lecture_notes.json");

pub fn get_builtin_templates() -> Vec<(&'static str, &'static str)> {
    vec![
        ("standard_meeting", STANDARD_MEETING),
        ("retrospective", RETROSPECTIVE),
        ("sales_marketing_client_call", SALES_MARKETING_CLIENT_CALL),
        ("interview", INTERVIEW),
        ("lecture_notes", LECTURE_NOTES),
    ]
}
pub fn get_builtin_template(id: &str) -> Option<&'static str> {
    match id {
        "daily_standup" | "project_sync" => Some(STANDARD_MEETING),
        "standard_meeting" => Some(STANDARD_MEETING),
        "retrospective" => Some(RETROSPECTIVE),
        "sales_marketing_client_call" => Some(SALES_MARKETING_CLIENT_CALL),
        "interview" => Some(INTERVIEW),
        "lecture_notes" => Some(LECTURE_NOTES),
        _ => None,
    }
}
pub fn list_builtin_template_ids() -> Vec<&'static str> {
    vec!["standard_meeting", "retrospective", "sales_marketing_client_call", "interview", "lecture_notes"]
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_builtin_templates_valid_json() {
        for (id, content) in get_builtin_templates() {
            let result = serde_json::from_str::<serde_json::Value>(content);
            assert!(
                result.is_ok(),
                "Built-in template '{}' contains invalid JSON: {:?}",
                id,
                result.err()
            );
        }
    }

    #[test]
    fn test_get_builtin_template() {
        assert!(get_builtin_template("daily_standup").is_some());
        assert!(get_builtin_template("standard_meeting").is_some());
        assert!(get_builtin_template("nonexistent").is_none());
    }
}
