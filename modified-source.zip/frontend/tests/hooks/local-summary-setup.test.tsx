import {mock,test,expect} from 'bun:test';
import {createElement} from 'react';
import {act,create,type ReactTestRenderer} from 'react-test-renderer';
let available=false,failLoad=false,finishDownload:()=>void=()=>{};
const calls:string[]=[];const listeners:Record<string,(e:any)=>void>={};
const invoke=mock(async(command:string,args?:any)=>{
  calls.push(command);
  if(command==='ai_get_connections')return [{connection:{provider:'builtin-ai',text_model:'qwen3.5:4b',endpoint:'',audio_model:'',text_verified:false,audio_verified:false},has_key:false}];
  if(command==='builtin_ai_list_models')return [{name:'qwen3.5:4b',display_name:'Qwen 3.5 4B',size_mb:2614,context_size:32768,status:{type:available?'available':'not_downloaded'}}];
  if(command==='builtin_ai_download_model'){await new Promise<void>(r=>{finishDownload=r;});available=true;return;}
  if(command==='builtin_ai_prepare_model'){if(failLoad)throw Error('記憶體不足');return;}
  if(command==='builtin_ai_is_model_ready')return available;
  if(command==='whisper_get_available_models')return [{name:'small',status:'Available'}];
  return;
});
mock.module('@tauri-apps/api/core',()=>({invoke}));
mock.module('@tauri-apps/api/event',()=>({emit:async()=>{},listen:async(name:string,callback:any)=>{listeners[name]=callback;return ()=>delete listeners[name];}}));
mock.module('../../src/components/ui/button',()=>({Button:(p:any)=>createElement('button',p,p.children)}));
mock.module('sonner',()=>({toast:{error:()=>{},success:()=>{},info:()=>{}}}));
const {ModelSettingsModal}=await import('../../src/components/ModelSettingsModal');
const {FlybirdSetup}=await import('../../src/components/FlybirdSetup');

test('fresh local summary settings offer download, show progress, then load before save; load failure preserves settings',async()=>{
  calls.length=0;available=false;let view:ReactTestRenderer;const saved=mock(()=>{});
  await act(async()=>{view=create(<ModelSettingsModal modelConfig={{provider:'builtin-ai',model:'',whisperModel:'small'}} setModelConfig={()=>{}} onSave={saved}/>);});
  const button=(label:string)=>view!.root.findAllByType('button').find(n=>n.props.children===label)!;
  expect(button('儲存').props.disabled).toBe(true);
  const download=view!.root.findAllByType('button').find(n=>Array.isArray(n.props.children) && n.props.children.some((c:any)=>typeof c==='string' && c.includes('下載')))!;
  await act(async()=>{download.props.onClick({stopPropagation(){}});});
  await act(async()=>listeners['builtin-ai-download-progress']({payload:{model:'qwen3.5:4b',progress:42,status:'downloading',total_mb:2614,downloaded_mb:1098}}));
  expect(JSON.stringify(view!.toJSON())).toContain('42');expect(button('取消')).toBeDefined();
  await act(async()=>{finishDownload();await new Promise(r=>setTimeout(r,10));});
  expect(button('儲存').props.disabled).toBe(false);
  failLoad=true;
  await act(async()=>{await button('儲存').props.onClick();await new Promise(r=>setTimeout(r,10));});
  expect(calls).not.toContain('api_save_model_config');expect(saved).not.toHaveBeenCalled();
  failLoad=false;
  await act(async()=>{await button('儲存').props.onClick();await new Promise(r=>setTimeout(r,10));});
  expect(calls.indexOf('builtin_ai_prepare_model')).toBeLessThan(calls.indexOf('api_save_model_config'));
  expect(saved).toHaveBeenCalledTimes(1);await act(async()=>view!.unmount());
});

test('first setup waits for the Qwen download before completing and reuses existing Whisper',async()=>{
  available=false;calls.length=0;let view:ReactTestRenderer;const reload=mock(()=>{});
  (globalThis as any).window={location:{reload}};(globalThis as any).localStorage={setItem:()=>{}};
  await act(async()=>{view=create(<FlybirdSetup/>);});
  let pending:Promise<void>;
  await act(async()=>{pending=view!.root.findAllByType('button')[0].props.onClick();await new Promise(r=>setTimeout(r,10));});
  expect(calls).toContain('builtin_ai_download_model');expect(calls).not.toContain('flybird_complete_setup');
  expect(calls).not.toContain('whisper_download_model');
  await act(async()=>{finishDownload();await pending!;});
  expect(calls).toContain('flybird_complete_setup');expect(reload).toHaveBeenCalledTimes(1);
  await act(async()=>view!.unmount());
});
