import {act,create,type ReactTestRenderer} from 'react-test-renderer';
import {mock,test,expect} from 'bun:test';
const calls:{command:string,args:any}[]=[];
let savedName='說話人 1';
mock.module('@tauri-apps/api/core',()=>({invoke:async(command:string,args:any)=>{
  calls.push({command,args});
  if(command==='list_meeting_speakers')return [{speaker_id:'attempt-A',display_name:savedName},{speaker_id:'attempt-B',display_name:'說話人 2'}];
  if(command==='rename_meeting_speaker'){savedName=args.displayName.trim();return;}
  throw Error(command);
}}));
const {SpeakerManager}=await import('../../src/components/MeetingDetails/SpeakerManager');
test('rename is meeting scoped, refetches labels and survives reopening',async()=>{
  let view:ReactTestRenderer;const refresh=mock(async()=>{});
  await act(async()=>{view=create(<SpeakerManager meetingId="meeting-one" onSaved={refresh}/>);});
  expect(view!.root.findAllByType('input').map(n=>n.props.value)).toEqual(['說話人 1','說話人 2']);
  await act(async()=>view!.root.findAllByType('input')[0].props.onChange({target:{value:'飛鳥'}}));
  await act(async()=>view!.root.findAllByType('form')[0].props.onSubmit({preventDefault(){}}));
  expect(calls.filter(c=>c.command==='rename_meeting_speaker')).toEqual([{command:'rename_meeting_speaker',args:{meetingId:'meeting-one',speakerId:'attempt-A',displayName:'飛鳥'}}]);
  expect(refresh).toHaveBeenCalledTimes(1);
  expect(JSON.stringify(view!.toJSON())).toContain('姓名已儲存');
  await act(async()=>view!.unmount());
  await act(async()=>{view=create(<SpeakerManager meetingId="meeting-one"/>);});
  expect(view!.root.findAllByType('input')[0].props.value).toBe('飛鳥');
  await act(async()=>view!.unmount());
});

test('empty names cannot be saved',async()=>{
  let view:ReactTestRenderer;
  await act(async()=>{view=create(<SpeakerManager meetingId="meeting-one"/>);});
  await act(async()=>view!.root.findAllByType('input')[0].props.onChange({target:{value:'  '}}));
  expect(view!.root.findAllByType('button')[0].props.disabled).toBe(true);
  await act(async()=>view!.unmount());
});
