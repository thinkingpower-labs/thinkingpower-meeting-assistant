import {mock,test,expect} from 'bun:test';
import {createElement} from 'react';
import {act,create,type ReactTestRenderer} from 'react-test-renderer';
const store=new Map<string,string>();
globalThis.sessionStorage={
  get length(){return store.size;},
  getItem:(k:string)=>store.get(k)??null,
  setItem:(k:string,v:string)=>{store.set(k,v);},
  removeItem:(k:string)=>{store.delete(k);},
  clear:()=>store.clear(),
  key:(index:number)=>Array.from(store.keys())[index]??null,
};
mock.module('next/navigation',()=>({useSearchParams:()=>new URLSearchParams('source=recording&recordingResult=complete')}));
mock.module('../../src/contexts/ConfigContext',()=>({useConfig:()=>({betaFeatures:{importAndRetranscribe:true}})}));
mock.module('../../src/lib/analytics',()=>({default:{trackButtonClick:()=>{}}}));
mock.module('../../src/components/ui/dialog',()=>Object.fromEntries(['Dialog','DialogContent','DialogHeader','DialogTitle','DialogDescription'].map(name=>[name,(p:any)=>createElement('section',{'data-part':name,open:p.open,onOpenChange:p.onOpenChange},p.children)])));
mock.module('../../src/components/ui/button',()=>({Button:(p:any)=>createElement('button',p,p.children)}));
mock.module('../../src/components/MeetingDetails/RetranscribeDialog',()=>({RetranscribeDialog:(p:any)=>createElement('aside',{open:p.open})}));
const {TranscriptButtonGroup}=await import('../../src/components/MeetingDetails/TranscriptButtonGroup');
test('recording navigation explains next step once and never auto-starts retranscription',async()=>{
  let r:ReactTestRenderer;
  const props={transcriptCount:1,onCopyTranscript:()=>{},onOpenMeetingFolder:async()=>{},meetingId:'synthetic-recording',meetingFolderPath:'fixture'};
  await act(async()=>{r=create(<TranscriptButtonGroup {...props}/>);});
  expect(r!.root.findAllByType('section').find(n=>n.props['data-part']==='Dialog')?.props.open).toBe(true);
  expect(JSON.stringify(r!.toJSON())).toContain('產生摘要');
  expect(r!.root.findByType('aside').props.open).toBe(false);
  await act(async()=>r!.unmount());
  await act(async()=>{r=create(<TranscriptButtonGroup {...props}/>);});
  expect(r!.root.findAllByType('section').find(n=>n.props['data-part']==='Dialog')?.props.open).toBe(false);
  await act(async()=>r!.unmount());
});
