import { act, create, type ReactTestRenderer } from 'react-test-renderer';
import { createElement, useState } from 'react';
import { expect, mock, test } from 'bun:test';

const options = [
  {provider:'openai',name:'gpt-4o-mini-transcribe',displayName:'OpenAI',size_mb:0},
  {provider:'whisper',name:'small',displayName:'Whisper',size_mb:100},
];
const requests: {command:string,args:any}[]=[];
let finish: ((value: any)=>void) | undefined;
const fetchModels=async()=>{};
const resetSelection=()=>{};
mock.module('../../src/contexts/ConfigContext',()=>({useConfig:()=>({selectedLanguage:'zh',transcriptModelConfig:{provider:'openai'}})}));
mock.module('../../src/hooks/useTranscriptionModels',()=>({useTranscriptionModels:(_config:any,allowCloud:boolean)=>{
  expect(allowCloud).toBe(true);
  const [selectedModelKey,setSelectedModelKey]=useState('openai:gpt-4o-mini-transcribe');
  return {availableModels:options,selectedModelKey,setSelectedModelKey,loadingModels:false,fetchModels,resetSelection};
}}));
mock.module('@tauri-apps/api/core',()=>({invoke:async(command:string,args:any)=>{
  requests.push({command,args});
  if(command==='ai_get_connections') return [{connection:{provider:'openai',endpoint:'https://example.invalid/v1'}}];
  if(command==='restart_recording_transcription') return new Promise(resolve=>{finish=resolve;});
  if(command==='get_audio_job') return {completed_chunks:'[]'};
  throw new Error(command);
}}));
mock.module('sonner',()=>({toast:{success:()=>{}}}));
mock.module('../../src/components/ui/dialog',()=>Object.fromEntries(['Dialog','DialogContent','DialogDescription','DialogFooter','DialogHeader','DialogTitle'].map(name=>[name,(p:any)=>createElement('section',{'data-part':name,...p},p.children)])));
mock.module('../../src/components/ui/button',()=>({Button:(p:any)=>createElement('button',p,p.children)}));
mock.module('../../src/components/ui/select',()=>({
  Select:(p:any)=>createElement('select',p,p.children),
  ...Object.fromEntries(['SelectContent','SelectItem','SelectTrigger','SelectValue'].map(name=>[name,(p:any)=>createElement('span',p,p.children)])),
}));
const {RetranscribeDialog}=await import('../../src/components/MeetingDetails/RetranscribeDialog');

test('cloud retry requires destination consent and creates exactly one same-meeting attempt',async()=>{
  requests.length=0; const completed=mock(()=>{}); const close=mock(()=>{}); let view:ReactTestRenderer;
  await act(async()=>{view=create(<RetranscribeDialog open meetingId="existing-meeting" meetingFolderPath="fixture" onComplete={completed} onOpenChange={close}/>);});
  const start=()=>view!.root.findAllByType('button').find(node=>node.children.includes('開始新的轉錄'))!;
  expect(start().props.disabled).toBe(true);
  expect(JSON.stringify(view!.toJSON())).toContain('https://example.invalid/v1/audio/transcriptions');
  await act(async()=>view!.root.findByType('input').props.onChange({target:{checked:true}}));
  expect(start().props.disabled).toBe(false);
  const handler=start().props.onClick;
  let pending:Promise<void>;
  await act(async()=>{pending=handler(); void handler();});
  const sent=requests.filter(r=>r.command==='restart_recording_transcription');
  expect(sent).toHaveLength(1);
  expect(sent[0].args).toEqual({meetingId:'existing-meeting',provider:'openai',model:'gpt-4o-mini-transcribe',language:'zh',cloudAuthorized:true,expectedEndpoint:'https://example.invalid/v1'});
  await act(async()=>{finish!({segments_count:3}); await pending!;});
  expect(completed).toHaveBeenCalledTimes(1); expect(close).toHaveBeenCalledWith(false);
  await act(async()=>view!.unmount());
});

test('switching away and back to a cloud model clears the previous consent',async()=>{
  let view:ReactTestRenderer;
  await act(async()=>{view=create(<RetranscribeDialog open meetingId="meeting" meetingFolderPath="fixture" onOpenChange={()=>{}}/>);});
  await act(async()=>view!.root.findByType('input').props.onChange({target:{checked:true}}));
  await act(async()=>view!.root.findAllByType('select')[0].props.onValueChange('whisper:small'));
  expect(view!.root.findAllByType('input')).toHaveLength(0);
  await act(async()=>view!.root.findAllByType('select')[0].props.onValueChange('openai:gpt-4o-mini-transcribe'));
  expect(view!.root.findByType('input').props.checked).toBe(false);
  await act(async()=>view!.unmount());
});
