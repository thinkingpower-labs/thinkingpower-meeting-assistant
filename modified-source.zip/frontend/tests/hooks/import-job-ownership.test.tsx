import {mock,test,expect} from 'bun:test';
import {act,create,type ReactTestRenderer} from 'react-test-renderer';
const listeners=new Map<string,(event:any)=>void>();
const calls:{command:string;args:any}[]=[];
mock.module('@tauri-apps/api/core',()=>({invoke:async(command:string,args:any)=>{calls.push({command,args});return {job_id:args?.requestId};}}));
mock.module('@tauri-apps/api/event',()=>({listen:async(name:string,callback:any)=>{listeners.set(name,callback);return ()=>listeners.delete(name);}}));
mock.module('../../src/lib/analytics',()=>({default:{track:async()=>{},trackError:async()=>{}}}));
mock.module('../../src/lib/summary-language-preferences',()=>({applyPinnedSummaryLanguageToMeeting:async()=>{}}));
mock.module('sonner',()=>({toast:{warning:()=>{}}}));
const {useImportAudio}=await import('../../src/hooks/useImportAudio');
test('parallel import events and cancellation are owned by request id',async()=>{
 let state:ReturnType<typeof useImportAudio>;const complete=mock(()=>{});
 function Harness(){state=useImportAudio({onComplete:complete});return null;}
 let view:ReactTestRenderer;await act(async()=>{view=create(<Harness/>);});
 await act(async()=>{await state!.startImport('fixture.wav','mine',null,'small','whisper');});
 const id=calls.find(call=>call.command==='start_import_audio_command')!.args.requestId;expect(typeof id).toBe('string');
 await act(async()=>listeners.get('import-progress')!({payload:{job_id:'other',stage:'uploading',progress_percentage:99,message:'wrong job'}}));
 expect(state!.progress).toBe(null);
 await act(async()=>listeners.get('import-complete')!({payload:{job_id:'other',meeting_id:'wrong'}}));expect(complete).toHaveBeenCalledTimes(0);
 await act(async()=>listeners.get('import-progress')!({payload:{job_id:id,stage:'transcribing',progress_percentage:45,message:'mine'}}));expect(state!.progress!.message).toBe('mine');
 await act(async()=>state!.cancelImport());expect(calls.at(-1)).toEqual({command:'cancel_transcription_task',args:{jobId:id}});
 await act(async()=>view!.unmount());
});
