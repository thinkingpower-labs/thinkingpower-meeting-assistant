import {test,expect,mock} from 'bun:test';
import {act,create,type ReactTestRenderer} from 'react-test-renderer';
mock.module('sonner',()=>({toast:{success:()=>{},error:()=>{}}}));
const {RecordingFileInfo,storedFileName}=await import('../../src/components/MeetingDetails/RecordingFileInfo');
test('disk names survive a renamed meeting and Windows, Unix, and trailing separators',()=>{
 expect(storedFileName('C:\\Users\\飛鳥\\Music\\Meeting_2026\\')).toBe('Meeting_2026');
 expect(storedFileName('/recordings/原始會議/audio.mp4')).toBe('audio.mp4');
 expect(storedFileName(null)).toBe('');
});
test('shows the real folder and filename and copies the exact path without renaming files',async()=>{
 const copy=mock(async()=>{});Object.defineProperty(globalThis,'navigator',{configurable:true,value:{clipboard:{writeText:copy}}});
 let view:ReactTestRenderer;const folder='C:\\Users\\飛鳥\\Music\\meetily-recordings\\Meeting 21_10_26_19_18_42';
 await act(async()=>{view=create(<RecordingFileInfo folderPath={folder} audioPath={folder+'\\audio.mp4'}/>);});
 const text=JSON.stringify(view!.toJSON());expect(text).toContain('Meeting 21_10_26_19_18_42');expect(text).toContain('audio.mp4');
 await act(async()=>{await view!.root.findAllByType('button')[0].props.onClick();});expect(copy).toHaveBeenCalledWith(folder);
 await act(async()=>{view!.update(<RecordingFileInfo folderPath={folder}/>);});expect(JSON.stringify(view!.toJSON())).toContain('尚未取得原音檔名');
 await act(async()=>view!.unmount());
});
