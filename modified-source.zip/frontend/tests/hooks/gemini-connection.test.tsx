import {mock,test,expect} from 'bun:test';
import {createElement} from 'react';
import {act,create,type ReactTestRenderer} from 'react-test-renderer';
const calls:{command:string,args:any}[]=[];
const connection={provider:'gemini',endpoint:'https://generativelanguage.googleapis.com/v1beta',text_model:'gemini-3.8-flash',audio_model:'gemini-3.8-flash',text_verified:false,audio_verified:false};
mock.module('@tauri-apps/api/core',()=>({invoke:async(command:string,args:any)=>{
  calls.push({command,args});
  if(command==='ai_get_connections')return [{connection,has_key:true}];
  if(command==='cloud_transcription_catalog')return {providers:[{provider:'gemini',models:['gemini-3.8-flash','gemini-3.5-transcribe']}]};
  if(command==='whisper_get_available_models'||command==='parakeet_get_available_models')return [];
  if(command==='ai_save_connection'||command==='api_save_model_config')return;
  throw Error(command);
}}));
mock.module('@tauri-apps/api/event',()=>({emit:async()=>{}}));
mock.module('../../src/components/TextModelPicker',()=>({TextModelPicker:(p:any)=>createElement('input',{'data-model-picker':true,value:p.value,onChange:(e:any)=>p.onChange(e.target.value)})}));
mock.module('../../src/components/ui/button',()=>({Button:(p:any)=>createElement('button',p,p.children)}));
mock.module('../../src/components/ui/input',()=>({Input:(p:any)=>createElement('input',p)}));
mock.module('sonner',()=>({toast:{error:()=>{}}}));
const {useTranscriptionModels}=await import('../../src/hooks/useTranscriptionModels');
const {ModelSettingsModal}=await import('../../src/components/ModelSettingsModal');
let models:ReturnType<typeof useTranscriptionModels>;
function View(){models=useTranscriptionModels({provider:'gemini',model:'gemini-3.8-flash'},true);return null;}
test('Google appears as a cloud provider with ordinary and whole-speaker choices',async()=>{
  let view:ReactTestRenderer;await act(async()=>{view=create(<View/>);});
  await act(async()=>{await models.fetchModels();});
  expect(models.availableModels).toHaveLength(2);
  expect(models.availableModels[1].displayName).toContain('30 分鐘');
  expect(models.selectedModelKey).toBe('gemini:gemini-3.8-flash');
  await act(async()=>view!.unmount());
});
test('Google summary settings preserve the encrypted key and Google endpoint',async()=>{
  let view:ReactTestRenderer;const saved=mock(async()=>{});
  await act(async()=>{view=create(<ModelSettingsModal modelConfig={{provider:'gemini',model:'gemini-3.8-flash',whisperModel:'small'}} setModelConfig={()=>{}} onSave={saved}/>);});
  const key=view!.root.findAllByType('input').find(n=>n.props.type==='password')!;
  expect(key.props.value).toBe('');expect(key.props.placeholder).toContain('留空保留');
  await act(async()=>{await view!.root.findAllByType('button').find(n=>n.props.children==='儲存')!.props.onClick();});
  const sent=calls.find(c=>c.command==='ai_save_connection')!;
  expect(sent.args.config.provider).toBe('gemini');expect(sent.args.config.endpoint).toBe(connection.endpoint);expect(sent.args.apiKey).toBeNull();
  expect(calls.some(c=>c.command==='api_get_api_key')).toBe(false);
  expect(saved).toHaveBeenCalledTimes(1);await act(async()=>view!.unmount());
});
