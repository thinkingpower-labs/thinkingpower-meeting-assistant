import {mock,test,expect} from 'bun:test';
import {createElement} from 'react';
import {act,create,type ReactTestRenderer} from 'react-test-renderer';
const calls:string[]=[];const imports:string[]=[];const failures:string[]=[];
let fail=false;
mock.module('@tauri-apps/api/core',()=>({convertFileSrc:(path:string)=>'asset://'+path,invoke:async(name:string)=>{
  calls.push(name);
  if(name==='list_interrupted_recordings')return [{folder:'fixture',name:'合成驗收',status:'save_failed',chunks:136}];
  if(name==='recover_audio_from_checkpoints'){
    if(fail)throw Error('synthetic IO failure');
    return {status:'success',audio_file_path:'verified-fixture.mp4',message:'ok'};
  }
  throw Error('Unexpected call '+name);
}}));
mock.module('../../src/contexts/ImportDialogContext',()=>({useImportDialog:()=>({openImportDialog:(path:string)=>imports.push(path)})}));
mock.module('../../src/components/ui/button',()=>({Button:(p:any)=>createElement('button',p,p.children)}));
mock.module('sonner',()=>({toast:{error:(message:string)=>failures.push(message),success:()=>{}}}));
const {InterruptedRecordings}=await import('../../src/components/InterruptedRecordings');
test('startup recovery waits for user confirmation and opens import without starting AI',async()=>{
  let r:ReactTestRenderer;
  await act(async()=>{r=create(<InterruptedRecordings/>);});
  expect(calls).toEqual(['list_interrupted_recordings']);expect(imports).toEqual([]);
  await act(async()=>{await r!.root.findAllByType('button').find(button=>button.children.includes('檢查原音並匯入'))!.props.onClick();});
  expect(calls).toEqual(['list_interrupted_recordings','recover_audio_from_checkpoints']);
  expect(imports).toEqual(['verified-fixture.mp4']);
  await act(async()=>{r!.unmount();});
});
test('recovery failure leaves the original entry available and never imports',async()=>{
  fail=true;imports.length=0;let r:ReactTestRenderer;
  await act(async()=>{r=create(<InterruptedRecordings/>);});
  await act(async()=>{await r!.root.findAllByType('button').find(button=>button.children.includes('檢查原音並匯入'))!.props.onClick();});
  expect(imports).toEqual([]);expect(failures.at(-1)).toContain('未覆寫原音');
  expect(r!.root.findAllByType('button').find(button=>button.children.includes('檢查原音並匯入'))!.props.disabled).toBe(false);
  await act(async()=>{r!.unmount();});
});

test('unfinished recording can be recovered for listening without importing or starting AI',async()=>{
  fail=false;imports.length=0;const listen=mock(()=>{});let r:ReactTestRenderer;
  await act(async()=>{r=create(<InterruptedRecordings onListen={listen}/>);});
  await act(async()=>{await r!.root.findAllByType('button').find(button=>button.children.includes('檢查原音並聆聽'))!.props.onClick();});
  expect(listen).toHaveBeenCalledWith('verified-fixture.mp4','合成驗收');
  expect(imports).toEqual([]);expect(calls.some(name=>/start_import|restart|resume/.test(name))).toBe(false);
  await act(async()=>r!.unmount());
});
