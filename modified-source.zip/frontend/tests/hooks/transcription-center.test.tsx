import {mock,test,expect} from 'bun:test';
import {createElement} from 'react';
import {act,create,type ReactTestRenderer} from 'react-test-renderer';
const calls:{name:string;args:any}[]=[];
const tasks=[
 {job_id:'task-a',meeting_id:'a',title:'第一場會議',provider:'openai',model:'mini',status:'running',stage:'uploading',progress_percentage:40,completed:2,total:10,message:'第一場進度',created_at:1},
 {job_id:'task-b',meeting_id:'b',title:'第二場會議',provider:'whisper',model:'small',status:'queued',stage:'queued',progress_percentage:0,completed:0,total:0,message:'等待本機模型',created_at:2},
];
mock.module('@tauri-apps/api/core',()=>({convertFileSrc:(path:string)=>`asset://${path}`,invoke:async(name:string,args:any)=>{
 calls.push({name,args});
 if(name==='list_recording_library')return [{meeting_id:'old',title:'之前的錄音',created_at:'2026-10-20',folder_path:'fixture',stage:'interrupted',provider:'whisper',model:'small',completed_count:14,error:null}];
 if(name==='flybird_meeting_audio')return `fixture-${args.meetingId}.wav`;
 if(name==='cancel_transcription_task')return;
 throw Error(name);
}}));
mock.module('../../src/hooks/useTranscriptionTasks',()=>({useTranscriptionTasks:()=>({tasks,error:''}),isActiveTask:(task:any)=>['queued','running','cancelling'].includes(task.status)}));
mock.module('next/link',()=>({default:(p:any)=>createElement('a',p,p.children)}));
mock.module('sonner',()=>({toast:{info:()=>{},error:()=>{}}}));
mock.module('../../src/components/ui/button',()=>({Button:(p:any)=>createElement('button',p,p.children)}));
mock.module('../../src/contexts/ImportDialogContext',()=>({useImportDialog:()=>({openImportDialog:()=>{}})}));
mock.module('../../src/components/InterruptedRecordings',()=>({InterruptedRecordings:()=>createElement('div',null,'未完成錄音集中管理')}));
const {default:Page}=await import('../../src/app/recordings/page');
test('center scopes cancellation, shows independent progress, searches and listens without starting AI',async()=>{
 let view:ReactTestRenderer;
 await act(async()=>{view=create(<Page/>);});
 expect(JSON.stringify(view!.toJSON())).toContain('第一場進度');
 expect(JSON.stringify(view!.toJSON())).toContain('等待本機模型');
 expect(JSON.stringify(view!.toJSON())).toContain('之前的錄音');
 expect(view!.root.findAllByType('progress').map(node=>node.props.value)).toEqual([40,0]);
 await act(async()=>{await view!.root.findAllByType('button').filter(node=>node.children.includes('取消這筆轉錄'))[1].props.onClick();});
 expect(calls.filter(call=>call.name==='cancel_transcription_task')).toEqual([{name:'cancel_transcription_task',args:{jobId:'task-b'}}]);
 await act(async()=>{await view!.root.findAllByType('button').find(node=>node.children.includes('聆聽原音'))!.props.onClick();});
 const audio=view!.root.findByType('audio');expect(audio.props.src).toBe('asset://fixture-a.wav');expect(audio.props.controls).toBe(true);
 expect(calls.some(call=>/restart|resume|start_import/.test(call.name))).toBe(false);
 await act(async()=>view!.root.findByType('input').props.onChange({target:{value:'之前'}}));
 expect(view!.root.findAllByType('progress')).toHaveLength(0);
 expect(JSON.stringify(view!.toJSON())).toContain('之前的錄音');
 await act(async()=>view!.root.findByType('select').props.onChange({target:{value:'active'}}));
 expect(JSON.stringify(view!.toJSON())).not.toContain('之前的錄音');
 await act(async()=>view!.unmount());
});
