import {expect,test} from 'bun:test';
import {parseSummaryContent} from '../../src/lib/summary-content';
test('all-placeholder Chinese and English reports cannot appear completed',()=>{
  expect(parseSummaryContent({markdown:'**會議日期與時間** 此部分未註明。\n**行動項目** 此部分未註明。'})).toBeNull();
  expect(parseSummaryContent({markdown:'## Summary\nNone noted in this section.\n## Actions\nNone noted in this section.'})).toBeNull();
  expect(parseSummaryContent({markdown:'## 摘要\n網站首頁需要加入貓咪動畫。\n## 日期\n未註明。'})).not.toBeNull();
});
