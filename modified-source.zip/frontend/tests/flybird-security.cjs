const test = require('node:test');
const assert = require('node:assert/strict');
const { createRequire } = require('node:module');
const fromEditor = createRequire(require.resolve('@blocknote/core'));
const { mergeAttributes } = fromEditor('@tiptap/core');

test('editor rejects prototype keys from untrusted imported attributes', () => {
  const malicious = JSON.parse('{"__proto__":{"onerror":"bad()"},"constructor":{"prototype":{"onclick":"bad()"}},"prototype":{"x":1},"title":"正常文字"}');
  const result = mergeAttributes({class:'first'}, malicious);
  assert.deepEqual(Object.keys(result).sort(), ['class','title']);
  assert.equal(result.onerror, undefined);
  assert.equal(result.onclick, undefined);
  assert.equal(result.title, '正常文字');
  const enumerated=[]; for (const key in result) enumerated.push(key);
  assert.deepEqual(enumerated.sort(), ['class','title']);
});

test('patched editor still merges normal classes and styles', () => {
  const result=mergeAttributes({class:'one', style:'color: red'}, {class:'one two', style:'color: blue'});
  assert.equal(result.class,'one two');
  assert.equal(result.style,'color: blue');
});
