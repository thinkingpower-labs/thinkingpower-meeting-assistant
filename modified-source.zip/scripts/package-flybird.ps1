$ErrorActionPreference = 'Stop'
$repo = Split-Path $PSScriptRoot -Parent
$project = Split-Path $repo -Parent
$env:PATH = "$env:USERPROFILE\.cargo\bin;$project\tooling\python\cmake\data\bin;" + $env:PATH
$env:LIBCLANG_PATH = "$project\tooling\python\clang\native"
$env:CMAKE_POLICY_VERSION_MINIMUM = '3.5'
$env:CXXFLAGS = '/utf-8'
$env:CFLAGS = '/utf-8'
$env:CARGO_BUILD_JOBS = '6'
$env:NEXT_TELEMETRY_DISABLED = '1'
Push-Location -LiteralPath (Join-Path $repo 'frontend')
try {
    & pnpm exec tauri build --bundles nsis --config ../scripts/bundle-config.json --ci
    if ($LASTEXITCODE -ne 0) { throw "Packaging failed: $LASTEXITCODE" }
} finally { Pop-Location }

