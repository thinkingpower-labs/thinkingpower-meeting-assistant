//! Durable progress. A completed chunk is never automatically sent twice.
use serde::{Deserialize, Serialize};
use sqlx::SqlitePool;

#[derive(Clone, Serialize, Deserialize, sqlx::FromRow)]
pub struct FileJob {
    pub meeting_id: String,
    pub source_path: String,
    pub provider: String,
    pub model: Option<String>,
    pub language: Option<String>,
    pub stage: String,
    pub completed_chunks: String,
    pub error: Option<String>,
    pub source_sha256: Option<String>,
    pub endpoint: Option<String>,
}

pub fn fingerprint(path: &std::path::Path) -> std::io::Result<String> {
    use sha2::{Digest, Sha256};
    use std::io::Read;
    let mut file = std::fs::File::open(path)?;
    let mut hash = Sha256::new();
    let mut buffer = [0u8; 65536];
    loop { let n = file.read(&mut buffer)?; if n == 0 { break; } hash.update(&buffer[..n]); }
    Ok(format!("{:x}", hash.finalize()))
}

pub async fn create(pool: &SqlitePool, id: &str, source: &str, provider: &str, model: Option<&str>, language: Option<&str>) -> Result<(), sqlx::Error> {
    let hash = fingerprint(std::path::Path::new(source)).map_err(sqlx::Error::Io)?;
    let endpoint = if matches!(provider, "openai" | "groq" | "openrouter" | "custom-openai") {
        Some(crate::ai_services::connection(pool, provider).await.map_err(sqlx::Error::Protocol)?.endpoint)
    } else { None };
    sqlx::query("INSERT INTO audio_jobs(meeting_id,source_path,provider,model,language,source_sha256,endpoint) VALUES(?,?,?,?,?,?,?)")
        .bind(id).bind(source).bind(provider).bind(model).bind(language).bind(hash).bind(endpoint).execute(pool).await?;
    Ok(())
}

pub async fn get(pool: &SqlitePool, id: &str) -> Result<FileJob, sqlx::Error> {
    sqlx::query_as("SELECT meeting_id,source_path,provider,model,language,stage,completed_chunks,error,source_sha256,endpoint FROM audio_jobs WHERE meeting_id=?")
        .bind(id).fetch_one(pool).await
}

pub async fn checkpoint(pool: &SqlitePool, id: &str, chunks: &[(String, f64, f64)]) -> Result<(), sqlx::Error> {
    let value = serde_json::to_string(chunks).map_err(|_| sqlx::Error::Protocol("無法保存轉錄進度".into()))?;
    sqlx::query("UPDATE audio_jobs SET completed_chunks=?,stage='transcribing',error=NULL,updated_at=CURRENT_TIMESTAMP WHERE meeting_id=?")
        .bind(value).bind(id).execute(pool).await?;
    Ok(())
}

pub async fn stage(pool: &SqlitePool, id: &str, stage: &str, error: Option<&str>) -> Result<(), sqlx::Error> {
    sqlx::query("UPDATE audio_jobs SET stage=?,error=?,updated_at=CURRENT_TIMESTAMP WHERE meeting_id=?")
        .bind(stage).bind(error).bind(id).execute(pool).await?;
    Ok(())
}

#[tauri::command]
pub async fn prepare_recording_job(state: tauri::State<'_, crate::state::AppState>, meeting_id: String,
    provider: String, model: Option<String>, language: Option<String>) -> Result<(), String> {
    let pool = state.db_manager.pool();
    match get(pool, &meeting_id).await {
        Ok(_) => return Ok(()),
        Err(sqlx::Error::RowNotFound) => (),
        Err(_) => return Err("無法讀取既有處理進度".into()),
    }
    let folder: Option<String> = sqlx::query_scalar("SELECT folder_path FROM meetings WHERE id=?")
        .bind(&meeting_id).fetch_one(pool).await.map_err(|_| "找不到已儲存的會議")?;
    let folder = folder.ok_or("會議沒有原始錄音路徑")?;
    let audio = super::retranscription::find_audio_file(std::path::Path::new(&folder)).map_err(|_| "找不到原始錄音；已停止轉錄")?;
    create(pool, &meeting_id, &audio.to_string_lossy(), &provider, model.as_deref(), language.as_deref()).await.map_err(|_| "無法保存處理進度".to_string())
}

#[tauri::command]
pub async fn get_audio_job(state: tauri::State<'_, crate::state::AppState>, meeting_id: String) -> Result<Option<FileJob>, String> {
    match get(state.db_manager.pool(), &meeting_id).await {
        Ok(job) => Ok(Some(job)),
        Err(sqlx::Error::RowNotFound) => Ok(None),
        Err(_) => Err("無法讀取處理進度；原始錄音不受影響。".into()),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[tokio::test]
    async fn failed_job_retains_audio_chunks_and_same_meeting_after_reopen() {
        let directory = tempfile::tempdir().unwrap();
        let audio = directory.path().join("original.wav");
        let original = super::super::cloud_transcription::wav(&[0.25; 1600]);
        std::fs::write(&audio, &original).unwrap();
        let database = directory.path().join("test.sqlite");
        let options = sqlx::sqlite::SqliteConnectOptions::new().filename(&database).create_if_missing(true);
        let pool = sqlx::sqlite::SqlitePoolOptions::new().max_connections(1).connect_with(options.clone()).await.unwrap();
        sqlx::migrate!("./migrations").run(&pool).await.unwrap();
        sqlx::query("INSERT INTO meetings(id,title,created_at,updated_at) VALUES('test-meeting','合成測試',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)").execute(&pool).await.unwrap();
        create(&pool, "test-meeting", &audio.to_string_lossy(), "openai", Some("gpt-4o-mini-transcribe"), Some("zh")).await.unwrap();
        checkpoint(&pool, "test-meeting", &[("已完成分段".into(), 0.0, 100.0)]).await.unwrap();
        stage(&pool, "test-meeting", "failed", Some("合成網路錯誤")).await.unwrap();
        pool.close().await;
        let reopened = sqlx::sqlite::SqlitePoolOptions::new().max_connections(1).connect_with(options).await.unwrap();
        let job = get(&reopened, "test-meeting").await.unwrap();
        assert_eq!(job.stage, "failed");
        let chunks: Vec<(String, f64, f64)> = serde_json::from_str(&job.completed_chunks).unwrap();
        assert_eq!(chunks.len(), 1);
        assert_eq!(std::fs::read(&audio).unwrap(), original);
        assert!(create(&reopened, "test-meeting", "unused", "groq", None, None).await.is_err());
        let count: i64 = sqlx::query_scalar("SELECT COUNT(*) FROM meetings").fetch_one(&reopened).await.unwrap();
        assert_eq!(count, 1);
        stage(&reopened, "test-meeting", "transcribed", None).await.unwrap();
        assert_eq!(get(&reopened, "test-meeting").await.unwrap().completed_chunks, job.completed_chunks);
        reopened.close().await;
    }

    #[test]
    fn same_name_meetings_never_reuse_audio_folders() {
        let root = tempfile::tempdir().unwrap();
        let first = super::super::audio_processing::create_meeting_folder(&root.path().to_path_buf(), "相同會議", false).unwrap();
        std::fs::write(first.join("audio.wav"), b"first recording").unwrap();
        let second = super::super::audio_processing::create_meeting_folder(&root.path().to_path_buf(), "相同會議", false).unwrap();
        assert_ne!(first, second);
        assert_eq!(std::fs::read(first.join("audio.wav")).unwrap(), b"first recording");
    }
}
