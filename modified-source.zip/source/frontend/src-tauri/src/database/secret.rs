//! Windows user-bound DPAPI encryption. No plaintext fallback on other platforms.
//! Ciphertext may be backed up, but is not portable to another Windows account.
use sqlx::SqlitePool;

fn failure() -> sqlx::Error {
    sqlx::Error::Protocol("無法使用 Windows 安全儲存；未儲存或顯示金鑰。".into())
}

pub(crate) fn protect_backup(bytes: &[u8]) -> Result<Vec<u8>, sqlx::Error> { crypt(bytes, true) }

#[cfg(windows)]
fn crypt(input: &[u8], encrypt: bool) -> Result<Vec<u8>, sqlx::Error> {
    #[repr(C)]
    struct Blob { len: u32, data: *mut u8 }
    #[link(name = "crypt32")]
    extern "system" {
        fn CryptProtectData(input: *const Blob, description: *const u16, entropy: *const Blob,
            reserved: *mut std::ffi::c_void, prompt: *mut std::ffi::c_void, flags: u32, output: *mut Blob) -> i32;
        fn CryptUnprotectData(input: *const Blob, description: *mut *mut u16, entropy: *const Blob,
            reserved: *mut std::ffi::c_void, prompt: *mut std::ffi::c_void, flags: u32, output: *mut Blob) -> i32;
    }
    #[link(name = "kernel32")]
    extern "system" { fn LocalFree(memory: *mut std::ffi::c_void) -> *mut std::ffi::c_void; }
    let len = u32::try_from(input.len()).map_err(|_| failure())?;
    let source = Blob { len, data: input.as_ptr() as *mut u8 };
    let mut output = Blob { len: 0, data: std::ptr::null_mut() };
    // DPAPI allocates output with LocalAlloc; copy then zero and free it on both paths.
    unsafe {
        let ok = if encrypt {
            CryptProtectData(&source, std::ptr::null(), std::ptr::null(), std::ptr::null_mut(), std::ptr::null_mut(), 1, &mut output)
        } else {
            CryptUnprotectData(&source, std::ptr::null_mut(), std::ptr::null(), std::ptr::null_mut(), std::ptr::null_mut(), 1, &mut output)
        };
        if ok == 0 { return Err(failure()); }
        let result = std::slice::from_raw_parts(output.data, output.len as usize).to_vec();
        for offset in 0..output.len as usize { output.data.add(offset).write_volatile(0); }
        LocalFree(output.data.cast());
        Ok(result)
    }
}

#[cfg(not(windows))]
fn crypt(_: &[u8], _: bool) -> Result<Vec<u8>, sqlx::Error> { Err(failure()) }

pub async fn save(pool: &SqlitePool, provider: &str, key: &str) -> Result<(), sqlx::Error> {
    let encrypted = crypt(key.as_bytes(), true)?;
    sqlx::query("INSERT INTO service_secrets(provider, protected_key) VALUES (?, ?) ON CONFLICT(provider) DO UPDATE SET protected_key=excluded.protected_key")
        .bind(provider).bind(encrypted).execute(pool).await?;
    Ok(())
}

pub async fn get(pool: &SqlitePool, provider: &str) -> Result<Option<String>, sqlx::Error> {
    let value: Option<Vec<u8>> = sqlx::query_scalar("SELECT protected_key FROM service_secrets WHERE provider=?")
        .bind(provider).fetch_optional(pool).await?;
    value.map(|bytes| crypt(&bytes, false).and_then(|plain| String::from_utf8(plain).map_err(|_| failure()))).transpose()
}

pub async fn delete(pool: &SqlitePool, provider: &str) -> Result<(), sqlx::Error> {
    sqlx::query("DELETE FROM service_secrets WHERE provider IN (?,?,?)").bind(provider)
        .bind(format!("legacy-settings-{provider}")).bind(format!("legacy-transcript_settings-{provider}")).execute(pool).await?;
    Ok(())
}

/// Move legacy plaintext fields only after their encrypted copies are durable.
/// If two old screens held different keys, retain the second encrypted value for
/// recovery and require the user to save a single preferred service key later.
pub async fn migrate_legacy(pool: &SqlitePool) -> Result<(), sqlx::Error> {
    let mut tx = pool.begin().await?;
    for (table, column, provider) in [
        ("settings", "openaiApiKey", "openai"),
        ("settings", "anthropicApiKey", "claude"),
        ("settings", "groqApiKey", "groq"),
        ("settings", "openRouterApiKey", "openrouter"),
        ("settings", "ollamaApiKey", "ollama"),
        ("transcript_settings", "openaiApiKey", "openai"),
        ("transcript_settings", "groqApiKey", "groq"),
        ("transcript_settings", "deepgramApiKey", "deepgram"),
        ("transcript_settings", "elevenLabsApiKey", "elevenLabs"),
        ("transcript_settings", "whisperApiKey", "legacy-whisper"),
    ] {
        let query = format!("SELECT {column} FROM {table} WHERE id='1'");
        let old: Option<String> = sqlx::query_scalar::<_, Option<String>>(&query).fetch_optional(&mut *tx).await?.flatten();
        if let Some(key) = old.filter(|value| !value.is_empty()) {
            let current: Option<Vec<u8>> = sqlx::query_scalar("SELECT protected_key FROM service_secrets WHERE provider=?")
                .bind(provider).fetch_optional(&mut *tx).await?;
            let target = match current {
                Some(bytes) if crypt(&bytes, false)? != key.as_bytes() => format!("legacy-{table}-{provider}"),
                _ => provider.to_string(),
            };
            let encrypted = crypt(key.as_bytes(), true)?;
            sqlx::query("INSERT INTO service_secrets(provider,protected_key) VALUES (?,?) ON CONFLICT(provider) DO NOTHING")
                .bind(target).bind(encrypted).execute(&mut *tx).await?;
            sqlx::query(&format!("UPDATE {table} SET {column}=NULL WHERE id='1'"))
                .execute(&mut *tx).await?;
        }
    }
    let custom: Option<String> = sqlx::query_scalar::<_, Option<String>>("SELECT customOpenAIConfig FROM settings WHERE id='1'")
        .fetch_optional(&mut *tx).await?.flatten();
    if let Some(json) = custom {
        let mut config: serde_json::Value = serde_json::from_str(&json).map_err(|_| failure())?;
        if let Some(key) = config.get("apiKey").and_then(|value| value.as_str()).filter(|key| !key.is_empty()) {
            let current: Option<Vec<u8>> = sqlx::query_scalar("SELECT protected_key FROM service_secrets WHERE provider='custom-openai'")
                .fetch_optional(&mut *tx).await?;
            let target = match current {
                Some(bytes) if crypt(&bytes, false)? != key.as_bytes() => "legacy-settings-custom-openai",
                _ => "custom-openai",
            };
            let encrypted = crypt(key.as_bytes(), true)?;
            sqlx::query("INSERT INTO service_secrets(provider,protected_key) VALUES (?,?) ON CONFLICT(provider) DO NOTHING")
                .bind(target).bind(encrypted).execute(&mut *tx).await?;
            config["apiKey"] = serde_json::Value::Null;
            sqlx::query("UPDATE settings SET customOpenAIConfig=? WHERE id='1'")
                .bind(config.to_string()).execute(&mut *tx).await?;
        }
    }
    tx.commit().await?;
    Ok(())
}

#[cfg(all(test, windows))]
mod tests {
    use super::*;
    #[tokio::test]
    async fn migration_preserves_meetings_and_shares_service_keys() {
        use crate::database::repositories::setting::SettingsRepository;
        let pool = sqlx::sqlite::SqlitePoolOptions::new().max_connections(1).connect("sqlite::memory:").await.unwrap();
        sqlx::migrate!("./migrations").run(&pool).await.unwrap();
        sqlx::query("INSERT INTO settings(id,provider,model,whisperModel,openaiApiKey) VALUES('1','openai','test','small','synthetic-summary')")
            .execute(&pool).await.unwrap();
        sqlx::query("INSERT INTO transcript_settings(id,provider,model,openaiApiKey) VALUES('1','openai','test','synthetic-transcript')")
            .execute(&pool).await.unwrap();
        migrate_legacy(&pool).await.unwrap();
        migrate_legacy(&pool).await.unwrap(); // Restart is idempotent.
        assert_eq!(get(&pool, "openai").await.unwrap().as_deref(), Some("synthetic-summary"));
        assert_eq!(get(&pool, "legacy-transcript_settings-openai").await.unwrap().as_deref(), Some("synthetic-transcript"));
        let old: Option<String> = sqlx::query_scalar("SELECT openaiApiKey FROM settings").fetch_one(&pool).await.unwrap();
        assert!(old.is_none());
        SettingsRepository::save_transcript_api_key(&pool, "openai", "synthetic-new").await.unwrap();
        assert_eq!(SettingsRepository::get_api_key(&pool, "openai").await.unwrap().as_deref(), Some("synthetic-new"));
        SettingsRepository::save_api_key(&pool, "groq", "synthetic-other").await.unwrap();
        SettingsRepository::delete_api_key(&pool, "openai").await.unwrap();
        assert!(SettingsRepository::get_transcript_api_key(&pool, "openai").await.unwrap().is_none());
        assert_eq!(get(&pool, "groq").await.unwrap().as_deref(), Some("synthetic-other"));
    }
    #[test]
    fn dpapi_roundtrip_and_tamper_rejection() {
        let plain = b"synthetic-test-secret-only";
        let mut encrypted = crypt(plain, true).unwrap();
        assert!(!encrypted.windows(plain.len()).any(|window| window == plain));
        assert_eq!(crypt(&encrypted, false).unwrap(), plain);
        let last = encrypted.len() - 1;
        encrypted[last] ^= 1;
        assert!(crypt(&encrypted, false).is_err());
    }
}
