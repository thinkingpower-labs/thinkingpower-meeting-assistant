use crate::{state::AppState, database::{secret, repositories::setting::SettingsRepository}};
use serde::{Deserialize, Serialize};
use sqlx::SqlitePool;
use tauri::Manager;

pub const PROVIDERS: &[&str] = &["builtin-ai", "claude", "custom-openai", "groq", "ollama", "openai", "openrouter"];

#[derive(Clone, Serialize, Deserialize, sqlx::FromRow)]
pub struct Connection {
    pub provider: String,
    pub endpoint: String,
    pub text_model: String,
    pub audio_model: String,
    pub text_verified: bool,
    pub audio_verified: bool,
}

fn default_endpoint(provider: &str) -> &'static str {
    match provider {
        "openai" => "https://api.openai.com/v1",
        "claude" => "https://api.anthropic.com/v1",
        "groq" => "https://api.groq.com/openai/v1",
        "openrouter" => "https://openrouter.ai/api/v1",
        "ollama" => "http://localhost:11434/v1",
        _ => "",
    }
}

pub fn validate_endpoint(endpoint: &str) -> Result<(), String> {
    let url = url::Url::parse(endpoint).map_err(|_| "請輸入有效的伺服器網址")?;
    if !url.username().is_empty() || url.password().is_some() || url.query().is_some() || url.fragment().is_some() {
        return Err("網址不可包含帳密、查詢參數或片段；請使用獨立的 API Key 欄位。".into());
    }
    let local = matches!(url.host_str(), Some("localhost" | "127.0.0.1" | "[::1]"));
    if url.scheme() != "https" && !(local && url.scheme() == "http") {
        return Err("雲端伺服器須使用 HTTPS；僅本機回送網址可使用 HTTP。".into());
    }
    Ok(())
}

pub async fn connection(pool: &SqlitePool, provider: &str) -> Result<Connection, String> {
    if !PROVIDERS.contains(&provider) { return Err("不支援此服務".into()); }
    let saved: Option<Connection> = sqlx::query_as("SELECT * FROM service_connections WHERE provider=?")
        .bind(provider).fetch_optional(pool).await.map_err(|_| "無法讀取服務設定")?;
    Ok(saved.unwrap_or_else(|| Connection { provider: provider.into(), endpoint: default_endpoint(provider).into(),
        text_model: String::new(), audio_model: String::new(), text_verified: false, audio_verified: false }))
}

#[tauri::command]
pub async fn ai_get_connections(state: tauri::State<'_, AppState>) -> Result<serde_json::Value, String> {
    let pool = state.db_manager.pool();
    let mut results = Vec::new();
    for provider in PROVIDERS {
        let config = connection(pool, provider).await?;
        let has_key = secret::get(pool, provider).await.map_err(|_| "無法存取 Windows 安全儲存")?.is_some();
        results.push(serde_json::json!({"connection": config, "has_key": has_key}));
    }
    Ok(serde_json::Value::Array(results))
}

#[tauri::command]
pub async fn ai_save_connection(state: tauri::State<'_, AppState>, mut config: Connection, api_key: Option<String>) -> Result<(), String> {
    if !PROVIDERS.contains(&config.provider.as_str()) { return Err("不支援此服務".into()); }
    if config.provider != "builtin-ai" { validate_endpoint(&config.endpoint)?; }
    if !matches!(config.provider.as_str(), "custom-openai" | "ollama" | "builtin-ai") && config.endpoint.trim_end_matches('/') != default_endpoint(&config.provider) {
        return Err("此服務請使用官方端點；其他網址請選擇自訂伺服器。".into());
    }
    let pool = state.db_manager.pool();
    let old = connection(pool, &config.provider).await?;
    let key_changed = api_key.as_ref().is_some_and(|key| !key.trim().is_empty());
    config.text_verified = old.text_verified && old.endpoint == config.endpoint && old.text_model == config.text_model && !key_changed;
    config.audio_verified = old.audio_verified && old.endpoint == config.endpoint && old.audio_model == config.audio_model && !key_changed;
    if let Some(key) = api_key.filter(|key| !key.trim().is_empty()) {
        secret::save(pool, &config.provider, key.trim()).await.map_err(|_| "金鑰未能安全儲存，設定未完成")?;
    }
    sqlx::query("INSERT INTO service_connections(provider,endpoint,text_model,audio_model,text_verified,audio_verified) VALUES(?,?,?,?,?,?) ON CONFLICT(provider) DO UPDATE SET endpoint=excluded.endpoint,text_model=excluded.text_model,audio_model=excluded.audio_model,text_verified=excluded.text_verified,audio_verified=excluded.audio_verified")
        .bind(&config.provider).bind(&config.endpoint).bind(&config.text_model).bind(&config.audio_model)
        .bind(config.text_verified).bind(config.audio_verified).execute(pool).await.map_err(|_| "無法儲存連線設定")?;
    // Keep existing summary adapter configuration in sync without storing secrets in JSON.
    if config.provider == "custom-openai" {
        SettingsRepository::save_custom_openai_config(pool, &crate::summary::CustomOpenAIConfig {
            endpoint: config.endpoint, api_key: None, model: config.text_model, max_tokens: None, temperature: None, top_p: None
        }).await.map_err(|_| "無法同步自訂伺服器設定")?;
    }
    Ok(())
}

#[tauri::command]
pub async fn ai_remove_connection(state: tauri::State<'_, AppState>, provider: String) -> Result<(), String> {
    let pool = state.db_manager.pool();
    if !PROVIDERS.contains(&provider.as_str()) { return Err("不支援此服務".into()); }
    secret::delete(pool, &provider).await.map_err(|_| "無法移除金鑰")?;
    if provider == "custom-openai" {
        sqlx::query("UPDATE settings SET customOpenAIConfig=NULL WHERE id='1'")
            .execute(pool).await.map_err(|_| "無法移除自訂伺服器設定")?;
    }
    sqlx::query("DELETE FROM service_connections WHERE provider=?").bind(&provider).execute(pool).await.map_err(|_| "無法移除連線設定")?;
    Ok(())
}

#[tauri::command]
pub async fn ai_test_connection(app: tauri::AppHandle, state: tauri::State<'_, AppState>, provider: String, capability: String, confirmed: bool) -> Result<String, String> {
    if !confirmed { return Err("測試會送出合成測試資料，雲端可能計費；請先確認。".into()); }
    let pool = state.db_manager.pool();
    let config = connection(pool, &provider).await?;
    let key = secret::get(pool, &provider).await.map_err(|_| "無法讀取安全儲存的金鑰")?;
    if !matches!(provider.as_str(), "builtin-ai" | "ollama" | "custom-openai") && key.is_none() {
        return Err("請先儲存此服務的 API Key".into());
    }
    let column = match capability.as_str() {
        "audio" => {
            if provider != "custom-openai" && !crate::audio::cloud_transcription::models(&provider).contains(&config.audio_model.as_str()) {
                return Err("此服務／模型未提供已查核的語音轉錄介面".into());
            }
            if config.audio_model.is_empty() { return Err("請先設定語音轉錄模型".into()); }
            crate::audio::cloud_transcription::transcribe(&config.endpoint, key.as_deref(), &config.audio_model, None, &[0.0; 16000]).await?;
            "audio_verified"
        }
        "text" => {
            if config.text_model.is_empty() { return Err("請先設定文字模型".into()); }
            let engine = crate::summary::LLMProvider::from_str(&provider)?;
            let client = reqwest::Client::builder().connect_timeout(std::time::Duration::from_secs(15))
                .redirect(reqwest::redirect::Policy::none()).build().map_err(|_| "無法建立連線")?;
            let app_data = app.path().app_data_dir().map_err(|_| "找不到本機模型資料夾")?;
            crate::summary::llm_client::generate_summary(&client, &engine, &config.text_model, key.as_deref().unwrap_or(""),
                "This is a connection test. Reply OK.", "Test only. No meeting content.",
                Some(config.endpoint.trim_end_matches("/v1")), Some(&config.endpoint), Some(16), None, None, Some(&app_data), None).await?;
            "text_verified"
        }
        _ => return Err("不支援此測試類型".into()),
    };
    sqlx::query(&format!("UPDATE service_connections SET {column}=1 WHERE provider=?"))
        .bind(&provider).execute(pool).await.map_err(|_| "測試成功，但無法保存驗證狀態")?;
    Ok("測試端點回應正常；這不代表長錄音的品質、完整性或費用已驗收。".into())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn urls_cannot_carry_secrets_or_plaintext_remote_traffic() {
        assert!(validate_endpoint("http://localhost:11434/v1").is_ok());
        assert!(validate_endpoint("https://example.com/v1").is_ok());
        for value in ["http://example.com", "https://user:secret@example.com", "https://example.com?key=secret", "file:///tmp/x"] {
            assert!(validate_endpoint(value).is_err());
        }
    }
}
