use crate::state::AppState;
use crate::database::repositories::setting::SettingsRepository;
use tauri::AppHandle;
use tauri_plugin_dialog::DialogExt;
use sqlx::Row;
use tauri::Manager;

#[tauri::command]
pub async fn flybird_meeting_audio(app: AppHandle, state: tauri::State<'_, AppState>, meeting_id: String) -> Result<String, String> {
    let folder: Option<String> = sqlx::query_scalar("SELECT folder_path FROM meetings WHERE id=?")
        .bind(&meeting_id).fetch_one(state.db_manager.pool()).await.map_err(|_| "找不到此會議")?;
    let folder = folder.ok_or("此會議沒有保留音檔路徑")?;
    let path = crate::audio::retranscription::find_audio_file(std::path::Path::new(&folder))
        .map_err(|_| "找不到原始錄音，請確認錄音資料夾仍在")?;
    app.asset_protocol_scope().allow_file(&path).map_err(|_| "無法開啟此會議音檔")?;
    Ok(path.to_string_lossy().into_owned())
}

#[tauri::command]
pub async fn flybird_backup_database(app: AppHandle, state: tauri::State<'_, AppState>) -> Result<serde_json::Value, String> {
    let folder = app.path().app_data_dir().map_err(|_| "找不到資料資料夾")?.join("backups");
    std::fs::create_dir_all(&folder).map_err(|_| "無法建立備份資料夾")?;
    let stamp = format!("{}-{}", chrono::Utc::now().format("%Y%m%dT%H%M%SZ"), uuid::Uuid::new_v4());
    let temporary = folder.join(format!("{}.sqlite", stamp));
    let destination = folder.join(format!("{}.sqlite.dpapi", stamp));
    let result = async {
        sqlx::query("VACUUM INTO ?").bind(temporary.to_string_lossy().as_ref())
            .execute(state.db_manager.pool()).await.map_err(|_| "資料庫快照失敗，原資料未變更")?;
        let options = sqlx::sqlite::SqliteConnectOptions::new().filename(&temporary).read_only(true);
        let snapshot = sqlx::sqlite::SqlitePoolOptions::new().max_connections(1).connect_with(options).await.map_err(|_| "無法驗證備份")?;
        let integrity: String = sqlx::query_scalar("PRAGMA integrity_check").fetch_one(&snapshot).await.map_err(|_| "備份驗證失敗")?;
        let meetings: i64 = sqlx::query_scalar("SELECT COUNT(*) FROM meetings").fetch_one(&snapshot).await.map_err(|_| "無法核對備份筆數")?;
        let transcripts: i64 = sqlx::query_scalar("SELECT COUNT(*) FROM transcripts").fetch_one(&snapshot).await.map_err(|_| "無法核對備份筆數")?;
        snapshot.close().await;
        if integrity != "ok" { return Err("備份完整性檢查未通過"); }
        let bytes = std::fs::read(&temporary).map_err(|_| "無法讀取備份")?;
        let protected = crate::database::secret::protect_backup(&bytes).map_err(|_| "無法加密備份")?;
        use std::io::Write;
        let mut file = std::fs::OpenOptions::new().write(true).create_new(true).open(&destination).map_err(|_| "無法儲存加密備份")?;
        file.write_all(&protected).and_then(|_| file.sync_all()).map_err(|_| "備份寫入未完成，請檢查磁碟空間")?;
        Ok(serde_json::json!({"path":destination.to_string_lossy(),"meetings":meetings,"transcripts":transcripts,"integrity":integrity}))
    }.await;
    // This temporary snapshot contains only already-protected keys; remove it on every exit.
    if temporary.exists() { let _ = std::fs::remove_file(&temporary); }
    result.map_err(str::to_string)
}

#[tauri::command]
pub async fn flybird_complete_setup(app: AppHandle, state: tauri::State<'_, AppState>) -> Result<(), String> {
    let loaded = crate::whisper_engine::commands::whisper_get_current_model().await?;
    if loaded.as_deref() != Some("small") { return Err("Chinese transcription model is not ready".into()); }
    SettingsRepository::save_transcript_config(state.db_manager.pool(), "localWhisper", "small")
        .await.map_err(|e| e.to_string())?;
    let mut status = crate::onboarding::load_onboarding_status(&app).await.map_err(|e| e.to_string())?;
    status.completed = true;
    status.current_step = 4;
    status.last_updated = chrono::Utc::now().to_rfc3339();
    crate::onboarding::save_onboarding_status(&app, &status).await.map_err(|e| e.to_string())
}

#[tauri::command]
pub async fn flybird_export_transcript(app: AppHandle, state: tauri::State<'_, AppState>,
    meeting_id: String, format: String) -> Result<Option<String>, String> {
    let content = export_content(state.db_manager.pool(), &meeting_id, &format).await?;
    let filename = format!("會議逐字稿.{}", format);
    let file = app.dialog().file().set_file_name(&filename).add_filter("逐字稿", &[format.as_str()]).blocking_save_file();
    let Some(file) = file else { return Ok(None); };
    let path = file.into_path().map_err(|e| e.to_string())?;
    // UTF-8 BOM keeps Traditional Chinese readable in Windows text editors.
    let mut bytes = vec![0xef, 0xbb, 0xbf]; bytes.extend_from_slice(content.as_bytes());
    std::fs::write(&path, bytes).map_err(|e| e.to_string())?;
    Ok(Some(path.to_string_lossy().into_owned()))
}

async fn export_content(pool: &sqlx::SqlitePool, meeting_id: &str, format: &str) -> Result<String, String> {
    if format != "txt" && format != "md" { return Err("Unsupported export format".into()); }
    let title: String = sqlx::query_scalar("SELECT title FROM meetings WHERE id = ?")
        .bind(&meeting_id).fetch_one(pool).await.map_err(|e| e.to_string())?;
    // Query all rows, never just the current UI pagination window.
    let rows = sqlx::query("SELECT transcript, timestamp, audio_start_time FROM transcripts WHERE meeting_id = ? ORDER BY COALESCE(audio_start_time, 0), timestamp, id")
        .bind(&meeting_id).fetch_all(pool).await.map_err(|e| e.to_string())?;
    if rows.is_empty() { return Err("此會議還沒有可匯出的逐字稿".into()); }
    let mut content = if format == "md" { format!("# {}\n\n", title.replace('\n', " ")) } else { format!("{}\n\n", title) };
    for row in rows {
        let text: String = row.try_get("transcript").map_err(|e| e.to_string())?;
        let seconds: Option<f64> = row.try_get("audio_start_time").map_err(|e| e.to_string())?;
        let stamp = if let Some(t) = seconds { let s = t.max(0.0) as u64; format!("{:02}:{:02}:{:02}", s / 3600, s / 60 % 60, s % 60) }
            else { row.try_get::<String, _>("timestamp").unwrap_or_default() };
        content.push_str(&format!("[{}] {}\n\n", stamp, text));
    }
    Ok(content)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[tokio::test]
    #[ignore = "requires the separately verified model and synthetic fixture"]
    async fn transcribes_synthetic_chinese_without_microphone_or_cloud() {
        let audit = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../../../audit");
        let engine = crate::whisper_engine::WhisperEngine::new_with_models_dir(Some(audit.clone())).unwrap();
        engine.discover_models().await.unwrap();
        engine.load_model("small").await.unwrap();
        let audio = crate::audio::decoder::decode_audio_file(&audit.join("synthetic-zh-TW.wav")).unwrap();
        assert!(audio.duration_seconds > 20.0);
        let (text, _, _) = engine.transcribe_audio_with_confidence(audio.to_whisper_format(), Some("zh".into())).await.unwrap();
        std::fs::write(audit.join("synthetic-zh-TW-result.txt"), &text).unwrap();
        assert!(text.contains("網站") || text.contains("网站"), "Missing expected subject: {text}");
        assert!(text.contains("報表") || text.contains("报表"), "Missing second agenda item: {text}");
        // The fixture ends in 謝謝; recognition quality is reviewed separately.
        assert!(text.trim().ends_with("謝謝") || text.trim().ends_with("谢谢"), "Missing closing word: {text}");
    }
    #[tokio::test]
    async fn exports_every_saved_segment_in_time_order_and_preserves_chinese() {
        let pool = sqlx::sqlite::SqlitePoolOptions::new().max_connections(1).connect("sqlite::memory:").await.unwrap();
        sqlx::query("CREATE TABLE meetings(id TEXT, title TEXT)").execute(&pool).await.unwrap();
        sqlx::query("CREATE TABLE transcripts(id TEXT, meeting_id TEXT, transcript TEXT, timestamp TEXT, audio_start_time REAL)").execute(&pool).await.unwrap();
        sqlx::query("INSERT INTO meetings VALUES('test','中文驗收')").execute(&pool).await.unwrap();
        for i in (0..251).rev() {
            sqlx::query("INSERT INTO transcripts VALUES(?, 'test', ?, '12:00:00', ?)")
                .bind(i.to_string()).bind(format!("第{}段產品資料", i)).bind(i as f64).execute(&pool).await.unwrap();
        }
        let text = export_content(&pool, "test", "txt").await.unwrap();
        assert_eq!(text.matches("產品資料").count(), 251);
        assert!(text.contains("[00:04:10] 第250段產品資料"));
        assert!(text.find("第0段").unwrap() < text.find("第250段").unwrap());
        assert!(export_content(&pool, "test", "md").await.unwrap().starts_with("# 中文驗收"));
        assert!(export_content(&pool, "test", "exe").await.is_err());
        assert!(export_content(&pool, "missing", "txt").await.is_err());
    }
}
