'use client';
import { useState, useEffect } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';

export function FlybirdSetup() {
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState('');
  useEffect(() => {
    const cleanup = listen<{ modelName: string; progress: number }>('model-download-progress', e => {
      if (e.payload.modelName === 'small') setProgress(e.payload.progress);
    });
    return () => { void cleanup.then(fn => fn()); };
  }, []);
  async function setup() {
    if (busy) return;
    setBusy(true); setError('');
    try {
      await invoke('whisper_init');
      const models = await invoke<Array<{ name: string; status: string }>>('whisper_get_available_models');
      if (!models.some(m => m.name === 'small' && m.status === 'Available')) {
        await invoke('whisper_download_model', { modelName: 'small' });
      }
      await invoke('whisper_load_model', { modelName: 'small' });
      await invoke('flybird_complete_setup');
      localStorage.setItem('primaryLanguage', 'zh');
      // Reload providers so configuration is read back from the saved database.
      window.location.reload();
    } catch (e) { setError(String(e)); setBusy(false); }
  }
  return <main className="min-h-screen flex items-center justify-center bg-slate-50 p-8">
    <section className="max-w-xl bg-white rounded-2xl shadow p-8 space-y-5">
      <h1 className="text-3xl font-bold">思惟力量會議助手</h1>
      <p>基於 Meetily 社群版的繁體中文版本。錄製線上或實體會議，在這台電腦轉為逐字稿。</p>
      <p className="text-sm text-gray-600">首次準備下載約 466 MB 的 Whisper Small 多語模型。錄音與轉錄保留本機；不需要帳號、訂閱或 API 金鑰。模型下載完成後可離線轉錄。</p>
      <button onClick={setup} disabled={busy} className="rounded-lg bg-blue-700 text-white px-5 py-3 disabled:opacity-50">
        {busy ? `正在準備中文轉錄模型… ${progress}%` : '準備本機中文轉錄'}
      </button>
      {error && <p role="alert" className="text-red-700 break-words">準備未完成：{error}。請確認連線後重試。</p>}
      <p className="text-xs text-gray-500">逐字稿仍需人工校對。請在錄音前讓與會者知悉。</p>
    </section>
  </main>;
}
