'use client';
import {useEffect,useState} from 'react';
import {invoke} from '@tauri-apps/api/core';
import {useImportDialog} from '@/contexts/ImportDialogContext';
import {Button} from './ui/button';
import {toast} from 'sonner';
type Item={folder:string;name:string;status:string;chunks:number};
export function InterruptedRecordings(){
  const [items,setItems]=useState<Item[]>([]);
  const [busy,setBusy]=useState<string|null>(null);
  const {openImportDialog}=useImportDialog();
  const refresh=()=>invoke<Item[]>('list_interrupted_recordings').then(setItems).catch(()=>toast.error('無法檢查未完成錄音，請至錄音資料夾保留原音'));
  useEffect(()=>{void refresh();},[]);
  if(!items.length)return null;
  return <section className="mx-6 mt-4 p-4 border border-amber-300 bg-amber-50 rounded-lg" aria-label="未完成錄音復原">
    <h2 className="font-semibold">找到未完成的錄音</h2>
    <p className="text-sm">原音及分段仍保留。先檢查／復原，再由你確認是否轉錄；不會自動上傳。若會議已存在，請優先從原會議重新轉錄，避免重複建立。</p>
    {items.map(item=><div key={item.folder} className="flex items-center justify-between gap-3 mt-3">
      <span>{item.name} · {item.chunks} 個保留分段</span>
      <Button disabled={busy!==null} onClick={async()=>{
        setBusy(item.folder);
        try{
          const result=await invoke<{status:string;audio_file_path:string|null;message:string}>('recover_audio_from_checkpoints',{meetingFolder:item.folder,sampleRate:48000});
          if(result.status==='success'&&result.audio_file_path){toast.success(result.message||'原音已驗證；請確認匯入與處理設定');openImportDialog(result.audio_file_path);}
          else toast.error(result.message||'尚無可復原音檔，請保留資料夾');
        }catch{toast.error('復原未完成，程式未覆寫原音。請保留資料夾與分段，檢查磁碟空間、檔案權限及診斷紀錄後重試。');}
        finally{setBusy(null);}
      }}>{busy===item.folder?'正在檢查／復原…':'檢查原音並匯入'}</Button>
    </div>)}
  </section>;
}
