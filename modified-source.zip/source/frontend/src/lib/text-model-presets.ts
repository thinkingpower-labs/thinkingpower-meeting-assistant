// Official model references checked 2026-10-16. Presets are suggestions,
// not proof of account access or successful summary calls.
export const textModelPresets: Record<string, {id: string; label: string}[]> = {
  openai: [
    {id:'gpt-4.1-mini',label:'GPT-4.1 mini｜一般會議摘要，建議先選'},
    {id:'gpt-4o-mini',label:'GPT-4o mini｜簡單重點與待辦整理'},
  ],
  claude: [
    {id:'claude-sonnet-5-5',label:'Claude Sonnet 5.5｜會議紀錄整理'},
    {id:'claude-haiku-5-5',label:'Claude Haiku 5.5｜簡短摘要與資訊擷取'},
  ],
  groq: [
    {id:'openai/gpt-oss-20b',label:'GPT OSS 20B｜一般重點整理'},
    {id:'openai/gpt-oss-120b',label:'GPT OSS 120B｜較複雜的討論整理'},
  ],
  openrouter: [{id:'openai/gpt-4.1-mini',label:'OpenAI GPT-4.1 mini｜一般會議摘要'}],
};
